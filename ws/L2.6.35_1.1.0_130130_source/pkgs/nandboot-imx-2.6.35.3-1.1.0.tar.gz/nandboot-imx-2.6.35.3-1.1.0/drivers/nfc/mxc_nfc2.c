/*
 * Copyright 2004-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_nfc.c
 *
 * @brief NANDBoot NFC code.
 *
 * This code implements the SPL part of the NANDboot. This reads the pages from
 * NAND Flash to RAM and detects the bad block before copying the pages.
 *
 * @ingroup NANDboot
 */

#include "mxc_uart.h"
#include "mxc_nfc2.h"


int badblock_list[1024];

/*!
 * This function polls the NANDFC to wait for an operation to complete
 * function. It sets the flags for the commands that requires different read
 * and write operations.
 *
 * @param       maxRetries     number of retry attempts (separated by 1 us)
 */
int wait_op_done(U32 maxRetries)
{
	while (maxRetries-- > 0) {
		if (_reg_MXC_NFC_IPC & NFC_INT)
		{	_reg_MXC_NFC_IPC &= ~NFC_INT;
			break;
		}
		udelay(1);
	}

	if (maxRetries <= 0) {

		mxc_outstring("wait_op_done failed..\n");
		return -1;
	}
	return 0;
}


/*
 * This function does the trick of swapping the 464th byte in the last RAM
 * buffer in the main area with the 0th byte in the spare area. This seems
 * to be the optimal way of addressing the NFC imcompatibility problem with
 * the NAND flash out of factory in terms of BI field.
 * Note: this function only operates on the NFC's internal RAM buffers and
 *       for 2K page only.
 */
static void mxc_swap_2k_bi_main_sp(void)
{
        U16 tmp1, tmp2, new_tmp1;

        tmp1 = BAD_BLK_MARKER_464;
        tmp2 = BAD_BLK_MARKER_SP_0;
        new_tmp1 = (tmp1 & 0xFF00) | (tmp2 >> 8);
        tmp2 = (tmp1 << 8) | (tmp2 & 0xFF);
        BAD_BLK_MARKER_464 = new_tmp1;
        BAD_BLK_MARKER_SP_0 = tmp2;
}

/*!
 * For every read/write operation on NAND Flash, command has to be send .
 * This function sends command to the NAND Flash. It writes the command to the
 * NFC's Command Register. Configures the NFC's Configuration Register to
 * perform the Command Input Operation.
 *
 * @param       cmd    area from where to read the page
 *
 * @return      This function returns 0 if command operation is not  complete
 * else returns 1.
 */
int mxc_nfb_command(U16 cmd)
{
	_reg_MXC_NFC_NAND_ADD_CMD = cmd;
	/* Set FCMD to 1 */
	_reg_MXC_NFC_LAUNCH_NFC = NFC_FCMD;

	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_NB_WAIT_US) == 0) ? 1 : 0;
}
/*!
 * Reading or writing to any location in NAND Flash requires to pass an
 * address of that location in NFC. This function writes the NAND Flash Address
 * to the NFC's Address Register. Sets the Configuration Register for the
 * Address Input Operation
 *
 * @param       addr    addr from where to read the page
 *
 * @return      This function returns 0 if address operation is not complete
 * else returns 1.
 */
int mxc_nfb_address(U16 addr)
{
	_reg_MXC_NFC_NAND_ADD_CMD = (U32)addr  << 16 ;
	/* Set FADD to 1 */
	_reg_MXC_NFC_LAUNCH_NFC = NFC_FADD;

	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_NB_WAIT_US) == 0) ? 1 : 0;
}

/*!
 * This function configures the NFC to copy the NAND Flash data in the main
 * area number passed as parameter during read operation or write the data
 * from main area to the NAND Flash.
 *
 * @param       addr    value for the internal main area buffer.
 *
 * @return      This function returns 0 if the operation is not complete
 * else returns 1.
 */
int mxc_nfb_bufferaddr(U16 addr)
{
        /* NFC buffer 0 is used for page read/write */
         _reg_MXC_NFC_CONFIGURATION1 = ( _reg_MXC_NFC_CONFIGURATION1 | NFC_SET_RBA_BITS) & NFC_SET_RBA0;

	/* Set FDO to 1 */
	_reg_MXC_NFC_LAUNCH_NFC = NFC_FDO_PAGE;
	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_NB_WAIT_US) == 0) ? 1 : 0;
}
/*!
 * This function reads pages to NAND flash RAM buffer. It configures the NFC
 * with address of the internal RamBuffer where the data has to be copied and
 * then configures the NFC Configuration Register to perform the read
 * operation.
 * Address of NAND flash is send as 3 bytes. 1st byte is the offset of the
 * page. 2nd bytes has LSB 5 bits as page number. MSB 3 bits of 2nd byte and
 * LSB 7 bits of 3rd byte forms the 10 bits of block address.
 * This function also checks for the bad block. The block is said to be bad if
 * the value at OxBth location in the spare area for page 0 or 1 of the block
 * is not 0xFF (for 16 bit NAND flash only).
 * If the destination pointer is null this function will just check whether
 * the block is good or bad without copying data to RAM.
 *
 * @param       page    5 bit page address in the block
 * @param       block   10 bit block address
 *
 * @return      This function returns 0 if the page read is in bad block
 *              It returns 1 is page is in good block
 *              It returns -1 if any of the command or address has failed
 */
int mxc_nfb_readpage(U16 page, U16 block)
{
	U32 i, addr, bi;
	volatile U16 *spbuff8;
	volatile U16 *spbuff16;

	addr = ((U32)block << 6) | page;

	/* Check  for Badblock */
	if (badblock_list[block] == 1) {
		mxc_outstring("Bad block \n");
		return 0;
	}
	if (!mxc_nfb_command(0x0)) {
		return -1;
	}

	/*
	 * The NAND Flash Addr is a 4 Cycle process.  Write to NAND Flash Addr
	 * Register - Start Addr in Page
	 */
	if (!mxc_nfb_address(0)) {
		return -1;
	}
	if (!mxc_nfb_address(0)) {
               	return -1;
        }
	/* Write to NAND Flash Addr Register - 5 bit Page Addr and
	 * 3 bit LSB Block Addr
	 */
	if (!mxc_nfb_address(addr & 0xff)) {
		return -1;
	}

	/* Write to NAND Flash Addr Register - 7 bit MSB of Block Addr
	 * 8th bit is don't care
	 */
	if (!mxc_nfb_address((addr >> 8)& 0xff)) {
		return -1;
	}
	/* For 2k pagesize, need  read confirm*/
	if (!mxc_nfb_command(0x30)) {
       		return -1;
       	}
	/* For 2kpagesize nandflash, need all 4 buffers to load data*/
	 if (!mxc_nfb_bufferaddr(0x0)) {
     	        return -1;
    	}
	mxc_swap_2k_bi_main_sp();
	return 1;
}

/*
 * This function copies data using ldmia and stmia instructions. It uses the
 * r3-r10 registers for this and copies 8 words at a time
 *
 */
asm("   	                		\n\
        .align  2				\n\
        .text					\n\
        .global asmcopy_8w			\n\
        .type asmcopy_8w, %function		\n\
asmcopy_8w:					\n\
	stmfd sp!, {r3-r10, lr}		 	\n\
.Loop:	ldmia r1!, {r3-r10}			\n\
	stmia r0!, {r3-r10}			\n\
	subs r2, r2, #1				\n\
	bne .Loop				\n\
	ldmfd sp!, {r3-r10, pc}			\n\
");

/*!
 * This function copies Linux kernel Image starting from 1st block of the
 * NAND Flash to RAM. The Linux kernl image written to NAND Flash has 4 bytes
 * size and 4 bytes of crc value written at starting of the image. This 8 bytes
 * are initially skipped and then remaining data are copied to RAM. Using the
 * size and crc value validity of the Linux kernel image is checked.
 *
 * @param       pmem    memory address in RAM where Linux has to be copied
 * @param       start_block    starting block from where to copy kernel from
 *
 * @return      This function returns 0 if copying of kernel is not succeeded
 * else it will return 1.
 *
 */
int mxc_nfb_copyimage(U32 * pmem, U32 start_block)
{
	U16 page, block, bd_blk, nf_addr, addr;
	U8 *ch;
	volatile U32 *membuff;
	U32 size, crc, i, tmp, ret, pagenum;

	/* Read first page of linux kernel image in order to get size and crc */
	bd_blk = 0;
	do {
		page = 0;
		block = start_block + bd_blk;
		ret = mxc_nfb_readpage(page, block);
		if (ret == -1) {
			mxc_outstring("\n-->Failed to read page... ");
			return 0;
		}
		if (ret == 0) {
			bd_blk++;
		}
	}while (ret != 1);

	membuff = MAIN_AREA0;
	size = *(membuff++);
	crc = *(membuff++);
	mxc_outstring("\n-->Size: ");
	mxc_puthex(size);
	mxc_outstring("\n-->Crc: ");
	mxc_puthex(crc);
	ch = (U8 *) pmem;	/* for checking crc */
	mxc_outstring("\nCopying pages....");

	/* Copy the first 6 words separately as it is not 8 word aligned for asmcopy_8w*/
        for (i = 0; i < 6; i++) {
		*(pmem++) = *(membuff++);
	}

	/* Copy the remaining (NB_2k_PG_SZ / 4)- 8 words starting from pmem*/
	asmcopy_8w(pmem, membuff, (NB_2k_PG_SZ / 32) - 1);

	/* Incrememt pmem by the number of relevant words */
	pmem += (NB_2k_PG_SZ / 4) - 8;

	/* Get total number of pages of image */
       	nf_addr = (size / NB_2k_PG_SZ) + 1;

	/* Read the remaining pages */
	pagenum = start_block << 6;
	addr = (start_block << 6) + 1;

	for (; addr <= (nf_addr + pagenum); addr++) {
		page = addr & 0x3F;
		ret = 0;
		while (ret != 1) {
			block = (addr >> 6) + bd_blk;
			ret = mxc_nfb_readpage(page, block);
			if (ret == -1) {
				mxc_outstring("\n-->Failed to read page... ");
				return 0;
			}
			if (ret == 0) {
				bd_blk++;
			}
		}
		/* Copy bytes from RAM buffer main area 0 to RAM */
		membuff = MAIN_AREA0;

		asmcopy_8w(pmem, membuff, NB_2k_PG_SZ/32);
		pmem += NB_2k_PG_SZ/4;
	}
	/* Check addition crc for image validity */
	tmp = 0;
	mxc_outstring("Calculating CRC\n ");
	for (i = 0; i < size; i++) {
		tmp += *(ch++);
	}
	mxc_outstring("\n-->Calculated CRC: ");
	mxc_puthex(tmp);
	mxc_outstring("\n");
	if (tmp != crc) {
		return 0;
	}
	mxc_outstring("\n-->Found valid CRC\n");
	return 1;
}

/*!
 * This function scan for badblock and maintains the Badblock table
 * Badblock table is maintained only for Kernel partition (i.e)4Mb.
 */
int mxcnb_scan_badblocks(int startblock)
{
	int ret, i,blocknum;
	U16 bi;
	U32 reg;

	/*
	 * As the global data structures are never initilised to zero for
	 * Nandboot code, let us do that..
	 */
	for(i = 0; i < 1024; i++)
	{
 		badblock_list[i] = 0;
	}
	blocknum = 1024; /*for 2k pagesize nandflash, blocksize is 128k, 128k*32.*/

	for (i = startblock; i <= blocknum; i++) {
		ret = mxc_nfb_readpage(0, i);
		bi = BAD_BLK_MARKER_SP_0;
		bi = (bi & 0xFF00) >> 8;
		if (bi != 0xFF) {
		badblock_list[i] = 1;
		}
		/* Check page 1 for Badblock */
		if (!badblock_list[i]) {
			ret = mxc_nfb_readpage(1, i);
			bi = BAD_BLK_MARKER_SP_0;
			bi = (bi & 0xFF00) >> 8;
			if (bi != 0xFF) {
			badblock_list[i] = 1;
			}
		}

	}
	/*Returning 1 to tell upper layer that it is 2K page size*/
	return 1;
}
