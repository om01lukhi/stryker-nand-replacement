/*
 * Copyright 2004-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_init.c
 * 
 * @brief This file contains the initialization code of the basic hardware 
 * required for NANDboot to boot the Linux kernel
 * 
 * @ingroup Miniboot and NANDboot
 */

#include "mxc.h"
#include "mxc_uart.h"

#define MSDELAY(x)      ((x)*1000)

/*!
 * This is the initialization function for Watchdog Timer.
 */

#if WDOG_EN==1
void mxc_wd_init(void)
{

#if defined(nandboot)
#if UNIT_TEST
	U32 *debug_addr = DEBUG_ADDR2;
#endif
#endif
	/* Set the timeout and WRE (4th bit) to 0 */
	_reg_MXC_WDOG_WCR |= (WDOG_TIMEOUT & ~0x0008);

	_reg_MXC_WDOG_WCR |= 0x0004;	/* Enable Watchdog Timer */

#if defined(nandboot)
#if UNIT_TEST
	if (!(_reg_MXC_WDOG_WCR & 0x0400)) {
		*(debug_addr++) = 0x50;	/* error */
	} else {
		*(debug_addr++) = 0x70;	/* success */
	}

	if (_reg_MXC_WDOG_WCR & 0x0018) {
		*(debug_addr++) = 0x51;	/* error */
	} else {
		*(debug_addr++) = 0x71;	/* success */
	}

	if (!(_reg_MXC_WDOG_WCR & 0x0004)) {
		*(debug_addr++) = 0x52;	/* error */
	} else {
		*(debug_addr++) = 0x72;	/* success */
	}
#endif
#endif
}
#else
void mxc_wd_init(void)
{
}
#endif

/*!
 * This function is used to service the Watchdog Timer before it gets timeout.
 */
void mxc_wd_reset(void)
{
	if (_reg_MXC_WDOG_WCR & 0x0004) {	/* service only if WDOG enabled */
		_reg_MXC_WDOG_WSR = 0x5555;
		_reg_MXC_WDOG_WSR = 0xAAAA;
	}
}

/*!
 * This is helper sleep function which loops for approximately given number
 * usecs.
 *
 * @param       count     number of usec to wait loop
 */
void udelay(int count)
{
/* Assuming 366 MHz, 366 instructions will take 1 usec, we will execute 2
 * inst in the loop (1 compare, 1 increment).
 */
#define LOOPS_PER_USEC (366 / 2)

        volatile int i;

        count *= LOOPS_PER_USEC; /* 'count' number of usec */

        for (i = 0; i < count; i++)
                ;
}

/*!
 * This function waits for input from user for few sec(6sec)
 *
 * @param       timeout   indicates the timeout or input from user
 *              1 -> Time out occured
 *              0->  Input from user
 *
 */
int  mxc_timeout(int timeout)
{
        unsigned int j;

        for (j = 0; j < MSDELAY(timeout); j++) {
                 udelay(100);
                 if(mxc_dataready()) {
                         return 0;
                 }
       }
       return 1;
}

#ifdef CLR_WDOG_PDE

#define MU_MEMORY_WRITE_OPCODE    1UL
#define MU_POLL_COUNTER_INIT      0x00100000
#define BP_PDC_DISABLE_VALUE      0x0
#define BP_PDC_LOCATION           0xFFF9C008

static unsigned int mu_read(unsigned int idx, unsigned int *value)
{
    unsigned int count = MU_POLL_COUNTER_INIT;
    unsigned int mask = 1 << (27 - idx);
    unsigned int addr = readl(MU_BASE_ADDR + 0x10 + (idx * 4));

    /* Wait for MRFn bit to become set */
    while (count-- && ((readl(MU_BASE_ADDR + 0x20) & mask) == 0));

    /* Fail if counter expired */
    if (count == ~0) {
        return 1;
    }
    /* Read value from register */
    *value = addr;

    return 0;
}

static unsigned int mu_write(unsigned int idx, unsigned int value)
{
    unsigned int count = MU_POLL_COUNTER_INIT;
    unsigned int mask = 1 << (23 - idx);
    unsigned int test;

    /* Wait for MTEn bit to become set */
    do {
        test = (readl(MU_BASE_ADDR + 0x20) & mask);
    } while (count-- && !test);

    /* Fail if counter expired */
    if (count == ~0)
        return 1;

    /* Write value to register */
    writel(value, MU_BASE_ADDR + (idx * 0x4));

    return 0;
}

static int clear_bp_wdog_pde(unsigned int dst, unsigned int num)
{
    unsigned int index = 0;
    unsigned int response;
    unsigned int count = num;

    /* Write command and destination address */
    if (mu_write(index++, (num << 16) | MU_MEMORY_WRITE_OPCODE)
        || mu_write(index++, dst)) {
        return 1;
    }

    /* Write words from source, wrapping around 4 MU registers */
    while (num--)
    {
        if (mu_write(index++, BP_PDC_DISABLE_VALUE)) return 1;
        index = index % 4;
    }

    /* Read response and check */
    if (mu_read(0, &response)
        || (count != (response >> 16))
        || (MU_MEMORY_WRITE_OPCODE != (response & 0xFF))
        || (0 != ((response >> 8) & 0xFF))) {
        return 1;
    }

    return 0;
}
int mxc_wdog_clrpde(void)
{
    // disable PDE bit inside AP WDOG
    _reg_MXC_WDOG_WMCR = 0;
    // disable PDE bit inside BP WDOG
    clear_bp_wdog_pde(BP_PDC_LOCATION, 1);
}

#endif


