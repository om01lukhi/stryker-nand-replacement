/******************************************************************************

 C   M O D U L E   F I L E
 
 (c) Copyright Motorola Semiconductors Hong Kong Limited 2000-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name	: i.MX System Test Program
 Project No.	: 
 Title			: 
 File Name		: macros.c    
 Last Modified	: 04/27/2003
 (MM/DD/YYYY)

 Description	: This file has all the macros and inline function for i.MX 
				  system test.

 Comments		:

 History (MM/DD/YYYY):
 04/27/2003 - Initial Proposal

******************************************************************************/




#include <stdio.h>
#include "common.h"
#include "tht_memory_map_defines.h"
#include "prototype.h"

// Inline function Macro to handle the Instruction Cache. 
// ENABLE I CACHE for aitc acceleration OPERATION	
void EnableICache (void)
{
__asm {
    mrc p15,0,r0,c1,c0,0
    mov r2, #0x00001000
    orr r0,r2,r0
    mcr p15,0,r0,c1,c0,0
}
}

// DISABLE I CACHE for aitc acceleration OPERATION	
void DisableICache (void)
{
__asm {
    mrc p15,0,r0,c1,c0,0
    mov r2, #0xFFFFEFFF
    and r0,r2,r0
    mcr p15,0,r0,c1,c0,0
}
}

// To set the iA bit and the nF bit of CP15 register 1.  
void SetAsynchMode(void)
{
__asm {
    mrc p15,0,r0,c1,c0,0
    mov r2, #0xC0000000
    orr r0,r2,r0
    mcr p15,0,r0,c1,c0,0
}
}

void SetFastBusMode(void)
{
__asm {
    mrc p15,0,r0,c1,c0,0
    mov r2, #0x3FFFFFFF
    and r0,r2,r0
    mcr p15,0,r0,c1,c0,0
}
}

// IRQ handling function for the ARM core. 
// Enable IRQ
void EnableIRQ (void)
{
__asm {
MRS r1, CPSR
BIC r1, r1, #0x80
MSR CPSR_c, r1
}
}

// Disable IRQ
void DisableIRQ (void)
{
__asm {
MRS r1, CPSR
ORR r1, r1, #0x80
MSR CPSR_c, r1
}
}

// Enable FIQ
void EnableFIQ (void)
{
__asm {
MRS r1, CPSR
BIC r1, r1, #0x40
MSR CPSR_c, r1
}
}

// Disbale FIQ
void DisableFIQ (void)
{
__asm {
MRS r1, CPSR
ORR r1, r1, #0x40
MSR CPSR_c, r1
}
}

// Mask IRWQ Level
// MaskLevel = 16 or above means do not disable any normal interrupts
void MaskIRQLevel(uint32_t MaskLevel)
{
	MaskLevel &= 0x0000001F;
	*(p_uint32_t)AITC_NIMASK = (uint32_t)MaskLevel;
}

// Macro to set the Interrupt Enable Number Register
void EnableIntSource(uint32_t IntNum)
{
	IntNum &= 0x0000003F;
	*(p_uint32_t)AITC_INTENNUM = (uint32_t)IntNum;
}

// Macro to disable the Interrupt Disable Number Register
void DisableIntSource(uint32_t IntNum)
{
	IntNum &= 0x0000003F;
	*(p_uint32_t)AITC_INTDISNUM = (uint32_t)IntNum;
}

void SetIntType(uint32_t IntNum, uint8_t type)
{
	uint32_t bitpos;
	if (IntNum<=31)
	{
		bitpos = 0x01;	
		bitpos <<= IntNum;
		if (type)
		{
			// set the source to FIQ
			*(p_uint32_t)AITC_INTTYPEL |= (uint32_t)IntNum;
		}
		else
		{
			// set the source to IRQ
			*(p_uint32_t)AITC_INTTYPEL &= (uint32_t)~IntNum;	
		}
		return;	
	}
	if ((IntNum>=32)&&(IntNum<=63))
	{
		bitpos = 0x01;	
		IntNum <<= 5;
		bitpos <<= IntNum;
		if (type)
		{
			// set the source to FIQ
			*(p_uint32_t)AITC_INTTYPEH |= (uint32_t)IntNum;
		}
		else
		{
			// set the source to IRQ
			*(p_uint32_t)AITC_INTTYPEH &= (uint32_t)~IntNum;	
		}
		return;
	}
	return;	
}

// A macro to set the priority level of the IRQ source.
void SetIrqPriority(uint8_t IntNum, uint8_t level)
{
 	switch(IntNum)
    	{
        	case 63:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
			case 62:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
			case 61:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
			case 60:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
			case 59:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
			case 58:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
			case 57:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
			case 56:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY7 |= level; return;
        	case 55:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
			case 54:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
			case 53:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
			case 52:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
			case 51:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
			case 50:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
			case 49:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
			case 48:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY6 |= level; return;
        	case 47:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;
			case 46:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;
			case 45:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;
			case 44:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;
			case 43:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;
			case 42:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;
			case 41:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;
			case 40:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY5 |= level; return;				
        	case 39:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;
			case 38:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;
			case 37:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;
			case 36:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;
			case 35:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;
			case 34:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;
			case 33:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;
			case 32:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY4 |= level; return;			
        	case 31:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;
			case 30:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;
			case 29:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;
			case 28:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;
			case 27:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;
			case 26:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;
			case 25:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;
			case 24:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY3 |= level; return;			
        	case 23:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;
			case 22:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;
			case 21:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;
			case 20:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;
			case 19:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;
			case 18:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;
			case 17:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;
			case 16:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY2 |= level; return;			
        	case 15:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;
			case 14:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;
			case 13:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;
			case 12:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;
			case 11:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;
			case 10:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;
			case 9:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;
			case 8:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY1 |= level; return;			
        	case 7:
				level <<= 28; level &= 0xF0000000;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;
			case 6:
				level <<= 24; level &= 0x0F000000;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;
			case 5:
				level <<= 20; level &= 0x00F00000;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;
			case 4:
				level <<= 16; level &= 0x000F0000;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;
			case 3:
				level <<= 12; level &= 0x0000F000;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;
			case 2:
				level <<= 8; level &= 0x00000F00;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;
			case 1:
				level <<= 4; level &= 0x000000F0;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;
			case 0:
				level &= 0x0000000F;
				*(p_uint32_t)AITC_NIPRIORITY0 |= level; return;						
			default:
				return;
		}							
}

// A macro to force the interrupt for testing.
void ForceOneInt(uint32_t IntNum)
{
  uint32_t intbit;

  intbit = 1;				// initialize the interrupt bit
  
  	if (IntNum<=31) 	
  	{
    	intbit <<= (IntNum);		// set the next interrupt bit, i=0, AITC_INTFRCL=0x1; i=1, AITC_INTFRCL=0x2;
    	*(p_uint32_t)AITC_INTFRCL |= intbit;	// i=2, AITC_INTFRCL=0x4...i=31, AITC_INTFRCL=0x80000000
	}
  	else 
  	{
    	intbit <<= (IntNum-32);		// set the next interrupt bit, i=32, AITC_INTFRCH=0x1; i=33, AITC_INTFRCH=0x2;
    	*(p_uint32_t)AITC_INTFRCH |= intbit;	// i=34, AITC_INTFRCH=0x4...i=63; AITC_INTFRCH=0x80000000
	}

}  // ForceOneInt


void ForceAllInt(void)
{	
  *(p_uint32_t)AITC_INTFRCH |= 0xFFFFFFFF;
  *(p_uint32_t)AITC_INTFRCL |= 0xFFFFFFFF; 
}  // ForceAllInt
	