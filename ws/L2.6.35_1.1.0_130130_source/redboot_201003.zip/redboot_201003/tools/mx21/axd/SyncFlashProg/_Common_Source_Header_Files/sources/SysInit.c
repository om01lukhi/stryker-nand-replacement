/******************************************************************************

 C   M O D U L E   F I L E
 
 (c) Copyright Motorola Semiconductors Hong Kong Limited 2000-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name	: i.MX System Test Program
 Project No		: 
 Title			: 
 File Name		: SysInit.c    
 Last Modified	: 04/27/2003
 (MM/DD/YYYY)

 Description	: Module and system initialization routines

 Comments		:

 History (MM/DD/YYYY) :
 04/27/2003 - Initial Proposal

******************************************************************************/

#define SYS_DEFINE_GLOBALS

#include <stdio.h>
#include "common.h"
#include "tht_memory_map_defines.h"
#include "prototype.h"

extern void SetIntType(uint32_t IntNum, uint8_t type);
extern void SetAsynchMode(void);


/////////////////////////////////////////////////
//											   //	
//	Call by user program for interupt enable   //
//											   //
/////////////////////////////////////////////////
void IrptInit(void)
{
	uint32_t i;
	*(p_uint32_t)AITC_INTCNTL &= 0x00;
	/* To set all interrupt source to normal interrupt source */	
	for (i=0; i<=63; i++)
	{
		SetIntType(i, 0);
	}	 

	/* Enable all int sources */
/*	for (i=0; i<=31; i++)
	{
		EnableIntSource(i);
	}
*/
}

void MemInit(void)
{

	// initialize memory controllers for memories on ADS
	// Initialize the SDRAMC control register
	// it's assumed that the debugger initialization file has already initialized the SDRAM
	// Well just make sure it's initialized here, but can come back and optimize
	// *(p_uint32_t) SDRAMC_SDCTL0 = 0x8212C300;
	
	// initilaize the EIM CS0 register for async accesses to the AMD flash
	// Again, we can optimize settings later
	*(p_uint32_t)WEIM_CS0U = 0x00000800; 
	*(p_uint32_t)WEIM_CS0L = 0x00000E01;

}

void LCDCInit(void)
{
}

void SysInit(void)
{
	// initialize PLL and clocks here
	// Set up the MPLL for 266.0000537MHz
	// PD = 0; MFI = 7; MFN = 115; MFD = 123
	*(p_uint32_t)CRM_MPCTL0 = 0x007B1C73;
	*(p_uint32_t)CRM_MPCTL1 = 0x00000040; 	// set BRMO since 1/10 < MFN/MFD+1 < 9/10
	
	// Set up the SPLL for 287.9999978Mhz operation
	*(p_uint32_t)CRM_SPCTL0 = 0x03B02227;
	
	// now configure the CSCR register
	// clear all bits except for PRESC
	*(p_uint32_t)CRM_CSCR &= 0x0000C000;
	
	// Now set USBDIV=5; SD_CNT=3; BCLKDIV=2; IPDIV=1; HCLK will be 88.6MHz
	*(p_uint32_t)CRM_CSCR |= 0x17000A07;		
	
	// Last step, clear PRESC to 0
	*(p_uint32_t)CRM_CSCR &= 0xFFFF3FFF;
	
	// Now, restart the PLLs
	*(p_uint32_t)CRM_CSCR |= 0x00600000;
	
	// Wait for lock flag to set
	while((*(p_uint32_t)CRM_MPCTL1 & 0x00008000) != 0x00008000);	


	// enable the following in the PCCR0
	// HCLK_DMA, LCDC, LCDC_PIXCLK, DMA_EN, GPIO_EN
	*(p_uint32_t)CRM_PCCR0 |= 0x44042800;
	
}



