/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mx25.c
 *
 * @brief Main source file for Nandboot
 *
 * @ingroup NANDboot
 */

#include "mxc.h"

unsigned int read_system_rev(void)
{
	unsigned int system_rev = 0x25 << PART_NUMBER_OFFSET;

	switch (_reg_MXC_IIM_SREV) {
	case 0x0: /* Rev 1.0 */
		system_rev |= (1 << MAJOR_NUMBER_OFFSET);
		system_rev |= (0 << MINOR_NUMBER_OFFSET);
		break;
	case 0x1: /* Rev 1.1 */
		system_rev |= (1 << MAJOR_NUMBER_OFFSET);
		system_rev |= (1 << MINOR_NUMBER_OFFSET);
		break;
	}

	return system_rev;
}

void mxc_platform_init()
{
	/* Mask all interrupts */
	_reg_MXC_ASIC_NIMASK = 0xFFFFFFFF;

	/* Make all interrupts IRQ and not FIQ */
	_reg_MXC_ASIC_INTTYPEH = 0;
	_reg_MXC_ASIC_INTTYPEL = 0;
}
