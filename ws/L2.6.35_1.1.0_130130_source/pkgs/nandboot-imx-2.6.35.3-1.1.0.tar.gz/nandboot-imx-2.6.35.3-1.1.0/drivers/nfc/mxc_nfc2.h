
#ifndef MXC_NFC_H
#define MXC_NFC_H
/*
 * Copyright 2004-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_nfc.h
 *
 * @brief This file contains the NAND Flash Controller register information.
 *
 *
 * @ingroup NANDboot
 */

#include "mxc.h"

/*!
 * @name Addresses for NFC registers
 */

/*! @{ */

#define _reg_MXC_NFC_NAND_ADD_CMD       (*((volatile U32 *)(MXC_NFC_BASE_ADDR+0xE00)))
#define _reg_MXC_NFC_CONFIGURATION1	(*((volatile U32 *)(MXC_NFC_BASE_ADDR+0xE04)))
#define _reg_MXC_NFC_ECC_STATUS_RESULT	(*((volatile U32 *)(MXC_NFC_BASE_ADDR+0xE08)))
#define _reg_MXC_NFC_LAUNCH_NFC		(*((volatile U32 *)(MXC_NFC_BASE_ADDR+0xE0C)))

#define _reg_MXC_NFC_WR_PROTECT		(*((volatile U32 *)(MXC_NFC_BASE_ADDR_IP )))
#define _reg_MXC_NFC_UNLOCK_BLK_ADD0	(*((volatile U32 *)(MXC_NFC_BASE_ADDR_IP + 0x04)))
#define _reg_MXC_NFC_CONFIGURATION2	(*((volatile U32 *)(MXC_NFC_BASE_ADDR_IP + 0x14)))
#define _reg_MXC_NFC_IPC			(*((volatile U32 *)(MXC_NFC_BASE_ADDR_IP + 0x18)))


#define NFC_BLS_UNLCK 		(2 << 16)
#define NFC_WPC_UNLCK 		(4 << 0)

#define NFC_FCMD 		(1 << 0)
#define NFC_FADD 		(1 << 1)
#define NFC_FDO_PAGE 		(1 << 3)

#define NFC_INT_MSK 		(1 << 4)
#define NFC_INT 		(1 << 31)
#define NFC_CACK		(1 << 1)
#define NFC_CREQ		(1 << 0)

/* read column 464-465 byte but only 464 for bad block marker */
#define BAD_BLK_MARKER_464      (*((volatile U16 *)(MXC_NFC_BASE_ADDR + 0x600 + 464)))
/* read column 0-1 byte, but only 1 is used for swapped main area data */
#define BAD_BLK_MARKER_SP_0     (*((volatile U16 *)(MXC_NFC_BASE_ADDR + 0x800)))
/*!
 * @name NFC RAM buffer main area addresses
 */
/*! @{ */
/*!
 * NFC RAM buffer main area 0 address
 */
#define MAIN_AREA0              (volatile U32 *)(MXC_NFC_BASE_ADDR+0x000)

#define NFC_SET_RBA_BITS     0x00000030
#define NFC_SET_RBA0         0xFFFFFFCF
#define NFC_SET_PPB_BITS     0x00000180
#define NFC_SET_PPB64        0xFFFFFEFF
#define NFC_SET_BLS_BITS     0x00030000
#define NFC_BLS_UNLOCK       0xFFFEFFFF
#define NFC_SET_WPC_BITS     0x00000007
#define NFC_WPC_UNLOCK       0xFFFFFFFC
#define NFC_UEBA0            16

#define NAND_CMD_READ0          0x0
#define NAND_CMD_READSTART      0x30
#define NAND_CMD_RESET          0xff

#define MXC_NB_WAIT_US          2000
#define NB_2k_PG_SZ 		2048

#endif				/* MXC_NB_NFC_H */
