/******************************************************************************

 C   M O D U L E   F I L E
 
 (c) Copyright Motorola Semiconductors Hong Kong Limited 2000-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name	: i.MX System Test Program
 Project No. 	: 
 Title			: 
 File Name		: chandle.c    
 Last Modified	: 04/27/2003
 (MM/DD/YYYY)

 Description	: Interrupt Handlers

 Comments		:

 History (MM/DD/YYYY):
 04/27/2003 - Initial Proposal

******************************************************************************/

/*
 * Copyright (C) ARM Limited, 1998. All rights reserved.
 */
#include <stdio.h>
#include "tht_memory_map_defines.h"
#include "common.h"
#include "prototype.h"
extern int32_t gIntFlag;


typedef void (*funct_t)(void);		// define a pointer to a function

/* look up table of normal ISRs */
funct_t vect_IRQ[64] = 
					{
					norm_scr00_isr, norm_scr01_isr, norm_scr02_isr, norm_scr03_isr,  
					norm_scr04_isr, norm_scr05_isr, norm_scr06_isr, norm_scr07_isr,
					norm_scr08_isr, norm_scr09_isr, norm_scr10_isr, norm_scr11_isr,  
					norm_scr12_isr, norm_scr13_isr, norm_scr14_isr, norm_scr15_isr,
					norm_scr16_isr, norm_scr17_isr, norm_scr18_isr, norm_scr19_isr,  
					norm_scr20_isr, norm_scr21_isr, norm_scr22_isr, norm_scr23_isr,
					norm_scr24_isr, norm_scr25_isr, norm_scr26_isr, norm_scr27_isr,  
					norm_scr28_isr, norm_scr29_isr, norm_scr30_isr, norm_scr31_isr,
					norm_scr32_isr, norm_scr33_isr, norm_scr34_isr, norm_scr35_isr,  
					norm_scr36_isr, norm_scr37_isr, norm_scr38_isr, norm_scr39_isr,
					norm_scr40_isr, norm_scr41_isr, norm_scr42_isr, norm_scr43_isr,  
					norm_scr44_isr, norm_scr45_isr, norm_scr46_isr, norm_scr47_isr,
					norm_scr48_isr, norm_scr49_isr, norm_scr50_isr, norm_scr51_isr,  
					norm_scr52_isr, norm_scr53_isr, norm_scr54_isr, norm_scr55_isr,
					norm_scr56_isr, norm_scr57_isr, norm_scr58_isr, norm_scr59_isr, 
					norm_scr60_isr, norm_scr61_isr, norm_scr62_isr, norm_scr63_isr
					};

/* look up table of fast ISRs */					 
funct_t vect_FIQ[64] = 
					{
					fast_scr00_isr, fast_scr01_isr, fast_scr02_isr, fast_scr03_isr,  
					fast_scr04_isr, fast_scr05_isr, fast_scr06_isr, fast_scr07_isr,
					fast_scr08_isr, fast_scr09_isr, fast_scr10_isr, fast_scr11_isr,  
					fast_scr12_isr, fast_scr13_isr, fast_scr14_isr, fast_scr15_isr,
					fast_scr16_isr, fast_scr17_isr, fast_scr18_isr, fast_scr19_isr,  
					fast_scr20_isr, fast_scr21_isr, fast_scr22_isr, fast_scr23_isr,
					fast_scr24_isr, fast_scr25_isr, fast_scr26_isr, fast_scr27_isr,  
					fast_scr28_isr, fast_scr29_isr, fast_scr30_isr, fast_scr31_isr,
					fast_scr32_isr, fast_scr33_isr, fast_scr34_isr, fast_scr35_isr,  
					fast_scr36_isr, fast_scr37_isr, fast_scr38_isr, fast_scr39_isr,
					fast_scr40_isr, fast_scr41_isr, fast_scr42_isr, fast_scr43_isr,  
					fast_scr44_isr, fast_scr45_isr, fast_scr46_isr, fast_scr47_isr,
					fast_scr48_isr, fast_scr49_isr, fast_scr50_isr, fast_scr51_isr,  
					fast_scr52_isr, fast_scr53_isr, fast_scr54_isr, fast_scr55_isr,
					fast_scr56_isr, fast_scr57_isr, fast_scr58_isr, fast_scr59_isr, 
					fast_scr60_isr, fast_scr61_isr, fast_scr62_isr, fast_scr63_isr
					};

/******************************* Global Data *********************************/
#define NUM_INT_SOURCES	64
/* ISR flags */
volatile int32_t gNormInt0flag;
volatile int32_t gNormInt1flag;
volatile int32_t gNormInt2flag;
volatile int32_t gNormInt3flag;
volatile int32_t gNormInt4flag;
volatile int32_t gNormInt5flag;
volatile int32_t gNormInt6flag;
volatile int32_t gNormInt7flag;
volatile int32_t gNormInt8flag;
volatile int32_t gNormInt9flag;
volatile int32_t gNormInt10flag;
volatile int32_t gNormInt11flag;
volatile int32_t gNormInt12flag;
volatile int32_t gNormInt13flag;
volatile int32_t gNormInt14flag;
volatile int32_t gNormInt15flag;
volatile int32_t gNormInt16flag;
volatile int32_t gNormInt32flag;
volatile int32_t gNormInt61flag;
volatile int32_t gNormInt62flag;
volatile int32_t gNormInt63flag;

volatile int32_t gFastInt0flag;
volatile int32_t gFastInt1flag;
volatile int32_t gFastInt2flag;
volatile int32_t gFastInt4flag;
volatile int32_t gFastInt8flag;
volatile int32_t gFastInt16flag;
volatile int32_t gFastInt32flag;
volatile int32_t gFastInt61flag;
volatile int32_t gFastInt62flag;
volatile int32_t gFastInt63flag;			

volatile int32_t gFailFastCount;
volatile int32_t gFailPendingCount;
volatile int32_t gFailPriorityCount;
					 				
void C_SWI_Handler( int32_t swi_num, int32_t *regs )
{
    switch( swi_num )
    {
    	case 0:
    	break;
		default:
    	break;
    }
}


void C_Undefined_Handler(void)
{
	//read in ITC status reg
	//test bit for dispatch
	//call user ISR
	return;
}

void C_Prefetch_Handler(void)
{
	//read in ITC status reg
	//test bit for dispatch
	//call user ISR
	return;
}

void C_Abort_Handler(void)
{
	//read in ITC status reg
	//test bit for dispatch
	//call user ISR
	return;
}


/******************************************************************************
* IRQ_Handler                                                                 *
* This function handles IRQ interrupts.  				                      *
******************************************************************************/

void __irq C_IRQ_Handler(void)
{
	int16_t vectNum;
	vectNum = AITC_NIVECSR >> 16;	// determine highest pending normal interrupt		
	vect_IRQ[vectNum]();		// find the pointer to correct ISR in the look up table
}

/******************************************************************************
* FIQ_Handler                                                                 *
* This function handles IRQ interrupts.  				                      *
******************************************************************************/

void __irq C_FIQ_Handler(void)
{
	int16_t vectNum;
	vectNum = AITC_FIVECSR & 0x0000003F;	// determine highest pending fast interrupt
	vect_FIQ[vectNum]();		// find the pointer to correct ISR in the look up table
}


/*******************************************************************************
*
*  Interrupt Handlers (64 fast int sources and 64 normal int sources)
*
*******************************************************************************/


/***********************/
/* Fast Interrupt ISRs */
/***********************/


void   fast_scr31_isr(void)		// fast_scr31_isr (31)
{
    if((AITC_FIPNDL & 0x80000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x80000000;		// clear the bit in the force reg.
}

void   fast_scr63_isr(void)	// fast_scr63_isr (63)
{
    if((AITC_FIPNDH & 0x80000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x80000000;		// clear the bit in the force reg.
    gFastInt63flag = 1;				// set flag
}

void   fast_scr30_isr(void)	// fast_scr30_isr (30)
{
    if((AITC_FIPNDL & 0x40000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x40000000;		// clear the bit in the force reg.
}

void   fast_scr62_isr(void)	// fast_scr62_isr (62)
{
    if((AITC_FIPNDH & 0x40000000)== 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x40000000;		// clear the bit in the force reg.
    gFastInt62flag = 1;
}

void   fast_scr29_isr(void)	// fast_scr29_isr (29)
{
    if((AITC_FIPNDL & 0x20000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x20000000;		// clear the bit in the force reg.
}

void   fast_scr61_isr(void)	// fast_scr61_isr (61)
{
    if((AITC_FIPNDH & 0x20000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x20000000;		// clear the bit in the force reg.
}

void   fast_scr28_isr(void)	// fast_scr28_isr (28)
{
    if((AITC_FIPNDL & 0x10000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x10000000;		// clear the bit in the force reg.
}

void   fast_scr60_isr(void)	// fast_scr60_isr (60)
{
    if((AITC_FIPNDH & 0x10000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x10000000;		// clear the bit in the force reg.
}

void   fast_scr27_isr(void)	// fast_scr27_isr (27)
{
    if((AITC_FIPNDL & 0x08000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x08000000;		// clear the bit in the force reg.
}

void   fast_scr59_isr(void)	// fast_scr59_isr (59)
{
    if((AITC_FIPNDH & 0x08000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x08000000;		// clear the bit in the force reg.
}

void   fast_scr26_isr(void)	// fast_scr26_isr (26)
{
    if((AITC_FIPNDL & 0x04000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x04000000;		// clear the bit in the force reg.
}

void   fast_scr58_isr(void)	// fast_scr58_isr (58)
{
    if((AITC_FIPNDH & 0x04000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x04000000;		// clear the bit in the force reg.
}

void   fast_scr25_isr(void)	// fast_scr25_isr (25)
{
    if((AITC_FIPNDL & 0x02000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x02000000;		// clear the bit in the force reg.
}

void   fast_scr57_isr(void)	// fast_scr57_isr (57)
{
    if((AITC_FIPNDH & 0x02000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x02000000;		// clear the bit in the force reg.
}

void   fast_scr24_isr(void)	// fast_scr24_isr (24)
{
    if((AITC_FIPNDL & 0x01000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x01000000;		// clear the bit in the force reg.
}

void   fast_scr56_isr(void)	// fast_scr56_isr (56)
{
    if((AITC_FIPNDH & 0x01000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x01000000;		// clear the bit in the force reg.
}

void   fast_scr23_isr(void)	// fast_scr23_isr (23)
{
    if((AITC_FIPNDL & 0x00800000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00800000;		// clear the bit in the force reg.
}

void   fast_scr55_isr(void)	// fast_scr55_isr (55)
{
    if((AITC_FIPNDH & 0x00800000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00800000;		// clear the bit in the force reg.
}

void   fast_scr22_isr(void)	// fast_scr22_isr (22)
{
    if((AITC_FIPNDL & 0x00400000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00400000;		// clear the bit in the force reg.
}

void   fast_scr54_isr(void)	// fast_scr54_isr (54)
{
    if((AITC_FIPNDH & 0x00400000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00400000;		// clear the bit in the force reg.
}

void   fast_scr21_isr(void)	// fast_scr21_isr (21)
{
    if((AITC_FIPNDL & 0x00200000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00200000;		// clear the bit in the force reg.
}

void   fast_scr53_isr(void)	// fast_scr53_isr (53)
{
    if((AITC_FIPNDH & 0x00200000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00200000;		// clear the bit in the force reg.
}

void   fast_scr20_isr(void)	// fast_scr20_isr (20)
{
    if((AITC_FIPNDL & 0x00100000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00100000;		// clear the bit in the force reg.
}

void   fast_scr52_isr(void)	// fast_scr52_isr (52)
{
    if((AITC_FIPNDH & 0x00100000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00100000;		// clear the bit in the force reg.
}

void   fast_scr19_isr(void)	// fast_scr19_isr (19)
{
    if((AITC_FIPNDL & 0x00080000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00080000;		// clear the bit in the force reg.
}

void   fast_scr51_isr(void)	// fast_scr51_isr (51)
{
    if((AITC_FIPNDH & 0x00080000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00080000;		// clear the bit in the force reg.
}

void   fast_scr18_isr(void)	// fast_scr18_isr (18)
{
    if((AITC_FIPNDL & 0x00040000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00040000;		// clear the bit in the force reg.
}

void   fast_scr50_isr(void)	// fast_scr50_isr (50)
{
    if((AITC_FIPNDH & 0x00040000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00040000;		// clear the bit in the force reg.
}

void   fast_scr17_isr(void)	// fast_scr17_isr (17)
{
    if((AITC_FIPNDL & 0x00020000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00020000;		// clear the bit in the force reg.
}

void   fast_scr49_isr(void)	// fast_scr49_isr (49)
{
    if((AITC_FIPNDH & 0x00020000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00020000;		// clear the bit in the force reg.
}

void   fast_scr16_isr(void)	// fast_scr16_isr (16)
{
    if((AITC_FIPNDL & 0x00010000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00010000;		// clear the bit in the force reg.
    gFastInt16flag = 1;
}

void   fast_scr48_isr(void)	// fast_scr48_isr (48)
{
    if((AITC_FIPNDH & 0x00010000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00010000;		// clear the bit in the force reg.
}

void   fast_scr15_isr(void)	// fast_scr15_isr (15)
{
    if((AITC_FIPNDL & 0x00008000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00008000;		// clear the bit in the force reg.
}

void   fast_scr47_isr(void)	// fast_scr47_isr (47)
{
    if((AITC_FIPNDH & 0x00008000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00008000;		// clear the bit in the force reg.
}

void   fast_scr14_isr(void)	// fast_scr14_isr (14)
{
    if((AITC_FIPNDL & 0x00004000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00004000;		// clear the bit in the force reg.
}

void   fast_scr46_isr(void)	// fast_scr46_isr (46)
{
    if((AITC_FIPNDH & 0x00004000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00004000;		// clear the bit in the force reg.
}

void   fast_scr13_isr(void)	// fast_scr13_isr (13)
{
    if((AITC_FIPNDL & 0x00002000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00002000;		// clear the bit in the force reg.
}

void   fast_scr45_isr(void)	// fast_scr45_isr (45)
{
    if((AITC_FIPNDH & 0x00002000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00002000;		// clear the bit in the force reg.
}

void   fast_scr12_isr(void)	// fast_scr12_isr (12)
{
    if((AITC_FIPNDL & 0x00001000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00001000;		// clear the bit in the force reg.
}

void   fast_scr44_isr(void)	// fast_scr44_isr (44)
{
    if((AITC_FIPNDH & 0x00001000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00001000;		// clear the bit in the force reg.
}

void   fast_scr11_isr(void)	// fast_scr11_isr (11)
{
    if((AITC_FIPNDL & 0x00000800) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000800;		// clear the bit in the force reg.
}

void   fast_scr43_isr(void)	// fast_scr43_isr (43)
{
    if((AITC_FIPNDH & 0x00000800) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000800;		// clear the bit in the force reg.
}

void   fast_scr10_isr(void)	// fast_scr10_isr (10)
{
    if((AITC_FIPNDL & 0x00000400) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000400;		// clear the bit in the force reg.
}

void   fast_scr42_isr(void)	// fast_scr42_isr (42)
{
    if((AITC_FIPNDH & 0x00000400) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000400;		// clear the bit in the force reg.
}

void   fast_scr09_isr(void)	// fast_scr09_isr  (9)
{
    if((AITC_FIPNDL & 0x00000200) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000200;		// clear the bit in the force reg.
}

void   fast_scr41_isr(void)	// fast_scr41_isr (41)
{
    if((AITC_FIPNDH & 0x00000200) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000200;		// clear the bit in the force reg.
}

void   fast_scr08_isr(void)	// fast_scr08_isr  (8)
{
    if((AITC_FIPNDL & 0x00000100) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000100;		// clear the bit in the force reg.
    gFastInt8flag = 1;
}

void   fast_scr40_isr(void)	// fast_scr40_isr (40)
{
    if((AITC_FIPNDH & 0x00000100) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000100;		// clear the bit in the force reg.
}

void   fast_scr07_isr(void)	// fast_scr07_isr  (7)
{
    if((AITC_FIPNDL & 0x0000080) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x0000080;		// clear the bit in the force reg.
}

void   fast_scr39_isr(void)	// fast_scr39_isr (39)
{
    if((AITC_FIPNDH & 0x00000080) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000080;		// clear the bit in the force reg.
}

void   fast_scr06_isr(void)	// fast_scr06_isr  (6)
{
    if((AITC_FIPNDL & 0x00000040) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000040;		// clear the bit in the force reg.
}

void   fast_scr38_isr(void)	// fast_scr38_isr (38)
{
    if((AITC_FIPNDH & 0x00000040) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000040;		// clear the bit in the force reg.
}

void   fast_scr05_isr(void)	// fast_scr05_isr  (5)
{
    if((AITC_FIPNDL & 0x00000020) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000020;		// clear the bit in the force reg.
}

void   fast_scr37_isr(void)	// fast_scr37_isr (37)
{
    if((AITC_FIPNDH & 0x00000020) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000020;		// clear the bit in the force reg.
}

void   fast_scr04_isr(void)	// fast_scr04_isr  (4)
{
    if((AITC_FIPNDL & 0x00000010) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000010;		// clear the bit in the force reg.
    gFastInt4flag = 1;

}

void   fast_scr36_isr(void)	// fast_scr36_isr (36)
{
    if((AITC_FIPNDH & 0x00000010) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000010;		// clear the bit in the force reg.
}

void   fast_scr03_isr(void)	// fast_scr03_isr  (3)
{
	if((AITC_FIPNDL & 0x00000008) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000008;		// clear the bit in the force reg.
}

void   fast_scr35_isr(void)	// fast_scr35_isr (35)
{
    if((AITC_FIPNDH & 0x00000008) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000008;		// clear the bit in the force reg.
}

void   fast_scr02_isr(void)	// fast_scr02_isr  (2)
{
    if((AITC_FIPNDL & 0x00000004) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000004;		// clear the bit in the force reg.
    gFastInt2flag = 1;
}

void   fast_scr34_isr(void)	// fast_scr34_isr (34)
{
    if((AITC_FIPNDH & 0x00000004) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000004;		// clear the bit in the force reg.
}

void   fast_scr01_isr(void)	// fast_scr01_isr  (1)
{
    if((AITC_FIPNDL & 0x00000002) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000002;		// clear the bit in the force reg.
    gFastInt1flag = 1;
}

void   fast_scr33_isr(void)	// fast_scr33_isr (33)
{
    if((AITC_FIPNDH & 0x00000002) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000002;		// clear the bit in the force reg.
}


void   fast_scr32_isr(void)	// fast_scr32_isr (32)
{
    if((AITC_FIPNDH & 0x00000001) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000001;		// clear the bit in the force reg.
    gFastInt32flag = 1;
}

void   fast_scr00_isr(void)	// fast_scr00_isr  (0)
{
    if((AITC_FIPNDL & 0x00000001) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000001;		// clear the bit in the force reg.
    gFastInt0flag = 1;
}

/*************************/
/* Normal Interrupt ISRs */
/*************************/

void   norm_scr63_isr(void)	// norm_scr63_isr (63)
{
    if((AITC_NIPNDH & 0x80000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY7>>28)&0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x80000000;		// clear the bit in the force reg.
    gNormInt63flag = 1;

}

void   norm_scr62_isr(void)	// norm_scr62_isr (62)
{
    if((AITC_NIPNDH & 0x40000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY7>>24)&0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x40000000;		// clear the bit in the force reg.
    gNormInt62flag = 1;

}

void   norm_scr61_isr(void)	// norm_scr61_isr (61)
{
    if((AITC_NIPNDH & 0x20000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY7>>20)&0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x20000000;		// clear the bit in the force reg.
    gNormInt61flag = 1;

}

void   norm_scr60_isr(void)	// norm_scr60_isr (60)
{
    if((AITC_NIPNDH & 0x10000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY7>>16)&0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x10000000;		// clear the bit in the force reg.

}

void   norm_scr59_isr(void)	// norm_scr59_isr (59)
{
    if((AITC_NIPNDH & 0x08000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY7>>12)&0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x08000000;		// clear the bit in the force reg.
}

void   norm_scr58_isr(void)	// norm_scr58_isr (58)
{
    if((AITC_NIPNDH & 0x04000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY7>>8)&0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x04000000;		// clear the bit in the force reg.

}

void   norm_scr57_isr(void)	// norm_scr57_isr (57)
{
    if((AITC_NIPNDH & 0x02000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY7>>4)&0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x02000000;		// clear the bit in the force reg.

}

void   norm_scr56_isr(void)	// norm_scr56_isr (56)
{
    if((AITC_NIPNDH & 0x01000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if((AITC_NIPRIORITY7 & 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x01000000;		// clear the bit in the force reg.

}

void   norm_scr55_isr(void)	// norm_scr55_isr (55)
{
    if((AITC_NIPNDH & 0x00800000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6>>28)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00800000;		// clear the bit in the force reg.

}

void   norm_scr54_isr(void)	// norm_scr54_isr (54)
{
    if((AITC_NIPNDH & 0x00400000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6>>24)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00400000;		// clear the bit in the force reg.

}

void   norm_scr53_isr(void)	// norm_scr53_isr (53)
{
    if((AITC_NIPNDH & 0x00200000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6>>20)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00200000;		// clear the bit in the force reg.

}

void   norm_scr52_isr(void)	// norm_scr52_isr (52)
{
    if((AITC_NIPNDH & 0x00100000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6>>16)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00100000;		// clear the bit in the force reg.

}

void   norm_scr51_isr(void)	// norm_scr51_isr (51)
{
    if((AITC_NIPNDH & 0x00080000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6>>12)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00080000;		// clear the bit in the force reg.

}

void   norm_scr50_isr(void)	// norm_scr50_isr (50)
{
    if((AITC_NIPNDH & 0x00040000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6>>8)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00040000;		// clear the bit in the force reg.

}

void   norm_scr49_isr(void)	// norm_scr49_isr (49)
{
    if((AITC_NIPNDH & 0x00020000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6>>4)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00020000;		// clear the bit in the force reg.

}

void   norm_scr48_isr(void)	// norm_scr48_isr (48)
{
    if((AITC_NIPNDH & 0x00010000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY6)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00010000;		// clear the bit in the force reg.

}

void   norm_scr47_isr(void)	// norm_scr47_isr (47)
{
    if((AITC_NIPNDH & 0x00008000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5>>28)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00008000;		// clear the bit in the force reg.

}

void   norm_scr46_isr(void)	// norm_scr46_isr (46)
{
    if((AITC_NIPNDH & 0x00004000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5>>24)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00004000;		// clear the bit in the force reg.

}

void   norm_scr45_isr(void)	// norm_scr45_isr (45)
{
    if((AITC_NIPNDH & 0x00002000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5>>20)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00002000;		// clear the bit in the force reg.

}


void   norm_scr44_isr(void)	// norm_scr44_isr (44)
{
    if((AITC_NIPNDH & 0x00001000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5>>16)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00001000;

}


void   norm_scr43_isr(void)	// norm_scr43_isr (43)
{
    if((AITC_NIPNDH & 0x00000800) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5>>12)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00000800;		// clear the bit in the force reg.

}

void   norm_scr42_isr(void)	// norm_scr42_isr (42)
{
    if((AITC_NIPNDH & 0x00000400) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5>>8)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00000400;		// clear the bit in the force reg.

}

void   norm_scr41_isr(void)	// norm_scr41_isr (41)
{
    if((AITC_NIPNDH & 0x00000200) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5>>4)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00000200;		// clear the bit in the force reg.

}


void   norm_scr40_isr(void)	// norm_scr40_isr (40)
{
    if((AITC_NIPNDH & 0x00000100) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY5)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00000100;		// clear the bit in the force reg.

}

void   norm_scr39_isr(void)	// norm_scr39_isr (39)
{
    if((AITC_NIPNDH & 0x00000080) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY4>>28)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCH &= ~0x00000080;		// clear the bit in the force reg.

}

void   norm_scr38_isr(void)	// norm_scr38_isr (38)
{
    if((AITC_NIPNDH & 0x00000040) == 0)	// verify the pending bit is set
    {
        	gFailPendingCount++;
    }	
	
	if(((AITC_NIPRIORITY4>>24)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000040;		// clear the bit in the force reg.

}

void   norm_scr37_isr(void)	// norm_scr37_isr (37)
{
    if((AITC_NIPNDH & 0x00000020) == 0)	// verify the pending bit is set
    {
        	gFailPendingCount++;
    }	
    
    if(((AITC_NIPRIORITY4>>20)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000020;		// clear the bit in the force reg.

}

void   norm_scr36_isr(void)	// norm_scr36_isr (36)
{
    if((AITC_NIPNDH & 0x00000010) == 0)	// verify the pending bit is set
    {
        	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY4>>16)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000010;		// clear the bit in the force reg.

}

void   norm_scr35_isr(void)	// norm_scr35_isr (35)
{
    if((AITC_NIPNDH & 0x00000008) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY4>>12)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000008;		// clear the bit in the force reg.

}

void   norm_scr34_isr(void)	// norm_scr34_isr (34)
{
    if((AITC_NIPNDH & 0x00000004) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY4>>8)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000004;		// clear the bit in the force reg.
}

void   norm_scr33_isr(void)	// norm_scr33_isr (33)
{
    if((AITC_NIPNDH & 0x00000002) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY4>>4)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000002;		// clear the bit in the force reg.
}

void   norm_scr32_isr(void)	// norm_scr32_isr (32)
{
    if((AITC_NIPNDH & 0x00000001) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY4)& 0xF)!=(AITC_NIVECSR & 0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCH &= ~0x00000001;		// clear the bit in the force reg.
    gNormInt32flag = 1;				// set flag
}

void   norm_scr31_isr(void)	// norm_scr31_isr (31)
{
    if((AITC_NIPNDL & 0x80000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY3>>28)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
	
    *(p_uint32_t) AITC_INTFRCL &= ~0x80000000;		// clear the bit in the force reg.
}

void   norm_scr30_isr(void)	// norm_scr30_isr (30)
{
    if((AITC_NIPNDL & 0x40000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY3>>24)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x40000000;		// clear the bit in the force reg.

}

void   norm_scr29_isr(void)	// norm_scr29_isr (29)
{
    if((AITC_NIPNDL & 0x20000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY3>>20)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x20000000;		// clear the bit in the force reg.
}

void   norm_scr28_isr(void)	// norm_scr28_isr (28)
{
    if((AITC_NIPNDL & 0x10000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	
    
	if(((AITC_NIPRIORITY3>>16)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x10000000;		// clear the bit in the force reg.
}

void   norm_scr27_isr(void)	// norm_scr27_isr (27)
{
    if((AITC_NIPNDL & 0x08000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY3>>12)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x08000000;		// clear the bit in the force reg.

}

void   norm_scr26_isr(void)	// norm_scr26_isr (26)
{
    if((AITC_NIPNDL & 0x04000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY3>>8)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x04000000;		// clear the bit in the force reg.

}

void   norm_scr25_isr(void)	// norm_scr25_isr (25)
{
    if((AITC_NIPNDL & 0x02000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY3>>4)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x02000000;		// clear the bit in the force reg.
}

void   norm_scr24_isr(void)	// norm_scr24_isr (24)
{
    if((AITC_NIPNDL & 0x01000000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY3)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x01000000;		// clear the bit in the force reg.
}

void   norm_scr23_isr(void)	// norm_scr23_isr (23)
{
    if((AITC_NIPNDL & 0x00800000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2>>28)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00800000;		// clear the bit in the force reg.
}

void   norm_scr22_isr(void)	// norm_scr22_isr (22)
{
    if((AITC_NIPNDL & 0x00400000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2>>24)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00400000;		// clear the bit in the force reg.
}

void   norm_scr21_isr(void)	// norm_scr21_isr (21)
{
    if((AITC_NIPNDL & 0x00200000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2>>20)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00200000;		// clear the bit in the force reg.
}

void   norm_scr20_isr(void)	// norm_scr20_isr (20)
{
    if((AITC_NIPNDL & 0x00100000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2>>16)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00100000;		// clear the bit in the force reg.
}

void   norm_scr19_isr(void)	// norm_scr19_isr (19)
{
    if((AITC_NIPNDL & 0x00080000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2>>12)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00080000;		// clear the bit in the force reg.
}

void   norm_scr18_isr(void)	// norm_scr18_isr (18)
{
    if((AITC_NIPNDL & 0x00040000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2>>8)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}


    *(p_uint32_t) AITC_INTFRCL &= ~0x00040000;		// clear the bit in the force reg.
}

void   norm_scr17_isr(void)	// norm_scr17_isr (17)
{
    if((AITC_NIPNDL & 0x00020000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2>>4)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00020000;			// clear the bit in the force reg.
    //gNormInt17flag = 1;				// set flag
	printf("IRQ source 17 is success\n");
}

void   norm_scr16_isr(void)	// norm_scr16_isr (16)
{
    if((AITC_NIPNDL & 0x00010000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY2)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00010000;			// clear the bit in the force reg.
    gNormInt16flag = 1;				// set flag
	printf("IRQ source 16 is success\n");	
}

void   norm_scr15_isr(void)	// norm_scr15_isr (15)
{
    if((AITC_NIPNDL & 0x00008000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1>>28)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00008000;			// clear the bit in the force reg.
    gNormInt15flag = 1;				// set flag
	printf("IRQ source 15 is success\n");	
}

void   norm_scr14_isr(void)	// norm_scr14_isr (14)
{
    if((AITC_NIPNDL & 0x00004000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1>>24)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}
    *(p_uint32_t) AITC_INTFRCL &= ~0x00004000;			// clear the bit in the force reg.
    gNormInt14flag = 1;				// set flag
	printf("IRQ source 14 is success\n");
}

void   norm_scr13_isr(void)	// norm_scr13_isr (13)
{
    if((AITC_NIPNDL & 0x00002000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1>>20)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00002000;			// clear the bit in the force reg.
    gNormInt13flag = 1;				// set flag
	printf("IRQ source 13 is success\n");
}

void   norm_scr12_isr(void)	// norm_scr12_isr (12)
{
    if((AITC_NIPNDL & 0x00001000) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1>>16)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00001000;			// clear the bit in the force reg.
    gNormInt12flag = 1;				// set flag
	printf("IRQ source 12 is success\n");
}

void   norm_scr11_isr(void)	// norm_scr11_isr (11)
{
    if((AITC_NIPNDL & 0x00000800) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1>>12)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000800;			// clear the bit in the force reg.
    gNormInt11flag = 1;				// set flag
	printf("IRQ source 11 is success\n");

}

void   norm_scr10_isr(void)	// norm_scr10_isr (10)
{
    if((AITC_NIPNDL & 0x00000400) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1>>8)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000400;		// clear the bit in the force reg.
    gNormInt10flag = 1;			// set flag
	printf("IRQ source 10 is success\n");	
}

void   norm_scr09_isr(void)	// norm_scr09_isr  (9)
{
    if((AITC_NIPNDL & 0x00000200) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1>>4)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000200;		// clear the bit in the force reg.
    gNormInt9flag = 1;			// set flag
	printf("IRQ source 9 is success\n");
}

void   norm_scr08_isr(void)	// norm_scr08_isr  (8)
{
    if((AITC_NIPNDL & 0x00000100) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY1)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000100;		// clear the bit in the force reg.
    gNormInt8flag = 1;			// set flag
	printf("IRQ source 8 is success\n");
}

void   norm_scr07_isr(void)	// norm_scr07_isr  (7)
{
    if((AITC_NIPNDL & 0x00000080) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0>>28)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000080;		// clear the bit in the force reg.
    gNormInt7flag = 1;			// set flag
	printf("IRQ source 7 is success\n");
}

void   norm_scr06_isr(void)	// norm_scr06_isr  (6)
{
    if((AITC_NIPNDL & 0x00000040) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0>>24)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000040;		// clear the bit in the force reg.
    gNormInt6flag = 1;				// set flag
	printf("IRQ source 6 is success\n");
}

void   norm_scr05_isr(void)	// norm_scr05_isr  (5)
{
    if((AITC_NIPNDL & 0x00000020) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0>>20)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000020;		// clear the bit in the force reg.
    gNormInt5flag = 1;				// set flag
	printf("IRQ source 5 is success\n");
}

void   norm_scr04_isr(void)	// norm_scr04_isr  (4)
{
    if((AITC_NIPNDL & 0x00000010) == 0)	// verify the pending bit is set
    {
        	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0>>16)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000010;	// clear the bit in the force reg.
    gNormInt4flag = 1;				// set flag
	printf("IRQ source 4 is success\n");
}

void   norm_scr03_isr(void)	// norm_scr03_isr  (3)
{
    if((AITC_NIPNDL & 0x00000008) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0>>12)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000008;		// clear the bit in the force reg.
    gNormInt3flag = 1;				// set flag
	printf("IRQ source 3 is success\n");
}

void   norm_scr02_isr(void)	// norm_scr02_isr  (2)
{
    if((AITC_NIPNDL & 0x00000004) == 0)	// verify the pending bit is set
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0>>8)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000004;		// clear the bit in the force reg.
    gNormInt2flag = 1;				// set flag
    printf("IRQ source 2 is success\n");
}

void   norm_scr01_isr(void)	// norm_scr01_isr  (1)
{
    if((AITC_NIPNDL & 0x00000002) == 0)
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0>>4)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000002;		// clear the bit in the force reg.
    gNormInt1flag = 1;				// set flag
	printf("IRQ source 1 is success\n");		
}

void   norm_scr00_isr(void)	// norm_scr00_isr  (0)
{
    if((AITC_NIPNDL & 0x00000001) == 0)
    {
    	gFailPendingCount++;
    }	

	if(((AITC_NIPRIORITY0)&0xF)!=(AITC_NIVECSR&0xF)) //verify interrupt priority
	{
		gFailPriorityCount++;
	}

    *(p_uint32_t) AITC_INTFRCL &= ~0x00000001;		// clear the bit in the force reg.
    gNormInt0flag = 1;			// set flag
    printf("IRQ source 0 is success\n");
}


