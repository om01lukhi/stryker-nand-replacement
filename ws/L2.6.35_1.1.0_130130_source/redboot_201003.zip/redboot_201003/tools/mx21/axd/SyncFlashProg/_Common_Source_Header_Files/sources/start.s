	EXPORT __main
	IMPORT main
	IMPORT |Image$$ZI$$Base|
	IMPORT |Image$$ZI$$Limit|
	AREA	Init, CODE, READONLY

	CODE32
	ENTRY
__main
	LDR sp, = |Image$$ZI$$Limit|
	B	main	
        END
	