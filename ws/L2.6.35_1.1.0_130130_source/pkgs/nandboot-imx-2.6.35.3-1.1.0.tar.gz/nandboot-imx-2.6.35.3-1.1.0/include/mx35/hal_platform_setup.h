/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef HAL_PLATFORM_SETUP_H_
#define HAL_PLATFORM_SETUP_H_

#include "mx35_3stack.h"

#if !defined(__ASSEMBLER__)

#define SETUP_IOMUX()  setup_iomux()
#define NFC_V1_2	/* V1.2 is an arbitrary designation for the MX25/MX35 NFC */

static void setup_iomux(void)
{
	/* enable UART1 IPG clock */
	_reg_MXC_CCM_CGR2 |= 0x00010000;
	/* enable UART PER clock */
	/* enable I2C PER clock */

	_reg_MXC_CCM_COSR = 0x7D000032;

	_reg_MXC_CCM_PDR0 = 0x00801000;

	_reg_MXC_CCM_CGR0 |= 0xffffffff;
	_reg_MXC_CCM_CGR1 |= 0xffffffff;
	_reg_MXC_CCM_CGR2 |= 0xffffffff;
	_reg_MXC_CCM_CGR3 |= 0xffffffff;

	/* I2C init */
	writel(0x10, MXC_IOMUXC_BASE_ADDR + 0x110);
	writel(0x10, MXC_IOMUXC_BASE_ADDR + 0x114);
	writel(0x1E4, MXC_IOMUXC_BASE_ADDR + 0x554);
	writel(0x1E4, MXC_IOMUXC_BASE_ADDR + 0x558);

	writew(0, MXC_I2C_BASE_ADDR + I2C_I2CR);
	writew(I2C_I2CR_IEN, MXC_I2C_BASE_ADDR + I2C_I2CR);
	writew(0x3e, MXC_I2C_BASE_ADDR + I2C_IFDR);

	// UART1
	/*RXD1*/
	writel(0, MXC_IOMUXC_BASE_ADDR + 0x188);
	writel(0x1E0, MXC_IOMUXC_BASE_ADDR + 0x55C);

	/*TXD1*/
	writel(0, MXC_IOMUXC_BASE_ADDR + 0x18C);
	writel(0x40, MXC_IOMUXC_BASE_ADDR + 0x560);

	/*RTS1*/
	writel(0, MXC_IOMUXC_BASE_ADDR + 0x190);
	writel(0x1E0, MXC_IOMUXC_BASE_ADDR + 0x564);

	/*CTS1*/
	writel(0, MXC_IOMUXC_BASE_ADDR + 0x194);
	writel(0x40, MXC_IOMUXC_BASE_ADDR + 0x568);
}

#include "hal_mm.h"
/*
 * hal_mmu_init() based on Redboot
 * Copyright (C) 1998, 1999, 2000, 2001, 2002 Red Hat, Inc.
 */
static void hal_mmu_init(void)
{
	unsigned long ttb_base = RAM_BANK0_BASE + 0x02000000;
	unsigned long i;
	static int zeros[8];

	/*
	 * Set the TTB register
	 */
	asm volatile ("mcr  p15,0,%0,c2,c0,0" : : "r"(ttb_base) /*:*/);

	/*
	 * Set the Domain Access Control Register
	 */
	i = ARM_ACCESS_DACR_DEFAULT;
	asm volatile ("mcr  p15,0,%0,c3,c0,0" : : "r"(i) /*:*/);

	/*
	 * First clear all TT entries - ie Set them to Faulting
	 */
	asmset_8w((void *)ttb_base, (void *)zeros, ARM_FIRST_LEVEL_PAGE_TABLE_SIZE / 32);

#define X		X_ARM_MMU_SECTION
#define NO_CACHE	ARM_UNCACHEABLE
#define CACHE		ARM_CACHEABLE
#define BUFF		ARM_BUFFERABLE
#define NO_BUFF		ARM_UNBUFFERABLE
#define RW		ARM_ACCESS_PERM_RW_RW
#define SECTION_BASE_ADDR(addr)	    (((unsigned long) addr) >> 20)
	/*--------------------------------------------------------------------------------------------------------------------------------------------------*/
	/*Physical				Virtual					    Size	    Attributes			Functions	    */
	/*Base					Base					    MB		cached?  buffered? r/w?				    */
	/*xxx00000				xxx00000												    */
	/*--------------------------------------------------------------------------------------------------------------------------------------------------*/
	X(SECTION_BASE_ADDR(SDRAM_BASE_ADDR),   SECTION_BASE_ADDR(SDRAM_BASE_ADDR),	    (SDRAM_SIZE/2) >> 20,	CACHE,    BUFF,    RW); /* SDRAM 64M 0x80000000 ---> 0x80000000 */
	X(SECTION_BASE_ADDR(SDRAM_BASE_ADDR),	SECTION_BASE_ADDR(SDRAM_BASE_ADDR_VIRT),    (SDRAM_SIZE/2) >> 20,	CACHE,    BUFF,    RW); /* SDRAM 64M 0x80000000 ---> 0xC0000000 where btcs is expected */	
	X(SECTION_BASE_ADDR(NFC_BASE_ADDR),	SECTION_BASE_ADDR(NFC_BASE_ADDR_VIRT),	    SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* NFC */
	X(SECTION_BASE_ADDR(AIPS1_BASE_ADDR),   SECTION_BASE_ADDR(AIPS1_BASE_ADDR_VIRT),    SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* AIPS1 to match kernel mapping */
	X(SECTION_BASE_ADDR(AIPS2_BASE_ADDR),   SECTION_BASE_ADDR(AIPS2_BASE_ADDR_VIRT),    SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* AIPS2 to match kernel mapping */
	X(SECTION_BASE_ADDR(ASIC_BASE_ADDR),    SECTION_BASE_ADDR(ASIC_BASE_ADDR_VIRT),     SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* ASIC mapping */
	X(SECTION_BASE_ADDR(L2CC_BASE_ADDR),    SECTION_BASE_ADDR(L2CC_BASE_ADDR_VIRT),     SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* L2CC mapping */
}

static void hal_mmu_enable(void)
{
asm("						\n\
	ldr r2, =10f				\n\
	mrc p15, 0, r1, c1, c0, 0		\n\
	orr r1, r1, #7                          \n\
	orr r1, r1, #0x1000                     \n\
	mcr p15, 0, r1, c1, c0, 0		\n\
	mov pc,r2				\n\
	nop					\n\
	nop					\n\
	nop					\n\
10:						\n\
	nop					\n\
");
}

static void hal_mmu_disable(void)
{
asm("						\n\
	mov r0, #0				\n\
	mcr p15, 0, r0, c7, c14, 0		\n\
	mcr p15, 0, r0, c7, c10, 4		\n\
        mcr p15, 0, r0, c7, c5, 0		\n\
	mrc p15, 0, r0, c1, c0, 0		\n\
	bic r0, r0, #0x7			\n\
	bic r0, r0, #0x1000			\n\
	mcr p15, 0, r0, c1, c0, 0		\n\
	nop					\n\
	nop					\n\
	nop					\n\
");
}

#endif

#if defined(__ASSEMBLER__)
#if !defined(NOHALASM)  /* Added for linking */
/*
 * Platform setup macro
 */
#define PLATFORM_SETUP1 _platform_setup1

/* Patterned after redboot hal_platform_setup.h
 * This macro represents the initial startup code for the platform
 * r11 is reserved to contain chip rev info in this file
*/
    .macro  _platform_setup1
MX35_SETUP_START:
	/* set the cpu to SVC32 mode */
	mrs     r0,cpsr
	bic     r0,r0,#0x1f
	orr     r0,r0,#0xd3
	msr     cpsr,r0

	/* Disable Power Down Counter of WDOG */
	ldr r0, =WDOG_BASE_ADDR
	mov r1, #0
	strh r1, [r0, #8]

	/* invalidate I/D cache/TLB and drain write buffer */
	mov r0, #0
	mcr 15, 0, r0, c7, c7, 0        /* invalidate I cache and D cache */
	mcr 15, 0, r0, c8, c7, 0        /* invalidate TLBs */
	mcr 15, 0, r0, c7, c10, 4       /* Drain the write buffer */

	/* Also setup the Peripheral Port Remap register inside the core */
	ldr r0, =0x40000015		/* start from AIPS 2GB region */
	mcr p15, 0, r0, c15, c2, 4

	init_l2cc
	init_aips
	init_clock
	setup_sdram_ddr
	init_debug_board

    .endm   /* _platform_setup1 */

    .macro init_clock
	ldr r0, =CCM_BASE_ADDR
	ldr r1, =0x00801000
	str r1, [r0, #CLKCTL_PDR0]

    .endm /* init_clock */

    .macro init_debug_board
	ldr r0, =CS5_CTL_BASE_ADDR
	ldr r1, =0x0000D843
	str r1, [r0, #0x00]
	ldr r1, =0x22252521
	str r1, [r0, #0x04]
	ldr r1, =0x22220A00
	str r1, [r0, #0x08]
    .endm /* init_debug_board */

    .macro init_aips
	/* setup AIPS1 and AIPS2 */
	ldr r0, =AIPS1_BASE_ADDR
	ldr r1, =0x77777777
	str r1, [r0]	/* MPR_1 */
	str r1, [r0, #4]  /* MPR_2 */
	mov r1, #0
	str r1, [r0, #0x40]
	str r1, [r0, #0x44]
	str r1, [r0, #0x48]
	str r1, [r0, #0x4C]
	str r1, [r0, #0x50]

	ldr r0, =AIPS2_BASE_ADDR
	ldr r1, =0x77777777
	str r1, [r0]	/* MPR_1 */
	str r1, [r0, #4]  /* MPR_2 */
	mov r1, #0
	str r1, [r0, #0x40]
	str r1, [r0, #0x44]
	str r1, [r0, #0x48]
	str r1, [r0, #0x4C]
	str r1, [r0, #0x50]
    .endm /* init_aipi */

    .macro init_l2cc
	/*** L2 Cache setup/invalidation/disable ***/
	/* Disable L2 cache first */
	mov r0, #L2CC_BASE_ADDR
	ldr r2, [r0, #L2CC_CACHE_CTL]
	bic r2, r2, #0x1
	str r2, [r0, #L2CC_CACHE_CTL]
	/*
	 * Configure L2 Cache:
	 * - 128k size(16k way)
	 * - 8-way associativity
	 * - 0 ws TAG/VALID/DIRTY
	 * - 4 ws DATA R/W
	 */
	ldr r1, [r0, #L2CC_CACHE_AUX_CTL]
	and r1, r1, #0xFE000000
	ldr r2, =0x00030024
	orr r1, r1, r2
	str r1, [r0, #L2CC_CACHE_AUX_CTL]

	/* Invalidate L2 */
	mov r1, #0x000000FF
	str r1, [r0, #L2CC_CACHE_INV_WAY]
L2_loop:
	/* Poll Invalidate By Way register */
	ldr r2, [r0, #L2CC_CACHE_INV_WAY]
	cmp r2, #0
	bne L2_loop

    .endm /* init_l2cc */

    .macro setup_sdram_ddr
	/* setmem /32 0xB8001010 =0x00000304 */
	ldr r0, =ESDCTL_BASE_ADDR
	ldr r1, =0x00000304
	str r1, [r0, #ESDMISC]

	/* ESD_ESDCFG0 : set timing paramters */
	/* setmem /32 0xB8001004 =0x007ffC2f */
	ldr r1, =0x007ffC2f
	str r1, [r0, #ESDCFG0]

	/* ESD_ESDCTL0 : select Prechare-All mode */
	/* setmem /32 0xB8001000 =0x92220000 */
	ldr r1, =0x92220000
	str r1, [r0, #ESDCTL0]

	/* DDR2 : Prechare-All */
	/* setmem /32 0x80000400 =0x12345678 */
	ldr r2, =0x80000400
	ldr r1, =0x12345678
	str r1, [r2]

	/* ESD_ESDCTL0 : select Load-Mode-Register mode */
	/* setmem /32 0xB8001000 =0xB2220000 */
	ldr r1, =0xB2220000
	str r1, [r0, #ESDCTL0]

	/* DDR2 : Load reg EMR2 */
	/* setmem /8 0x84000000 =0xda */
	ldr r2, =0x84000000
	ldr r1, =0xda
	strb r1, [r2]

	/* DDR2 : Load reg EMR3 */
	/* setmem /8 0x86000000 =0xda */
	ldr r2, =0x86000000
	strb r1, [r2]

	/* DDR2 : Load reg EMR1 -- enable DLL */
	/* setmem /8 0x82000400 =0xda */
	ldr r2, =0x82000400
	strb r1, [r2]

	/* DDR2 : Load reg MR -- reset DLL */
	/* setmem /8 0x80000333 =0xda */
	ldr r2, =0x80000333
	strb r1, [r2]

	/* ESD_ESDCTL0 : select Prechare-All mode */
	/* setmem /32 0xB8001000 =0x92220000 */
	ldr r1, =0x92220000
	str r1, [r0, #ESDCTL0]

	/* DDR2 : Prechare-All */
	/* setmem /8 0x80000400 =0x12345678 */
	ldr r2, =0x80000400
	ldr r1, =0x12345678
	str r1, [r2]

	/* ESD_ESDCTL0 : select Manual-Refresh mode */
	/* setmem /32 0xB8001000 =0xA2220000 */
	ldr r1, =0xA2220000
	str r1, [r0, #ESDCTL0]

	/* DDR2 : Manual-Refresh 2 times */
	/* setmem /32 0x80000000 =0x87654321 */
	/* setmem /32 0x80000000 =0x87654321 */
	ldr r2, =0x80000000
	ldr r1, =0x87654321
	str r1, [r2]
	str r1, [r2]

	/* ESD_ESDCTL0 : select Load-Mode-Register mode */
	/* setmem /32 0xB8001000 =0xB2220000 */
	ldr r1, =0xB2220000
	str r1, [r0, #ESDCTL0]

	/* DDR2 : Load reg MR -- CL=3, BL=8, end DLL reset */
	/* setmem /8 0x80000233 =0xda */
	ldr r2, =0x80000233
	ldr r1, =0xda
	strb r1, [r2]

	/* DDR2 : Load reg EMR1 -- OCD default */
	/* setmem /8 0x82000780 =0xda; */
	ldr r2, =0x82000780
	strb r1, [r2]

	/* DDR2 : Load reg EMR1 -- OCD exit */
	/*setmem /8 0x82000400 =0xda */
	ldr r2, =0x82000400
	strb r1, [r2]

	/* ESD_ESDCTL0 : select normal-operation mode; DSIZ=32-bit,
	 * BL=8, COL=10-bit, ROW=13-bit; disable PWT & PRCT;
	 * disable Auto-Refresh */
	/* setmem /32 0xB8001000 =0x82220080 */
	ldr r1, =0x82220080
	str r1, [r0, #ESDCTL0]

	/* # ESD_ESDCTL0 : enable Auto-Refresh */
	/* setmem /32 0xB8001000 =0x82228080 */
	ldr r1, =0x82228080
	str r1, [r0, #ESDCTL0]

	/* # ESD_ESDCTL1 : enable Auto-Refresh */
	/* setmem /32 0xB8001008 =0x00002000 */
	ldr r1, =0x00002000
	str r1, [r0, #ESDCTL1]

	/* Then you can make force measure with the dedicated bit (Bit 7 at ESDMISC) */
	/* setmem /32 0xB8001010 =0x00000384 */
	ldr r1, =0x00000384
	str r1, [r0, #ESDMISC]
	mov r2, #200

	/* now clear the force measurement bit */
	/* setmem /32 0xB8001010 =0x00000304 */
	ldr r1, =0x00000304
	str r1, [r0, #ESDMISC]

	/* dummy write to DDR memory to set DQS low */
	/* setmem /32 0x80000000 = 0x00000000 */
	ldr r2, =0x80000000
	mov r1, #0
	str r1, [r2]

    .endm   /* setup_sdram_ddr */

#endif  /* !defined(NOHALASM) */
#endif  /* defined(__ASSEMBLER__) */
#endif  /* HAL_PLATFORM_SETUP_H_ */
