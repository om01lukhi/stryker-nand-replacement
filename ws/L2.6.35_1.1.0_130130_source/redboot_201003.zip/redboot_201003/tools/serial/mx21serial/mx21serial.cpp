#include <conio.h>
#include "stdafx.h"
#include "stdio.h"
#include "stdlib.h"
#include <stdio.h>
#include <windows.h>
#include <ctype.h>
#include <string.h>
#include <time.h>
#include <io.h>
#include "mx21serial.h"

static int debug = 0;
static int action = ENUM_NULL;
const DATA_LEN = 1024 * 4;
static unsigned char scratch_buf[DATA_LEN]; 		// 16KB data

//                                cmd   |     addr     | width |  count   |    data      | end
unsigned char irom_readl[16]   = {1, 1,  _x, _x, _x, _x,  32,    0, 0, 0, 4,  0, 0, 0, 0,  0};
unsigned char irom_readw[16]   = {1, 1,  _x, _x, _x, _x,  16,    0, 0, 0, 2,  0, 0, 0, 0,  0};
unsigned char irom_readb[16]   = {1, 1,  _x, _x, _x, _x,  8,     0, 0, 0, 1,  0, 0, 0, 0,  0};
unsigned char irom_writel[16]  = {2, 2,  _x, _x, _x, _x,  32,    0, 0, 0, 4,  _x,_x,_x,_x, 0};
unsigned char irom_writew[16]  = {2, 2,  _x, _x, _x, _x,  16,    0, 0, 0, 2,  _x,_x,_x,_x, 0};
unsigned char irom_writeb[16]  = {2, 2,  _x, _x, _x, _x,  8,     0, 0, 0, 1,  _x,_x,_x,_x, 0};
unsigned char irom_status[16]  = {5, 5,  0,  0,  0,  0,   0,     0, 0, 0, 0,  0, 0, 0, 0,  0};
unsigned char irom_download[16]= {4, 4,  _x, _x, _x, _x,  0,    _x,_x,_x,_x,  0, 0, 0, 0,  END_RPT};
unsigned char irom_exec[16]    = {4, 4,  _x, _x, _x, _x,  0,     0, 0, 0, 0,  0, 0, 0, 0,  END_EXEC};
							//	  0	 1	  2	  3	 4	 5	  6		 7	8  9  10  11 12	13 14  15

struct reg_addr_val {
	unsigned long r_w;
	unsigned long addr;
	unsigned long val;
} mx21reg_initsys[] = {
	// ### AHB-Lite IP Interface
	{REG_WEITE, 0x10000000, 0x00040304},
	{REG_WEITE, 0x10020000, 0x00000000},
	{REG_WEITE, 0x10000004, 0xFFFBFCFB},
	{REG_WEITE, 0x10020004, 0xFFFFFFFF},
	{REG_WEITE, 0x10027020, 0x31084003},
	// # CS0 Initialization (Async Mode) 32-bit, ?? wait states              
	{REG_WEITE, 0xDF001000, 0x00000E01},
	{REG_WEITE, 0xDF001004, 0x00000E01},
	// # Setting for Memory Map IO Port
	// # CS1 Initialization (Async Mode)
	// # 16-bit, D0..15, ?? wait states
	{REG_WEITE, 0xDF001008, 0x00002000},
	{REG_WEITE, 0xDF00100C, 0x11118501},
	// # CSD0 Initialization (SDRAM)   
	{REG_WEITE, 0xDF000000, 0x92120300},
	// *** Issue Precharge all Command
	{REG_READ,  0xC0200000, 0},          
	// *** Set AutoRefresh Command
	{REG_WEITE, 0xDF000000, 0xA2120300},
	// *** Issue AutoRefresh Command
	{REG_READ,  0xC0000000, 0},
	{REG_READ,  0xC0000000, 0},
	{REG_READ,  0xC0000000, 0},
	{REG_READ,  0xC0000000, 0},
	{REG_READ,  0xC0000000, 0},
	{REG_READ,  0xC0000000, 0},
	{REG_READ,  0xC0000000, 0},
	{REG_READ,  0xC0000000, 0},
	// *** Set Mode Register
	{REG_WEITE, 0xDF000000, 0xB2120300},
	{REG_READ,  0xC0119800, 0},
	{REG_WEITE, 0xDF000000, 0x8212F339},
	// ### End of Memory Configuration
	{REG_WEITE, 0x1003F300, 0x00123056},
	// ### CSCR: FCLK=MPLL/1; HCLK=FCLK/4; #####(If MPLL==266MHz, FCLK=266MHz and HCLK=66MHz)
	{REG_WEITE, 0x10027000, 0x17000E07},
	// for flashing
	{REG_WEITE, SERIAL_DOWNLOAD_MAGIC_REG, SERIAL_DOWNLOAD_MAGIC},
	{REG_WEITE, SERIAL_DOWNLOAD_SRC_REG, SERIAL_DOWNLOAD_SRC_ADDR},
	{REG_WEITE, SERIAL_DOWNLOAD_TGT_REG, NULL},
	{REG_WEITE, SERIAL_DOWNLOAD_SZ_REG, NULL},
};

#define INIT_LOOP_COUNT		(sizeof(mx21reg_initsys) / sizeof(struct reg_addr_val))
#define SET_MAGIC_FOR_DOWNLOAD()	(mx21reg_initsys[INIT_LOOP_COUNT-4].val = 0)
#define SET_TGT_ADDR_FOR_FLASH(x)	(mx21reg_initsys[INIT_LOOP_COUNT-2].val = x)
#define SET_SIZE_FOR_FLASH(x)	(mx21reg_initsys[INIT_LOOP_COUNT-1].val = x)

int main(int argc, char* argv[])
{
	int port;
	unsigned long download = 0, result;
	char *file_name;
	char *port_name;
	HANDLE portH;
	FILE *fp;
	unsigned long total;
	unsigned long bytes_read = 0;

	if (argc == 1) {
		goto help_msg;
    }
	if (argc != 4 && argc != 5) {
		printf("Wrong number of arguments.\n");
		goto help_msg_short;
	}
    if (parse_cmd_line(argc, argv, &port, &download) != 0) {
		printf("Command parsing error\n");
		goto help_msg_short;
    }

	port_name = argv[1];
	file_name = argv[3];
	if (download >= SDRAM_BASE_ADDR && 
		download < (SDRAM_BASE_ADDR + SDRAM_SIZE)) {
		action = ENUM_DOWNLOAD;
		if (debug) printf("downloading to sdram ...\n");
	} else if (download >= CS0_BASE_ADDR && 
			   download < (CS0_BASE_ADDR + CS0_SIZE)) {
		action = ENUM_NOR;
	} else if (download >= NFC_BASE && 
			   download < (NFC_BASE + NFC_SIZE)) {
		action = ENUM_NAND;
		printf("programing to NAND flash is not supported yet\n");
		printf("nice try :<\n");
		exit (-1);
	} else {
		printf("Unknown address range. Assuming download ...\n");
	}

	// Open the serial port.
	if ((portH = Open_Port(port_name, CBR_115200)) == INVALID_HANDLE_VALUE) {
		printf("Error: %s is in use\n", port_name);
		return -1;
	}
	if (op_header(portH, irom_status, &result) != ROM_OK)
		goto func_out;

	if (debug) printf("status = 0x%08x '%s'\n", result, status_to_string(result));
	switch (action) {
	case ENUM_DOWNLOAD:
		SET_MAGIC_FOR_DOWNLOAD();
		if (config_reg(portH, mx21reg_initsys, INIT_LOOP_COUNT) != ROM_OK) {
			printf("config_reg(portH, mx21reg_initsys, INIT_LOOP_COUNT) failed\n");
			goto func_out;
		}
		printf("Downloading to SDRAM at 0x%x via %s. File: %s\n",
			   download, port_name, file_name);
		if (download_file(portH, file_name, download) != ROM_OK) {
			printf("download_file() failed at line %d\n", __LINE__);
			goto func_out;
		}
		// execute
		SET_ADDR(irom_exec, download);
		if (op_header(portH, irom_exec, &result) != ROM_OK) {
			printf("Failed to exec\n");
			goto func_out;
		}
		printf("\nJumping to 0x%08x\n", download);
		if (op_header(portH, irom_status, &result) != ROM_OK)
			goto func_out;
		break;
	case ENUM_NOR:
		SET_TGT_ADDR_FOR_FLASH(download);

		if ((fp = fopen(file_name,"rb")) == NULL) {
			printf("\nUnable to open file: %s\n", file_name);
			return ERR_FILE_NOT_OPEN;
		}

		if ((total = filelength(fileno(fp))) == 0 || total > 0x2000000 /* 32MB max*/) {
			printf("File has invalid size %d.\n", total);
			return ERR_FILE_ZERO_BYTE;
		}
		if (!fp) {
			fclose(fp);
		}
		
		SET_SIZE_FOR_FLASH(total);
		if (config_reg(portH, mx21reg_initsys, INIT_LOOP_COUNT) != ROM_OK) {
			printf("config_reg(portH, mx21reg_initsys, INIT_LOOP_COUNT) failed\n");
			goto func_out;
		}

		if (debug) printf("Downloading to SDRAM at 0x%x via %s. File: %s\n",
                          SERIAL_DOWNLOAD_SRC_ADDR, port_name, file_name);
		printf("Downloading\n");
		if (download_file(portH, file_name, SERIAL_DOWNLOAD_SRC_ADDR) != ROM_OK) {
			printf("download_file() failed at line %d\n", __LINE__);
			goto func_out;
		}
              
		if (debug)printf("Downloading .dat to SDRAM at 0x%x via %s. File: %s\n",
                         FLASH_CODE_ADDR, port_name, "./flash_code");
		if (download_file(portH, "./flash_code", FLASH_CODE_ADDR) != ROM_OK) {
			printf("download_file() failed at line %d\n", __LINE__);
			goto func_out;
		}

		// execute
		SET_ADDR(irom_exec, FLASH_CODE_ADDR);
		if (op_header(portH, irom_exec, &result) != ROM_OK) {
			printf("Failed to exec\n");
			goto func_out;
		}
		op_header(portH, irom_status, &result);

		if (PurgeComm(portH, PURGE_RXABORT|PURGE_RXCLEAR|PURGE_TXABORT|PURGE_TXCLEAR) == 0) {
			printf("PurgeComm() failed\n"); 
			return ROM_ERROR;
		}
		
		Shutdown_Port(portH);
		if ((portH = Open_Port(port_name, CBR_115200)) == INVALID_HANDLE_VALUE) {
			printf("Error: %s is in use\n", port_name);
			return -1;
		}
		printf("\nStart erasing\n");
		while (1) {
			unsigned char c, cc[9];
			printf("."); 
			if (ReadFile(portH, &c, 1, &bytes_read, NULL) == 0) {
				printf("\nReadFile failed at line: %d\n", __LINE__);
				goto func_out;
			}
			if (debug) printf("%c", c);

			if (c == '\n') {
				if (ReadFile(portH, &cc, 8, &bytes_read, NULL) == 0) {
					printf("\nReadFile failed at line: %d\n", __LINE__);
					goto func_out;
				}
				cc[8] = 0;
				if (debug) printf("cc=%s\n", cc);
				if (memcmp(cc, "BEADDEAD", 8) == 0) {
					printf("\nErase failed\n");
					goto func_out;
				} else if (memcmp(cc, "BEADBEEF", 8) == 0) {
					printf("\nErase ok. Start programming\n");
				} else if (memcmp(cc, "BEADFEEF", 8) == 0) {
					printf("\nProgram failed\n");
					goto func_out;
				} else if (memcmp(cc, "BEADCEEF", 8) == 0) {
					printf("\nProgram ok\n");
					goto func_out;
				}
			}

		}

		break;
	case ENUM_NAND:
		break;
	}

func_out:
	if (!fp) fclose(fp);
    Shutdown_Port(portH);

	exit (0);

help_msg:
	PRINT_HELP_MSG(argv[0]);
	exit (-1);
help_msg_short:
	printf("Type %s without argument for help\n", argv[0]);
	exit(-1);

}

/*!
 * Open a serial port for reading or writing.
 */
HANDLE Open_Port(char* pcCommPort, int baud)
{
	HANDLE hCom;
	if (debug) printf("\nOpen_Port for RW Opening = %s \n",pcCommPort);
	hCom = CreateFile (pcCommPort,						// Pointer to the name of the port
                       GENERIC_READ | GENERIC_WRITE,	// Access (read-write) mode
                       0,								// Share mode
                       NULL,							// Pointer to the security attribute
                       OPEN_EXISTING,					// How to open the port
                       0,								// Port attributes
                       NULL);							// Handle to port with attribute

	if (hCom == INVALID_HANDLE_VALUE) {
		// Handle the error.
		printf ("CreateFile failed with error %d.\n", GetLastError());
		return INVALID_HANDLE_VALUE;
	}
	else {
		if (debug) printf("Setting up port %s with baud=%d\n", pcCommPort, baud);
		if (Setup_Port(hCom, baud) == 0) {
			if (debug) printf ("Serial port %s successfully reconfigured.\n", pcCommPort);
		} else
			return INVALID_HANDLE_VALUE;
	}

	return hCom;
}
/*!
 * Close a port with a serial or parallel port printer.
 */
void Shutdown_Port(HANDLE portH)
{
	if (portH != NULL)
		CloseHandle(portH);
}

/*!
 * Setup the serial or parallel port currently selected with specific baud rate
 */
int Setup_Port(HANDLE hCom, int baud)
{
	DCB  dcb;
	COMMTIMEOUTS CommTimeouts;

	// Build on the current configuration, and skip setting the size
	// of the input and output buffers with SetupComm.

	if (GetCommState(hCom, &dcb) == 0) {
	   printf ("GetCommState failed with error %d.\n", GetLastError());
	   return (2);
	}
    
	// Fill in DCB: 115,200 bps, 8 data bits, no parity, and 1 stop bit.
	dcb.BaudRate = baud;     // set the baud rate
	dcb.ByteSize = 8;             // data size, xmit, and rcv
	dcb.Parity = NOPARITY;        // no parity bit
	dcb.StopBits = ONESTOPBIT;    // one stop bit

	if (SetCommState(hCom, &dcb) == 0) {
	   // Handle the error.
	   printf ("SetCommState failed with error %d.\n", GetLastError());
	   return (3);
	}

	//Communication timeouts are optional but can be set similarly to DCB values
	//This will prevent the program from hanging should the port does not respond.
	if (GetCommTimeouts (hCom, &CommTimeouts) == 0) {
		printf("Failed at GetCommTimeouts()\n");
		return 4;
	}
	if (debug) printf("\
		   CommTimeouts.ReadIntervalTimeout = %d\n\
		   CommTimeouts.ReadTotalTimeoutConstant = %d\n\
		   CommTimeouts.ReadTotalTimeoutMultiplier = %d\n\
		   CommTimeouts.WriteTotalTimeoutConstant = %d\n\
		   CommTimeouts.WriteTotalTimeoutMultiplier = %d\n",
			CommTimeouts.ReadIntervalTimeout,
			CommTimeouts.ReadTotalTimeoutConstant,
			CommTimeouts.ReadTotalTimeoutMultiplier,
			CommTimeouts.WriteTotalTimeoutConstant,
			CommTimeouts.WriteTotalTimeoutMultiplier);
           
	CommTimeouts.ReadIntervalTimeout = 50;
	CommTimeouts.ReadTotalTimeoutConstant = 100;
	CommTimeouts.ReadTotalTimeoutMultiplier = 10;
	CommTimeouts.WriteTotalTimeoutConstant = 100;
	CommTimeouts.WriteTotalTimeoutMultiplier = 10;

	if (SetCommTimeouts (hCom, &CommTimeouts) == 0) {
		printf("Failed to SetCommTimeouts()\n");
		return 5;
	}

	return 0;
}

/*
 * Convert the error status code from the i.mx21 bootstrap to a string
 */
char *status_to_string(unsigned long status)
{
	struct status_decode *decode;
	
	decode = &status_codes[0];
	while (!(decode->description == 0 && decode->code == 0)) {
		if (decode->code == status) {
			return decode->description;
		}
		decode++;
	}
	
	return "unknown";
}

void PRINT_HELP_MSG(char* s)
{
	printf("This Windows program downloads a file to a specified memory \n\
location on the MX21ADS board via a PC COM port using internal UART1 on \n\
the ADS board. Note: \n\
1. If the memory location is within the NOR flash range, then it will try \n\
   to program the file into the NOR flash. (NOR flash base is 0xC8000000) \n\
2. If the memory location is within the NAND flash range, then it will try \n\
   to program the file into the NAND flash. (NAND flash base is 0xDF003000)\n\
3. If the memory location is within the SDRAM, it will then jump to that \n\
   location after downloading the file. (SDRAM base is 0xC0000000)\n");

	printf("\nSyntax:\n");
	printf("   %s <com port> <address> <file name>\n", s);
	printf("\nExample:\n");
	printf("<1> %s COM1 0xC0000000 test.bin \n", s);
	printf("    -- download test.bin to the beginning of SDRAM\n");
	printf("<2> %s COM1 0xC8000000 test.bin \n", s);
	printf("    -- program test.bin to the beginning of NOR flash\n");
	printf("<3> %s COM1 0xDF003000 test.bin \n", s);
	printf("    -- program test.bin to the beginning of NAND flash (skip bad blocks)\n");
}

int parse_cmd_line(int argc, char* argv[], int *p_num, unsigned long *download)
{
    int  val1, port;
	unsigned long addr = 0;
    char *ptr;

	// Check for COM port
	if ((argv[1][0] != 'C' && argv[1][0] != 'c') || (argv[1][1] != 'O' && argv[1][1] != 'o') ||
		(argv[1][2] != 'M' && argv[1][2] != 'm') || argv[1][3] == '\0') {
		printf("Use 'COM1', 'COM2', ...\n");
		return (__LINE__);
	}
	ptr = &argv[1][3];
	while ((val1 = *ptr++) != '\0') {
		if (val1 < '0' || val1 > '9') {
			printf("Wrong port number.\n");
            return (__LINE__);
		}
	}
	port = atoi(&(argv[1][3]));

	// Check for download address
	if (argv[2][0] != '0' || argv[2][1] != 'x') {
		printf("Wrong address, use hex format: 0x.... instead\n");
        return (__LINE__);
	}
	ptr = &argv[2][2];
	while ((val1 = *ptr++) != '\0') {
		addr *= 16;
		if (val1 >= 'a' && val1 <= 'f')
			addr += val1 - 'a' + 10;
		else if (val1 >= 'A' && val1 <= 'F')
			addr += val1 - 'A' + 10;
		else if (val1 >= '0' && val1 <= '9')
			addr += val1 - '0';
		else {
			printf("Wrong hex value for address \n");
            return (__LINE__);
		}
	}
	*download = addr;
	if (argc == 5) {
		if (argv[4][0] == '-' && argv[4][1] == 'd')
			debug = 1;
	}

    return 0;
}

/*!
 * Send 16byte operation header to mx21 for various operations
 * @param handle	com port handle
 * @param header	16-byte command header
 * @param result	returned code when reading back the status after cmd is sent
 * @return	ROM_OK if successful; ROM_ERROR otherwise.
 */
int op_header(HANDLE handle, unsigned char* header, unsigned long *result)
{
	unsigned long byte_count, response[8] = {0, 0, 0, 0, 0, 0, 0, 0};
	DWORD dw, bytes_sent;
    LPVOID lpMsgBuf;

    if (PurgeComm(handle, PURGE_RXABORT|PURGE_RXCLEAR|PURGE_TXABORT|PURGE_TXCLEAR) == 0) {
		printf("PurgeComm() failed\n"); 
		return ROM_ERROR;
	}

	if (WriteFile(handle, header, 16, &bytes_sent, NULL) == 0 ||
		bytes_sent != 16) {
        printf("Failed to write cmd header 0x%x, bytes_written=%d\n", GET_CMD(header), bytes_sent);
        return ROM_ERROR;
    }
	if (debug) printf("GET_CMD(header)=%04x\n", GET_CMD(header));
	
	switch (GET_CMD(header)) {
	case CMD_STATUS:
		if (ReadFile(handle, (unsigned char*)response, 4, &byte_count, NULL) == 0 ||
			byte_count != 4) {
			if (debug) {
				printf ("CMD_STATUS: ReadFile failed with error %d.\n", dw=GetLastError());
				printf("Failed to get status for cmd 0x%x. result=0x%x, bytes_read=%d\n", 
							GET_CMD(header), response[0], byte_count);
				FormatMessage(
					FORMAT_MESSAGE_ALLOCATE_BUFFER | 
					FORMAT_MESSAGE_FROM_SYSTEM,
					NULL,
					dw,
					MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
					(LPTSTR) &lpMsgBuf,
					0, NULL );

				printf("failed with error %d: %s", dw, lpMsgBuf); 
			}
			return ROM_ERROR;
		}
		break;
	case CMD_DOWNLOAD:
		response[0] = 0;
		// have to ignore the return value since it always returns 0 (error)
		ReadFile(handle, (unsigned char*)response, 4, &byte_count, NULL);
		if (byte_count != 4 || (response[0] != DEVELOPMENT_PART &&
			response[0] != PRODUCTION_PART)) {
			printf ("CMD_DOWNLOAD: ReadFile failed with error %d.\n", GetLastError());
			printf("Failed to get status for cmd 0x%x. result=0x%x, bytes_read=%d\n", 
				   GET_CMD(header), response[0], byte_count);
			return ROM_ERROR;
		}
		break;
	case CMD_READ:
		/* Read write complete acknowledge */
		if (ReadFile(handle, (unsigned char*)response, 8, &byte_count, NULL) == 0 ||
			byte_count != 8) {
			printf("Failed to read 0x%x. resp1=0x%x resp2=0x%x bytes_read=%d\n", 
				   GET_CMD(header), response[0], response[1], byte_count);
			return ROM_ERROR;
		}
		break;
	case CMD_WRITE:
		/* Read write complete acknowledge */
		if (ReadFile(handle, response, 8, &byte_count, NULL) == 0 ||
			byte_count != 8) {
			printf("Failed to write 0x%x. resp_b=0x%x, resp_c=0x%x, bytes_read=%d\n", 
				   GET_CMD(header), response[0], response[1], byte_count);
			return ROM_ERROR;
		}
		if (response[1] != WRITE_COMPLETE) {
			printf("Failed: 0x%x. resp_b=0x%x, resp_c=0x%x, bytes_read=%d\n", 
				   GET_CMD(header), response[0], response[1], byte_count);
			return ROM_ERROR;
		}
		break;
	}
	if (debug) printf("resp1=0x%08x resp2=0x%08x\n", response[0], response[1]);
	*result = response[0];
	return ROM_OK;   
}

/*!
 * Download a file via a com port on the target
 * @param handle	com port handle
 * @param f_name	file name to be downloaded
 * @param addr		target address to be downloaded
 * @return 			ROM_OK if successful
 */
int download_file(HANDLE handle, char *f_name, unsigned long addr)
{
	FILE *fp;
	unsigned long byte_count, result, sz_sent, i = 0, total;
	
	if ((fp = fopen(f_name,"rb")) == NULL) {
		printf("\nUnable to open file: %s\n", f_name);
		return ERR_FILE_NOT_OPEN;
	}

	if ((total = filelength(fileno(fp))) == 0 || total > 0x2000000 /* 32MB max*/) {
		printf("Zero byte file.\n");
		return ERR_FILE_ZERO_BYTE;
	}
	while ((byte_count = fread(scratch_buf, sizeof(char), DATA_LEN, fp)) != 0) {
		// send byte_count bytes
		SET_ADDR(irom_download, addr);
		SET_COUNT(irom_download, byte_count);
		if (debug) 
			printf("addr=0x%x, byte_count=0x%x\n", addr, byte_count);
		else {
			printf("."); 
		}

		if (op_header(handle, irom_download, &result) != ROM_OK)
			return ROM_ERROR;
		// send data out to serial port
		if (WriteFile(handle, scratch_buf, byte_count, &sz_sent, NULL) == 0 ||
			sz_sent != byte_count) {
			printf("Failed to download. sz_sent=%d\n", sz_sent);
			return ROM_ERROR;
		}

		if (byte_count < DATA_LEN)	// last buffer
			break;

		addr += byte_count;
	}
	if (debug) printf("\nFinish downloading %d bytes\n", total);

	if (!fp) {
		fclose(fp);
	}
	return ROM_OK;
}

/*!
 * Send read/write register command
 * @param handle	com port handle
 * @param p			pointer to an array of the register profile for read/write with values
 * @param count		number of entries in the array
 * @return			ROM_OK if successful; ROM_ERROR otherwise
 */
int config_reg(HANDLE handle, struct reg_addr_val p[], unsigned long count)
{
	unsigned long result, i;

	if (debug) printf("INIT_LOOP_COUNT=%d\n", INIT_LOOP_COUNT);

	for (i = 0; i < INIT_LOOP_COUNT; i++) {
		if (p[i].r_w == REG_READ) {
			SET_ADDR(irom_readl, p[i].addr);
			if (op_header(handle, irom_readl, &result) != 0) {
				printf("Error at line: %d\n", __LINE__);
				return ROM_ERROR;
			}
		} else {
			SET_ADDR(irom_writel, p[i].addr);
			SET_DATA(irom_writel, p[i].val); 
			if (op_header(handle, irom_writel, &result) != 0) {
				printf("Error at line: %d\n", __LINE__);
				return ROM_ERROR;
			}
		}
	}
	return ROM_OK;
}
