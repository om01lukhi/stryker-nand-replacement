In this project, you can build using either the flash_test.c or 
generic_flash_programmer.c

flash_test.c tests the programming capability of the entire flash.

generic_flash_programmer.c is used to program the flash with known data patterns.

