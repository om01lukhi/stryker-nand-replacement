#!/bin/bash
# 
# This will make your life easier when compiling nandboot and miniboot which uses very
# long commands.  This script supports distcc. You can also build ctags & cscope
# data base files.
#  
# To build MXC Linux boot loaders nandboot
# 18-JUL-2006 
#
#  Copyright 2004-2009 Freescale Semiconductor, Inc. All Rights Reserved.
# 
#  The code contained herein is licensed under the GNU General Public
#  License. You may obtain a copy of the GNU General Public License
#  Version 2 or later at the following locations:
# 
#  http://www.opensource.org/licenses/gpl-license.html
#  http://www.gnu.org/copyleft/gpl.html
# 

if [[ "$1" = "" ]]
then
        printf "\nScript to build MXC Linux bootloaders (nandboot)\n"
        printf "\n"
	printf "==>Set and export CROSS_COMPILE to absolute path of the cross compiler\n"
	printf "==>Set KBUILD_OUTPUT to absolute path of the build output directory\n"
	printf "==> Execute the following commands in sequence:\n\n"
        printf "    1. makebuild.sh {platform}\n"
        printf "       Where platform is one of:\n"
	printf "         {IMX25_3STACK IMX25_3STACK_AGL}\n"
	printf "    2. makebuild.sh { clean }\n"
	printf "    After building binaries can be found under bootloader/bin directory \n"
	exit 1;

fi

if [[ "$CROSS_COMPILE" = "" ]] && [ "$1" != "clean" ]
then
	echo "CROSS_COMPILE environment variable not set or not exported!!!"
	echo "Please set CROSS_COMPILE to the absolute path of the cross compiler and export it"
	echo "Example: export CROSS_COMPILE=/opt/freescale/usr/local/gcc-4.1.1-glibc-2.4-nptl-3/arm-none-linux-gnueabi/bin/arm-none-linux-gnueabi-"
	exit 1
fi

if [ "$1" = "clean" ]
then
	echo "Executing.... make" $1 for nandboot
	make clean
	exit
fi

	echo "Executing.... make" $1 for nandboot
	make clean
        make PLATFORM=$1
	exit

