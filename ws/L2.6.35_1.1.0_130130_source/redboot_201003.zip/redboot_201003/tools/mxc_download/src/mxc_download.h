/* mxc_download.h */

#define COM1_S "COM1:"
#define COM2_S "COM2:"
#define COM3_S "COM3:"

enum { PACKET_SIZE  = 256 };
enum { USB_PACKET_SIZE  = 32 };
enum { SER_PACKET_SIZE  = 1024 };
enum { PAR_PACKET_SIZE  = 128 };
enum { COM1 = 1};
enum { COM2 = 2};
enum { COM3 = 3};
enum { SPACE = 32 };
enum { TILDE = 126 };

// Types to be used later.
typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef float               FLOAT;
typedef void				*PVOID;
typedef PVOID				HANDLE;

