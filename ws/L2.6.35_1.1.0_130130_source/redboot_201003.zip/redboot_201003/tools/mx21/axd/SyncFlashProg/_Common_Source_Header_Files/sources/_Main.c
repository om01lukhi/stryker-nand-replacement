/******************************************************************************

 C   M O D U L E   F I L E
 
 (c) Copyright Motorola Semiconductors Hong Kong Limited 2000-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name	: i.MX System Test Program
 Project No.	: 
 Title			: memcpy tests
 File Name		: main.c
 Last Modified	: 04/27/2003
 (MM/DD/YYYY)

 Description	: The main function for the SDRAM memcpy test. This test will
 				  utilize the C library function call "memcpy". It also uses
 				  the Timer module to time how long each memcpy transfer takes	
 				  to be used later for benhmarking purposes.
 				  
 				  Also, the test requires the user to link in the init file
 				  "tahiti_init_caches_enabled.s" to enable both the I and D
 				  caches.  
 				  
 				  Run the memcpy test first by linking in "tahiti_init.s" to
 				  ensure proper functionality (caches disabled), then later
 				  link in "tahiti_init_caches_enabled.s".
 
 Comments		:

 History (MM/DD/YYYY):
 04/27/2003 - Initial Proposal

******************************************************************************/
#include <stdio.h>
#include "common.h"
#include "tht_memory_map_defines.h"
#include "testcase.h"
#include <string.h>	// for memcpy function

/* Modify SysInit() for different system initialization settings */
extern int SysInit(void);
extern int MemInit(void);

/****************************************************************
# D E F I N E S
****************************************************************/
// used only for testing code on DBMX1, where most of the 
// initialization will take place in the init.txt file for the
// debugger
#define DBMX1	

/****************************************************************
F U N C T I O N   P R O T O T Y P E S
****************************************************************/
void  Timer1_SetUp(void);

/*****************************************************************
 Public Functions
*****************************************************************/

volatile uint32_t gFailCount;

int32_t main(void)
{
	
	uint32_t offset_for_code, i, pattern, SDRAM_test_length, k, SDRAM_TEST_block, j;
	uint32_t SDRAM_test_length_word, SDRAM_TEST_block_word;
	uint32_t TimerValue, Time, PLLfreq;
	p_uint32_t mem_src, ps, mem_dst;
	
	// initialize time variables
	Time = 0;
	TimerValue = 0;
	
	// initialize gFailCount	
	gFailCount = 0;
	
	offset_for_code = 0x10000;
			
	SDRAM_test_length = 1024*1024*4;				// define a 4MB test length
	SDRAM_test_length_word = SDRAM_test_length / 4;	// 4MB = 1M-Word (Word = 32-bits)
	
	SDRAM_TEST_block = 1024;						// memcpy transfer in 1KB blocks
	SDRAM_TEST_block_word = SDRAM_TEST_block / 4;	// test block in word value
	
#ifdef DBMX1
	// DBMX1
	
	// set up Clock Source Control Register (CSCR) to maximize HCLK 
	*(p_uint32_t)(0x0021B000) &= 0xFFFFC3FF;	// BCLK_DIV = div-by-1
	
	// maximize PerCLK1 for TIMER1 (assuming 133MHz)
	*(p_uint32_t)(0x0021B020) &= 0xFFFFF0FF;	// PERDIV1 = div-by-1
	
	// define memory source, allowing enough offset for code	
	mem_src = (p_uint32_t)(0x08000000 + offset_for_code);
	// define memory destination, where the memory is being copied to
	mem_dst = (p_uint32_t)(0x0A000000);	// define SDRAM destination as third bank

#else	
	// DBMX21
	SysInit();
	MemInit();

	// set up Clock Source Control Register (CSCR) to maximize HCLK 
	*(p_uint32_t)CRM_CSCR &= 0xFFFFC3FF;	// BCLK_DIV = div-by-1
	
	// maximize PerCLK1 for TIMER1 (assuming 133MHz)
	*(p_uint32_t)CRM_PCDR &= 0xFFFFF0FF;	// PERDIV1 = div-by-1	

	// define memory source, allowing enough offset for code
	mem_src   = (p_uint32_t)(SDRAM0_BASE + 	offset_for_code);
	// define memory destination, where the memory is being copied to	
	mem_dst   = (p_uint32_t)(0xC2000000); // define SDRAM destination as third bank

#endif	// DBMX1	

	//***********************************
	// Initialize SDRAM memory source 
	//***********************************
		
	// fill memory source
	for( ps = mem_src, i = 0, pattern = 0; i < SDRAM_test_length ; i+= 4, ps += 1 ) 
    { 
		 
		*ps = pattern; 
		pattern += 0x11112222; 
    } 

  
    // verify values were programmed
    for( ps = mem_src, i = 0, pattern = 0; i < SDRAM_test_length; i+= 4, ps += 1 ) 
    {
   		
    	if (*ps != pattern)
    	{
    		gFailCount++;
       	}
    
    	pattern += 0x11112222;
    }
   
   	if (gFailCount != 0)
   	{
   		printf("**FAIL: Memory wasn't programmed correctly\n");
   	}
   	else
   	{
   		printf("Memory was programmed correctly.\n");
   	}
   
   
   // Set up and initialize the General Purpose Timer 1
   Timer1_SetUp();
   
   
	//***********************************
	// Begin memcpy test 
	//***********************************

	// do the memcpy test 10 times
	for( k=0; k<=9 ;k++ ) 
	{ 
		printf("\nIteration #%d ", k);
	
		#ifdef DBMX1
			*(p_uint32_t)(0x00202000) |= 0x00000001;	// activate Timer1
		#else
			*(p_uint32_t)GPT1_TCTL1 |= 0x00000001;	// activate Timer1
		#endif 		
		
		// memory transfer, increment variable "i" in word values
        for( j = 0, i = 0; i < SDRAM_test_length_word ; i += SDRAM_TEST_block_word, j += SDRAM_TEST_block_word) 
		{ 
			memcpy( (mem_dst + j), (mem_src + i), SDRAM_TEST_block ); 
		} 
		
		#ifdef DBMX1
			// DBMX1
			PLLfreq = 96; 	// assume 96MHz PLL frequency
			
			// TimerValue is taken from TCN1
			TimerValue = *(p_uint32_t)(0x00202010);			
			
			*(p_uint32_t)(0x00202000) &= 0xFFFFFFFE;	//deactivate Timer1	
			
        #else
        	// DBMX21
   			PLLfreq = 133; 	// assume 133MHz PLL frequency
   			
   			// TimerValue is taken from TCN1
			TimerValue = *(p_uint32_t)GPT1_TCN1;			
			
			*(p_uint32_t)GPT1_TCTL1 &= 0xFFFFFFFE;	//deactivate Timer1	
			
        #endif

			// calculate how much time it took to do memcpy in seconds
			Time = (TimerValue / PLLfreq);

			// uncomment for debug purposes
	//		printf ("TimerValue = %d\n", TimerValue); 
			printf( "Time (in us) = %d\n", Time );   
			
        // verify values were transferred
        for( ps = mem_dst, i = 0, pattern = 0; i < SDRAM_test_length; i+= 4, ps += 1 ) 
   		{
   		
    		if (*ps != pattern)
    			{
    				gFailCount++;
/*    				printf("Address = %x\n", ps);	// uncomment for debug purposes if fail  */  
       			}
       		pattern += 0x11112222;
    	}
   
	   	if (gFailCount != 0)
	   	{
	   		printf("**FAIL: Memory didn't transfer correctly, memcpy failed\n");
	   	}
   		else
   		{
   			printf("Memory was transfered correctly, memcpy passed.\n");
   		}
	
	}	// end for loop "k"
	
}


//*********************************
// Other function definitions
//*********************************

void Timer1_SetUp(void)
{
	
	#ifdef DBMX1 
		// DBMX1
		//init TIMER1
		// reset TIMER1 sequence
		*(p_uint32_t)(0x00202000) = 0x00000001;		//enable Timer1
		*(p_uint32_t)(0x00202000) |= 0x00008001;	//software reset Timer1
		*(p_uint32_t)(0x00202000) &= 0x00000000;	// disable Timer1
	    
	    // set up timer to run off of PLL freq
	    *(p_uint32_t)(0x00202000) = 0x00000002;	// CLKSOURCE = 001
	    
	#else	
		// DBMX21		    
	    //init TIMER1
	    // reset TIMER1 sequence
		*(p_uint32_t)GPT1_TCTL1 = 0x00000001;		//enable Timer1
		*(p_uint32_t)GPT1_TCTL1 |= 0x00008001;	//software reset Timer1
		*(p_uint32_t)GPT1_TCTL1 &= 0x00000000;	// disable Timer1
	    
	    // set up timer to run off of PLL freq (PerCLK1)
	    *(p_uint32_t)GPT1_TCTL1 = 0x00000002; 	// CLKSOURCE = 001
	#endif

}