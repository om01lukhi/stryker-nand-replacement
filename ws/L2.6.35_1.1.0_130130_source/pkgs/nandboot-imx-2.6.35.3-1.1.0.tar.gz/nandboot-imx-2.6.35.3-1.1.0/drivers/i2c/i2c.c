/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file i2c.c
 *
 * @brief NANDBoot I2C code.
 *
 * @ingroup NANDboot
 */

#include "mxc.h"
#include "mxc_uart.h"

#define I2C_AR                      0x0
#define I2C_IFDR                    0x4
#define I2C_I2CR                    0x8
#define I2C_I2SR                    0xC
#define I2C_I2DR                    0x10

#define I2C_I2CR_IEN                (1 << 7)
#define I2C_I2CR_IIEN               (1 << 6)
#define I2C_I2CR_MSTA               (1 << 5)
#define I2C_I2CR_MTX                (1 << 4)
#define I2C_I2CR_TXAK               (1 << 3)
#define I2C_I2CR_RSTA               (1 << 2)

#define I2C_I2SR_ICF                (1 << 7)
#define I2C_I2SR_IAAS               (1 << 6)
#define I2C_I2SR_IBB                (1 << 5)
#define I2C_I2SR_IAL                (1 << 4)
#define I2C_I2SR_SRW                (1 << 2)
#define I2C_I2SR_IIF                (1 << 1)
#define I2C_I2SR_RXAK               (1 << 0)

#define I2C_WRITE   0
#define I2C_READ    1

#undef writew

static void _writew(unsigned short v, volatile unsigned short *a)
{
       	/*
	 * Don't know why this is needed but this delay
	 * makes things work
	 */
	udelay(1);
	*a = v;
}
#define writew(v, a) _writew((unsigned short)(v), (volatile unsigned short *)(a))

static void tx_byte(unsigned char *data, unsigned int base)
{
	/* clear both IAL and IIF bits */
	writew(0, MXC_I2C_BASE_ADDR + I2C_I2SR);

	writew(*data, MXC_I2C_BASE_ADDR + I2C_I2DR);

	while ((readw(MXC_I2C_BASE_ADDR + I2C_I2SR) & I2C_I2SR_ICF) == 0)
		continue;
}

void i2c_write(unsigned char i2c_dev_addr, unsigned int reg_addr, unsigned int val)
{
	unsigned int reg;
	unsigned char i, data;
	unsigned short i2cr;
	static fdr = 0x3e;

	writew(fdr, MXC_I2C_BASE_ADDR + I2C_IFDR);
	/* reset and enable I2C */
	writew(0, MXC_I2C_BASE_ADDR + I2C_I2CR);

	writew(I2C_I2CR_IEN, MXC_I2C_BASE_ADDR + I2C_I2CR);

	/* Need wait at least 2 cycles of per_clk*/
	for (i = 0; i < 16; i++) {
		asm("nop");
	}

	/* 1.2 clear both IAL and IIF bits */
	writew(0, MXC_I2C_BASE_ADDR + I2C_I2SR);

	/* 1.3 assert START signal and also indicate TX mode */
	i2cr = I2C_I2CR_IEN | I2C_I2CR_MSTA | I2C_I2CR_MTX;
	writew(i2cr, MXC_I2C_BASE_ADDR + I2C_I2CR);

	/* 1.4 make sure bus is busy after the START signal */
	while((readw(MXC_I2C_BASE_ADDR + I2C_I2SR) & I2C_I2SR_IBB) == 0)
		continue;

	/* Step 2: send slave address + read/write at the LSB */
	data = (i2c_dev_addr << 1) | I2C_WRITE;
	tx_byte(&data, MXC_I2C_BASE_ADDR);

	/* Step 3: send I2C device register address */
	reg = reg_addr;

	data = reg;
	tx_byte(&data, MXC_I2C_BASE_ADDR);

	/* Step 4: write data */
	/* I2C_WRITE */
	/* send device register value */
	data = val;
	tx_byte(&data, MXC_I2C_BASE_ADDR);

	/* generate STOP by clearing MSTA bit */
	writew(I2C_I2CR_IEN | I2C_I2CR_MTX, MXC_I2C_BASE_ADDR + I2C_I2CR);
}
