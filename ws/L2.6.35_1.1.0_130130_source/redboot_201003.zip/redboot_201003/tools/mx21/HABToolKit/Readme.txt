*************************************************************************************************
Please Note the following:

1. This ToolKits v2.0 or higher support TO2.1 silicon
2. Installation only need to do once for each PC for TO2.1 silicon.
*************************************************************************************************

25/06/2004
\i.MX21 HABToolKits Exe Update
- i.MX21_HABToolKits_v2.2.exe: bug fixed for 8BitNAND Flash Program


03/06/2004
\i.MX21 HABToolKits Exe Update
- i.MX21 HABToolKits v2.1.exe: 	bug fixed for the flashing to user defined address
				in v2.0, it will always flash to 0xC8000000

24/03/2004 

i.MX21 HAB ToolKits v2.0 
- First release
- \example: 
	contains the download and the flashing example image for ADS
- \exe: 
	contains the "i.MX21 HAB ToolKit v2.0.exe" and the user guide
- \install: 
	contains the installation files and the installation guide
- \User Specific Flash: 
	contains guide and the example for users to build their own Flash program using the HAB ToolKits


Note: 	Code Signing Feature is not included in the ToolKits yet
	NAND flash limited to the first block (16k Bytes)only
