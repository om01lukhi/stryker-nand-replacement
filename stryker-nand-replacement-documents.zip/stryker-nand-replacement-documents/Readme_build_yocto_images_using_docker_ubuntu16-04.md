
# STEPS TO BUILD IMAGE USING YOCTO FOR I.MX28 

#######################################################
#     CONTENT                                         #
# 1. BSP Source Tree Details                          #
# 2. BSP Source Setup                                 #
# 3. Docker Setup                                     #
# 4. Build Pre-requisites                             #
# 5. Fetch Sources and Build the Image                #
# 6. Error gets occured during the build process      #
#######################################################

############################
# 1. BSP Source Tree Details
############################
================
# 1.1 For Linux
================
SRC_URI="https://github.com/Freescale/linux-fslc;  branch=4.9.x+fslc"
 OR 
SRC_URI="https://github.com/Freescale/linux-fslc/tree/4.9.x%2Bfslc"

------------------------------------------------------------------------
# Package/receipe name, package version and source directory in host PC
------------------------------------------------------------------------
PN="linux-fslc"
PV="4.9+gitAUTOINC+b69ecd63c1"
S="/home/work/fsl-community-bsp/build/tmp/work/imx28evk-fslc-linux-gnueabi/linux-fslc/4.9+gitAUTOINC+b69ecd63c1-r0/git"

=================
# 1.2 For U-Boot
=================
SRC_URI="https://github.com/Freescale/u-boot-fslc; branch=2016.11+fslc"
 OR 
SRC_URI="https://github.com/Freescale/u-boot-fslc/tree/2016.11%2Bfslc"

------------------------------------------------------------------------
# Package/receipe name, package version and source directory in host PC
------------------------------------------------------------------------
PV="v2016.11+gitAUTOINC+c44711d91e"
S="/home/work/fsl-community-bsp/build/tmp/work/imx28evk-fslc-linux-gnueabi/u-boot-fslc/v2016.11+gitAUTOINC+c44711d91e-r0/git"
PN="u-boot-fslc"

#####################
# 2. BSP Source Setup
#####################

=========================
2.1 Create the workspace
=========================
cd /hdd1/work/stryker_nand_replacement/
mkdir ~/bin
mkdir fsl-community-bsp
cd fsl-community-bsp

=========================
2.2 Install the repo tool
=========================
curl http://commondatastorage.googleapis.com/git-repo-downloads/repo > ~/bin/repo
chmod a+x ~/bin/repo
PATH=${PATH}:~/bin

======================================
2.3 Initialize and synchronize the BSP
======================================
repo init -u https://github.com/Freescale/fsl-community-bsp-platform -b morty
repo sync


# NOTE: IF do not want to use docker, and have older os-kernel, you can skip step 2 And continue with step 3

#################
# 2. Docker setup
#################

=========================================
# Install docker if not installed already
=========================================
sudo apt install docker.io
sudo usermod -aG docker $USER
newgrp docker

========================
# Create container
========================
 docker run -it --name yocto-morty --network host \
  -v /hdd1/work/stryker_nand_replacement/fsl-community-bsp:/home/work/fsl-community-bsp \
  ubuntu:16.04 bash

=> This command will put user into docker's /home/work/fsl-community-bsp directory
Below operations will take place in docker's fsl-community-bsp directory

root@om:/home/work/fsl-community-bsp

==============
# Make a user
==============

create a user named "user01" and continue with the following commands:

## This creates user  = user01, group = user01
useradd -m -s /bin/bash user01 

## Add user to sudo group and give password less sudo access
usermod -aG sudo user01
echo "user01 ALL=(ALL) NOPASSWD:ALL" >> /etc/sudoers

## Give user "user01" ownership of the Yocto workspace
chown -R user01:user01 /home/work/fsl-community-bsp 

------------------------------------------------------------------
 Few important things :
# Re-enter the existing container
docker start -ai yocto-morty

The host directory /hdd1/work/stryker_nand_replacement/fsl-community-bsp is mounted inside the container as /home/work/fsl-community-bsp. Therefore All source code and build outputs will be stored on the host.
------------------------------------------------------------------

#########################
# 3. Build Pre-requisites
#########################
[NOTE: If Docker is used, confirm that you are in /home/work/fsl-community-bsp/ directory after following step 2,
       If not used, you are in host pc's fsl-community-bsp direcory to perform following steps]

=====================================================
# Install Python 2, Python 3, and build essentials :
=====================================================
apt update
apt install -y python python3 python3-pip \
  gawk wget git-core diffstat unzip texinfo gcc-multilib \
  build-essential chrpath socat cpio python-pexpect \
  xz-utils debianutils iputils-ping libsdl1.2-dev xterm curl ca-certificates locales

=======================
# Set up UTF-8 locale:
=======================

locale-gen en_US.UTF-8
update-locale LANG=en_US.UTF-8
echo 'export LC_ALL=en_US.UTF-8' >> ~/.bashrc
echo 'export LANG=en_US.UTF-8' >> ~/.bashrc
echo 'export LANGUAGE=en_US.UTF-8' >> ~/.bashrc
source ~/.bashrc

cd /home/work/fsl-community-bsp

===========================
# Switch to the user01 user
===========================
su - user01

===============
# Source setup
===============

MACHINE=imx28evk DISTRO=fslc-framebuffer source setup-environment build-imx28

##########################################
# 4. Fetch Sources and Build the Image
##########################################
Two commands are given below :

1. bitbake -c fetchall core-image-base

2. MACHINE=imx28evk bitbake core-image-base


# The generated images are available in:
Host:
    /hdd1/work/stryker_nand_replacement/fsl-community-bsp/build-imx28/tmp/deploy/images/imx28evk/

Container:
    /home/work/fsl-community-bsp/build-imx28/tmp/deploy/images/imx28evk/

Since the Yocto workspace is mounted from the host into the container, both paths refer to the same files.

#####################################################
# 5. Error might gets occured during the build process
#####################################################

=====================================================================================================
# NOTE: If git fetch error,  means that git protocol git:// does not works, change it to https://
=====================================================================================================

sudo chown -R user01:user01 /home/work
git config --global url."https://github.com/".insteadOf git://github.com/

And rerun :
bitbake -c fetchall core-image-base

------------------------------------------------------------------------------