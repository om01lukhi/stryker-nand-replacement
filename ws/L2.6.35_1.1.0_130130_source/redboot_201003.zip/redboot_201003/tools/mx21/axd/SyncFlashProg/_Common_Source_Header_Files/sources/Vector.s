;;; Copyright ARM Ltd 1999. All rights reserved.

        AREA Vect, CODE, READONLY

; These are example exception vectors and exception handlers

; Where there is ROM fixed at 0x0 (build_b & build_c), these are hard-coded at 0x0.
; Where ROM/RAM remapping occurs (build_d), these are copied from ROM to RAM.
; The copying is done automatically by the C library code inside __main.

; *****************
; Exception Vectors
; *****************

; Note: LDR PC instructions are used here because branch (B) instructions
; could not simply be copied (the branch offsets would be wrong).  Also,
; a branch instruction might not reach if the ROM is at an address >32MB).

        ENTRY

        LDR     PC, Reset_Addr
        LDR     PC, Undefined_Addr
        LDR     PC, SWI_Addr
        LDR     PC, Prefetch_Addr
        LDR     PC, Abort_Addr
        NOP                             ; Reserved vector
        LDR     PC, IRQ_Addr
        LDR     PC, FIQ_Addr
        
        IMPORT  Reset_Handler           ; In init.s
        
Reset_Addr      DCD     Reset_Handler
Undefined_Addr  DCD     Undefined_Handler
SWI_Addr        DCD     SWI_Handler
Prefetch_Addr   DCD     Prefetch_Handler
Abort_Addr      DCD     Abort_Handler
                DCD     0               ; Reserved vector
IRQ_Addr        DCD     IRQ_Handler
FIQ_Addr        DCD     FIQ_Handler


; ************************
; Exception Handlers
; ************************

        IMPORT	C_Undefined_Handler
        IMPORT	C_SWI_Handler
        IMPORT	C_Prefetch_Handler
        IMPORT	C_Abort_Handler
        IMPORT	C_IRQ_Handler
        IMPORT	C_FIQ_Handler

; The following dummy handlers do not do anything useful in this example.
; They are set up here for completeness.

Undefined_Handler
        B       C_Undefined_Handler
SWI_Handler
        B       C_SWI_Handler     
Prefetch_Handler
        B       C_Prefetch_Handler
Abort_Handler
        B       C_Abort_Handler
IRQ_Handler
        B       C_IRQ_Handler
FIQ_Handler
        B       C_FIQ_Handler
        
        END

