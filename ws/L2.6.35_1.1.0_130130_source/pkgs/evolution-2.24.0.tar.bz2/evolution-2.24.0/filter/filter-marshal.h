
#ifndef __filter_marshal_MARSHAL_H__
#define __filter_marshal_MARSHAL_H__

#include	<glib-object.h>

G_BEGIN_DECLS

G_END_DECLS

#endif /* __filter_marshal_MARSHAL_H__ */

