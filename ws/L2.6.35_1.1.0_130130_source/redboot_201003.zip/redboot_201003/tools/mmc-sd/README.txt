Type cfimager.exe without argument will show help info.

Need a USB MMC/SD card reader that is plugged into a Windows PC. Then find
the drive letter associated with the MMC/SD driver - it is needed in the
following command after -d. The actual command to program Redboot binary is:

	cfimager -o 0x400 -f z:\temp\redboot-no-padding.bin -d g

Note: 1) Make sure use the Redboot binary without padding
      2) The -o option is not listed in the cfimager help itself


