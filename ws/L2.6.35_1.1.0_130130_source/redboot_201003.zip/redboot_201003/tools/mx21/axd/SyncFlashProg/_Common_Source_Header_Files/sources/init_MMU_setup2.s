        AREA    Init, CODE, READONLY

; --- Standard definitions of mode bits and interrupt (I & F) flags in PSRs

Mode_USR        EQU     0x10
Mode_FIQ        EQU     0x11
Mode_IRQ        EQU     0x12
Mode_SVC        EQU     0x13
Mode_ABT        EQU     0x17
Mode_UNDEF      EQU     0x1B
Mode_SYS        EQU     0x1F ; available on ARM Arch 4 and later

I_Bit           EQU     0x80 ; when I bit is set, IRQ is disabled
F_Bit           EQU     0x40 ; when F bit is set, FIQ is disabled

; --- Amount of memory (in bytes) allocated for stacks

Len_FIQ_Stack    EQU     1024
Len_IRQ_Stack    EQU     1024
Len_ABT_Stack    EQU     1024
Len_UND_Stack    EQU     1024
Len_SVC_Stack    EQU     1024
Len_USR_Stack    EQU     1024


; Add lengths >0 for FIQ_Stack, ABT_Stack, UND_Stack if you need them.
; Offsets will be loaded as immediate values.
; Offsets must be 8 byte aligned.

Offset_FIQ_Stack         EQU     0
Offset_IRQ_Stack         EQU     Offset_FIQ_Stack + Len_FIQ_Stack
Offset_ABT_Stack         EQU     Offset_IRQ_Stack + Len_IRQ_Stack
Offset_UND_Stack         EQU     Offset_ABT_Stack + Len_ABT_Stack
Offset_SVC_Stack         EQU     Offset_UND_Stack + Len_UND_Stack
Offset_USR_Stack         EQU     Offset_SVC_Stack + Len_SVC_Stack

        ENTRY

        EXPORT  Reset_Handler

Reset_Handler

	bl MMU_Setup
	bl PrvFlushCacheAndTLB_AND_DisableCaches


; --- Initialize stack pointer registers

; Enter each mode in turn and set up the stack pointer

       IMPORT  top_of_stacks       ; defined in stack.s and located by scatter file
       LDR     r0, =top_of_stacks

       MSR     CPSR_c, #Mode_FIQ:OR:I_Bit:OR:F_Bit ; No interrupts
       SUB     sp, r0, #Offset_FIQ_Stack

       MSR     CPSR_c, #Mode_IRQ:OR:I_Bit:OR:F_Bit ; No interrupts
       SUB     sp, r0, #Offset_IRQ_Stack

       MSR     CPSR_c, #Mode_ABT:OR:I_Bit:OR:F_Bit ; No interrupts
       SUB     sp, r0, #Offset_ABT_Stack

;       MSR     CPSR_c, #Mode_UND:OR:I_Bit:OR:F_Bit ; No interrupts
;       SUB     sp, r0, #Offset_UND_Stack

       MSR     CPSR_c, #Mode_SVC:OR:I_Bit:OR:F_Bit ; No interrupts
       SUB     sp, r0, #Offset_SVC_Stack

; --- Initialize memory system


; --- Initialize critical IO devices

; --- Now change to User mode and set up User mode stack, if needed
;        MSR     CPSR_c, #Mode_USR:OR:I_Bit:OR:F_Bit ; No interrupts
;        SUB     sp, r0, #Offset_USR_Stack
                
        IMPORT  __main

; --- Now enter the C code
        B       __main   ; note use B not BL, because an application will never return this way

	LTORG		;// place LTORG here, before the MMU translation table, but after all other LDR commands
	        
    GBLA	XCount
       
MMUTranslationTable


	IF :DEF: MX1
;// DBMX1 translation table
XCount	SETA	(0x0000007E) 
		DCD	XCount
XCount	SETA	(0x0010007E) 
		DCD	XCount
XCount	SETA	(0x00200072) 
		DCD	XCount		
;XCount	SETA	(0x00300072) ; Use 0x72 for non-cacheable, non-bufferable
XCount	SETA	(0x0030007A) ; Use 0x7A for cacheable only
;XCount	SETA	(0x0030007E) ; Use 0x7E for both cacheable and bufferable. 
	WHILE XCount < (0x10000000)
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND

XCount	SETA	(0x1000007A) ; Use 0x7A for cacheable only
	WHILE XCount < (0xFFF00000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND

;// 0xFFF00000 to end of memory map
XCount	SETA	(0xFFF0007E)	; Use 0x7E for both cacheable and bufferable.  	
		DCD	XCount
		
	ELSE
;// DBMX21 translation table	

;// 0x0 to 0x0FFFFFFF	
XCount	SETA	(0x0000007E)	; Use 0x7E for both cacheable and bufferable.  	
	WHILE XCount < (0x10000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	

;// 0x10000000 to 0xBFFFFFFF
XCount	SETA	(0x10000072)	; Use 0x72 for non-cacheable, non-bufferable
	WHILE XCount < (0xC0000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	

;// 0xC0000000 to 0xDFFFFFFF
;// XCount	SETA	(0xC000007E)	; Use 0x7E for both cacheable and bufferable.  	
;//	WHILE XCount < (0xE0000000)		
;//		DCD	XCount
;// XCount	SETA	(XCount + 0x00100000)
;//	WEND

;// 0xC0000000 to 0xC0FFFFFF	define 1st Bank of SDRAM0 as cacheable and bufferable		
XCount	SETA	(0xC000007E)	; Use 0x7E for both cacheable and bufferable.  	
	WHILE XCount < (0xC1000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND

;// 0xC1000000 to 0xC10FFFFF	define first 1 MB of SDRAM0 Bank 2 as non-cacheable, non-bufferable
XCount	SETA	(0xC1000072)	;  Use 0x72 for non-cacheable, non-bufferable
	WHILE XCount < (0xC1100000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND

;// 0xC1100000 to 0xC1FFFFFF	define rest of SDRAM0 Bank 2 region as cacheable and bufferable
XCount	SETA	(0xC110007E)	;  Use 0x7E for both cacheable and bufferable.
	WHILE XCount < (0xC2000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND
	
;// 0xC200000 to 0xC2FFFFFF		define SDRAM0 Bank 3 region as non-cacheable, non-bufferable
XCount	SETA	(0xC2000072)	;  Use 0x72 for non-cacheable, non-bufferable
	WHILE XCount < (0xC3000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	

;// 0xC300000 to 0xC4FFFFFF		define SDRAM0 Bank 4 region as cacheable and bufferable
XCount	SETA	(0xC300007E)	;  Use 0x7E for both cacheable and bufferable.
	WHILE XCount < (0xC4000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	


;// 0xC4000000 to 0xC7FFFFFF	define all of SDRAM1 as cacheable and bufferable
XCount	SETA	(0xC400007E)	;  Use 0x7E for both cacheable and bufferable.
	WHILE XCount < (0xC8000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND
	
;// 0xC8000000 to 0xC80FFFFF	define 1st MB of flash (CS0) as cacheable and bufferable
XCount	SETA	(0xC8000072)	;  Use 0x7E for both cacheable and bufferable.
	WHILE XCount < (0xC8100000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND
	
;// 0xC810000 to 0xCBFFFFFF		define 2nd MB and rest of flash (CS0) region as non-cacheable, non-bufferable
XCount	SETA	(0xC8100072)	;  Use 0x72 for non-cacheable, non-bufferable
	WHILE XCount < (0xCC000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	

;// 0xCC00000 to 0xCFFFFFFF		define CS1 region as non-cacheable, non-bufferable
XCount	SETA	(0xCC000072)	;  Use 0x72 for non-cacheable, non-bufferable
	WHILE XCount < (0xD0000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	
	
;// 0xD000000 to 0xD0FFFFFF		define CS2 region as non-cacheable, non-bufferable
XCount	SETA	(0xD0000072)	;  Use 0x72 for non-cacheable, non-bufferable
	WHILE XCount < (0xD1000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	
		
;// 0xD100000 to 0xD10FFFFF		define 1st 1MB of CS3 region as cacheable and bufferable
XCount	SETA	(0xD100007E)	;  Use 0x7E for both cacheable and bufferable.
	WHILE XCount < (0xD1100000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	

;// 0xD110000 to 0xD1FFFFFF		define rest CS2 region as non-cacheable, non-bufferable
XCount	SETA	(0xD1100072)	;  Use 0x72 for non-cacheable, non-bufferable
	WHILE XCount < (0xD2000000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND	

;// 0xD2000000 to 0xFFEFFFFF	define memory region from CS4 on as non-cacheable and non-bufferable 
XCount	SETA	(0xD2000072)	; Use 0x72 for non-cacheable, non-bufferable  	
	WHILE XCount < (0xFFF00000)		
		DCD	XCount
XCount	SETA	(XCount + 0x00100000)
	WEND

;// 0xFFF00000 to end of memory map
XCount	SETA	(0xFFF0007E)	; Use 0x7E for both cacheable and bufferable.  	
		DCD	XCount

	ENDIF
	
EndOfTables
	

MMU_Setup
	LDR	r0, =0x4000	; target address = 0x4000
	
	IF :DEF: MX1
	;// i.MX1 SDRAM location
	add	r0, r0, #0x0B000000;  Physical target address, fourth bank of SDRAM
	ELSE
	;// i.MX21 SDRAM location
	add	r0, r0, #0xC3000000;  Physical target address, fourth bank of SDRAM
	ENDIF
	
	
	ADRL	r1, MMUTranslationTable			; source address
	ADR	r2, EndOfTables					; limit of source

copyloop1
		ldmia	r1!, {r3-r7}
		stmia	r0!, {r3-r7}
		subs	r3, r1, r2
		blt		copyloop1


	LDR	r0, =0x555555f1
	MCR	p15, 0, r0, c3, c0, 0

	;; make the translation table base ptr point to our table
	IF :DEF: MX1
	;// i.MX1 SDRAM location
	LDR	r0, =0x0B004000		;MMUTranslationTableAddr
	ELSE
	;// i.MX21 SDRAM location	
	LDR	r0, =0xC3004000		;MMUTranslationTableAddr
	ENDIF
	
	MCR	p15, 0, r0, c2, c0, 0

	bx	lr  





PrvFlushCacheAndTLB_AND_DisableCaches

	ldr	r1, =0x00000000

	;; Drain the write buffer
	mcr	p15, 0, r1, c7, c10, 4

	;; Clean and Flush the Cache
	mcr	p15, 0, r1, c7, c7, 0

	;; Flush the TLB
	mcr	p15, 0, r1, c8, c7, 0

	;; Read the coprocessor control register
	mrc	p15, 0, r1, c1, c0, 0
	mov	r2, #0x00001000
	add	r2, r2, #0x4
	bic r1, r1, r2
	
	;write to control register
	mcr p15, 0, r1, c1, c0, 0

	BX	lr


        END




