/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 *
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef MX35_H_
#define MX35_H_

#include "hal_cache.h"

/* definitions */
#ifdef __ASSEMBLER__

#define REG8_VAL(a)      (a)
#define REG16_VAL(a)     (a)
#define REG32_VAL(a)     (a)

#define REG8_PTR(a)      (a)
#define REG16_PTR(a)     (a)
#define REG32_PTR(a)     (a)

#else				/* __ASSEMBLER__ */

#define REG8_VAL(a)      ((unsigned char)(a))
#define REG16_VAL(a)     ((unsigned short)(a))
#define REG32_VAL(a)     ((unsigned int)(a))

#define REG8_PTR(a)      ((volatile unsigned char *)(a))
#define REG16_PTR(a)     ((volatile unsigned short *)(a))
#define REG32_PTR(a)     ((volatile unsigned long *)(a))

#define REG32_SET(addr, val)    (*(volatile unsigned long*) (addr) = (val))
#define REG16_SET(addr, val)    (*(volatile unsigned short*) (addr) = (val))
#define readb(a)             (*(volatile unsigned char *)(a))
#define readw(a)             (*(volatile unsigned short *)(a))
#define readl(a)             (*(volatile unsigned int *)(a))
#define writeb(v,a)          (*(volatile unsigned char *)(a) = (v))
#define writew(v,a)          (*(volatile unsigned short *)(a) = (v))
#define writel(v,a)          (*(volatile unsigned int *)(a) = (v))

#endif				/* __ASSEMBLER__ */

/* handy sizes */
#define SZ_16		    0x00000010
#define SZ_256		    0x00000100
#define SZ_512		    0x00000200

#define SZ_1K		    0x00000400
#define SZ_2K		    0x00000800
#define SZ_4K		    0x00001000
#define SZ_8K		    0x00002000
#define SZ_16K		    0x00004000
#define SZ_32K		    0x00008000
#define SZ_64K		    0x00010000
#define SZ_128K		    0x00020000
#define SZ_256K		    0x00040000
#define SZ_512K		    0x00080000

#define SZ_1M		    0x00100000
#define SZ_2M		    0x00200000
#define SZ_4M		    0x00400000
#define SZ_8M		    0x00800000
#define SZ_16M		    0x01000000
#define SZ_32M		    0x02000000
#define SZ_48M		    0x03000000
#define SZ_64M		    0x04000000
#define SZ_128M		    0x08000000
#define SZ_256M		    0x10000000
#define SZ_512M		    0x20000000

#define SZ_1G		    0x40000000
#define SZ_2G		    0x80000000


/*
 * MX35 memory map:
 *
 * Virt		Phys		Size	What
 * ---------------------------------------------------------------------------
 * FC000000	43F00000	1M	AIPS 1
 * 50000000	50000000	1M	SPBA
 * FC200000	53F00000	1M	AIPS 2
 * 60000000	60000000	128M	ROMPATCH
 * 68000000	68000000	128M	ASIC
 *         	70000000	256M	IPU (MAX M2)
 * C0000000    	80000000	256M	CSD0 SDRAM/DDR
 *         	90000000	256M	CSD1 SDRAM/DDR
 *         	A0000000	128M	CS0 Flash
 *         	A8000000	128M	CS1 Flash
 *         	B0000000	32M	CS2
 *         	B2000000	32M	CS3
 * B4000000	B4000000	32M	CS4
 *         	B6000000	32M	CS5
 * BB000000	B8000000	64K	NAND, SDRAM, WEIM, M3IF, EMI controllers
 *         	C0000000	64M	PCMCIA/CF
 */

/* IRAM */
#define IRAM_BASE_ADDR		0x10000000
#define IRAM_BASE_ADDR_VIRT	0x10000000
#define IRAM_SIZE		SZ_128K

/*
 * L2CC
 */
#define L2CC_BASE_ADDR		0x30000000
#define L2CC_BASE_ADDR_VIRT	0x30000000
#define L2CC_SIZE		SZ_1M

/*
 * AIPS 1
 */
#define AIPS1_BASE_ADDR		0x43F00000
#define AIPS1_BASE_ADDR_VIRT	0xFC000000
#define AIPS1_SIZE		SZ_1M

#define MAX_BASE_ADDR		(AIPS1_BASE_ADDR + 0x00004000)
#define EVTMON_BASE_ADDR	(AIPS1_BASE_ADDR + 0x00008000)
#define CLKCTL_BASE_ADDR	(AIPS1_BASE_ADDR + 0x0000C000)
#define ETB_SLOT4_BASE_ADDR	(AIPS1_BASE_ADDR + 0x00010000)
#define ETB_SLOT5_BASE_ADDR	(AIPS1_BASE_ADDR + 0x00014000)
#define ECT_CTIO_BASE_ADDR	(AIPS1_BASE_ADDR + 0x00018000)
#define I2C_BASE_ADDR		(AIPS1_BASE_ADDR + 0x00080000)
#define I2C3_BASE_ADDR		(AIPS1_BASE_ADDR + 0x00084000)
#define UART1_BASE_ADDR 	(AIPS1_BASE_ADDR + 0x00090000)
#define UART2_BASE_ADDR 	(AIPS1_BASE_ADDR + 0x00094000)
#define I2C2_BASE_ADDR		(AIPS1_BASE_ADDR + 0x00098000)
#define OWIRE_BASE_ADDR 	(AIPS1_BASE_ADDR + 0x0009C000)
#define SSI1_BASE_ADDR		(AIPS1_BASE_ADDR + 0x000A0000)
#define CSPI1_BASE_ADDR 	(AIPS1_BASE_ADDR + 0x000A4000)
#define KPP_BASE_ADDR		(AIPS1_BASE_ADDR + 0x000A8000)
#define IOMUXC_BASE_ADDR	(AIPS1_BASE_ADDR + 0x000AC000)
#define ECT_IP1_BASE_ADDR	(AIPS1_BASE_ADDR + 0x000B8000)
#define ECT_IP2_BASE_ADDR	(AIPS1_BASE_ADDR + 0x000BC000)

/*
 * SPBA global module enabled #0
 */
#define SPBA_BASE_ADDR		0x50000000
#define SPBA_BASE_ADDR_VIRT	0x50000000
#define SPBA_SIZE		SZ_1M

#define UART3_BASE_ADDR 	(SPBA_BASE_ADDR + 0x0000C000)
#define CSPI2_BASE_ADDR 	(SPBA_BASE_ADDR + 0x00010000)
#define SSI2_BASE_ADDR		(SPBA_BASE_ADDR + 0x00014000)
#define ATA_DMA_BASE_ADDR	(SPBA_BASE_ADDR + 0x00020000)
#define MSHC1_BASE_ADDR		(SPBA_BASE_ADDR + 0x00024000)
#define SPDIF_BASE_ADDR		(SPBA_BASE_ADDR + 0x00028000)
#define ASRC_BASE_ADDR		(SPBA_BASE_ADDR + 0x0002C000)
#define ESAI_BASE_ADDR		(SPBA_BASE_ADDR + 0x00034000)
#define FEC_BASE_ADDR		(SPBA_BASE_ADDR + 0x00038000)
#define SPBA_CTRL_BASE_ADDR	(SPBA_BASE_ADDR + 0x0003C000)

/*
 * AIPS 2
 */
#define AIPS2_BASE_ADDR		0x53F00000
#define AIPS2_BASE_ADDR_VIRT	0xFC200000
#define AIPS2_SIZE		SZ_1M
#define CCM_BASE_ADDR		(AIPS2_BASE_ADDR + 0x00080000)
#define GPT1_BASE_ADDR		(AIPS2_BASE_ADDR + 0x00090000)
#define EPIT1_BASE_ADDR		(AIPS2_BASE_ADDR + 0x00094000)
#define EPIT2_BASE_ADDR		(AIPS2_BASE_ADDR + 0x00098000)
#define GPIO3_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000A4000)
#define SCC_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000AC000)
#define RNGC_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000B0000)
#define SDHC1_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000B4000)
#define SDHC2_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000B8000)
#define SDHC3_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000BC000)
#define IPU_CTRL_BASE_ADDR	(AIPS2_BASE_ADDR + 0x000C0000)
#define AUDMUX_BASE_ADDR	(AIPS2_BASE_ADDR + 0x000C4000)
#define GPIO1_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000CC000)
#define GPIO2_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000D0000)
#define SDMA_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000D4000)
#define RTC_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000D8000)
#define WDOG_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000DC000)
#define PWM_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000E0000)
#define CAN1_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000E4000)
#define CAN2_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000E8000)
#define RTIC_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000EC000)
#define IIM_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000F0000)
#define USB_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000F4000)
#define MLB_BASE_ADDR		(AIPS2_BASE_ADDR + 0x000F8000)

/*
 * ROMP and ASIC
 */
#define ROMP_BASE_ADDR		0x60000000
#define ROMP_BASE_ADDR_VIRT	0x60000000
#define ROMP_SIZE		SZ_1M

#define ASIC_BASE_ADDR		0x68000000
#define ASIC_BASE_ADDR_VIRT	0x68000000
#define ASIC_SIZE		SZ_1M

/* WEIM address */
#define CS0_BASE_ADDR		0xA0000000
#define CS1_BASE_ADDR		0xA8000000
#define CS2_BASE_ADDR		0xB0000000
#define CS3_BASE_ADDR		0xB2000000

#define CS4_BASE_ADDR		0xB4000000
#define CS4_BASE_ADDR_VIRT	0xB4000000
#define CS4_SIZE		SZ_32M

#define CS5_BASE_ADDR		0xB6000000
#define CS5_BASE_ADDR_VIRT	0xB6000000
#define CS5_SIZE		SZ_32M

/*
 * SDRAM, WEIM, M3IF, EMI controllers
 */
#define X_MEMC_BASE_ADDR	0xB8000000
#define X_MEMC_BASE_ADDR_VIRT	0xB8000000
#define X_MEMC_SIZE		SZ_64K

#define ESDCTL_BASE_ADDR	(X_MEMC_BASE_ADDR + 0x1000)
#define WEIM_BASE_ADDR		(X_MEMC_BASE_ADDR + 0x2000)
#define M3IF_BASE_ADDR		(X_MEMC_BASE_ADDR + 0x3000)
#define EMI_CTL_BASE_ADDR	(X_MEMC_BASE_ADDR + 0x4000)
#define PCMCIA_CTL_BASE_ADDR	EMI_CTL_BASE_ADDR

#define CS0_CTL_BASE_ADDR	WEIM_BASE_ADDR
#define CS1_CTL_BASE_ADDR	(WEIM_BASE_ADDR + 10)
#define CS2_CTL_BASE_ADDR	(WEIM_BASE_ADDR + 20)
#define CS3_CTL_BASE_ADDR	(WEIM_BASE_ADDR + 30)
#define CS4_CTL_BASE_ADDR	(WEIM_BASE_ADDR + 40)
#define CS5_CTL_BASE_ADDR	(WEIM_BASE_ADDR + 50)

/*
 * NFC controller
 */
#define NFC_BASE_ADDR		0xBB000000
#define NFC_BASE_ADDR_VIRT	0xBB000000
#define NFC_SIZE		SZ_8K

/*
 * Memory regions and CS
 */
#define CSD0_BASE_ADDR		0x80000000
#define CSD0_BASE_ADDR_VIRT	0xC0000000
#define CSD1_BASE_ADDR		0x90000000

/*!
 * This macro defines the physical to virtual address mapping for all the
 * peripheral modules. It is used by passing in the physical address as x
 * and returning the virtual address. If the physical address is not mapped,
 * it returns 0xDEADBEEF
 */
#define IO_ADDRESS(x)   \
	(void *) \
	(((x >= L2CC_BASE_ADDR) && (x < (L2CC_BASE_ADDR + L2CC_SIZE))) ? L2CC_IO_ADDRESS(x):\
	((x >= AIPS1_BASE_ADDR) && (x < (AIPS1_BASE_ADDR + AIPS1_SIZE))) ? AIPS1_IO_ADDRESS(x):\
	((x >= SPBA_BASE_ADDR) && (x < (SPBA_BASE_ADDR + SPBA_SIZE))) ? SPBA_IO_ADDRESS(x):\
	((x >= AIPS2_BASE_ADDR) && (x < (AIPS2_BASE_ADDR + AIPS2_SIZE))) ? AIPS2_IO_ADDRESS(x):\
	((x >= ROMP_BASE_ADDR) && (x < (ROMP_BASE_ADDR + ROMP_SIZE))) ? ROMP_IO_ADDRESS(x):\
	((x >= ASIC_BASE_ADDR) && (x < (ASIC_BASE_ADDR + ASIC_SIZE))) ? ASIC_IO_ADDRESS(x):\
	((x >= CS4_BASE_ADDR) && (x < (CS4_BASE_ADDR + CS4_SIZE))) ? CS4_IO_ADDRESS(x):\
	((x >= X_MEMC_BASE_ADDR) && (x < (X_MEMC_BASE_ADDR + X_MEMC_SIZE))) ? X_MEMC_IO_ADDRESS(x):\
	((x >= NFC_BASE_ADDR) && (x < (NFC_BASE_ADDR + NFC_SIZE))) ? NFC_IO_ADDRESS(x):\
	0xDEADBEEF)

/*
 * define the address mapping macros: in physical address order
 */
#define L2CC_IO_ADDRESS(x)  \
	(((x) - L2CC_BASE_ADDR) + L2CC_BASE_ADDR_VIRT)

#define AIPS1_IO_ADDRESS(x)  \
	(((x) - AIPS1_BASE_ADDR) + AIPS1_BASE_ADDR_VIRT)

#define SPBA_IO_ADDRESS(x)  \
	(((x) - SPBA_BASE_ADDR) + SPBA_BASE_ADDR_VIRT)

#define AIPS2_IO_ADDRESS(x)  \
	(((x) - AIPS2_BASE_ADDR) + AIPS2_BASE_ADDR_VIRT)

#define ROMP_IO_ADDRESS(x)  \
	(((x) - ROMP_BASE_ADDR) + ROMP_BASE_ADDR_VIRT)

#define ASIC_IO_ADDRESS(x)  \
	(((x) - ASIC_BASE_ADDR) + ASIC_BASE_ADDR_VIRT)

#define CS4_IO_ADDRESS(x)  \
	(((x) - CS4_BASE_ADDR) + CS4_BASE_ADDR_VIRT)

#define CS5_IO_ADDRESS(x)  \
	(((x) - CS5_BASE_ADDR) + CS5_BASE_ADDR_VIRT)

#define X_MEMC_IO_ADDRESS(x)  \
	(((x) - X_MEMC_BASE_ADDR) + X_MEMC_BASE_ADDR_VIRT)

#define NFC_IO_ADDRESS(x)  \
	(((x) - NFC_BASE_ADDR) + NFC_BASE_ADDR_VIRT)


/* WDOG register offsets */
#define WDOG_WCR			0x0
#define WDOG_WSR			0x2
#define WDOG_WRSR			0x4
#define WDOG_WICR			0x6
#define WDOG_WMCR			0x8

/* CCM Register offsets */
#define CLKCTL_CCMR                     0x00
#define CLKCTL_PDR0                     0x04
#define CLKCTL_PDR1                     0x08
#define CLKCTL_PDR2                     0x0C
#define CLKCTL_PDR3                     0x10
#define CLKCTL_PDR4                     0x14
#define CLKCTL_RCSR                     0x18
#define CLKCTL_MPCTL                    0x1C
#define CLKCTL_PPCTL                    0x20
#define CLKCTL_ACMR                     0x24
#define CLKCTL_COSR                     0x28
#define CLKCTL_CGR0                     0x2C
#define CLKCTL_CGR1                     0x30
#define CLKCTL_CGR2                     0x34
#define CLKCTL_CGR3                     0x38

/* CLKCTL_RCSR bit offsets */
#define CCM_RCSR_NF16B_OFFSET		14
#define CCM_RCSR_NFC_4K_OFFSET		9
#define CCM_RCSR_NFC_FMS_OFFSET		8

/* ASIC register offsets */
#define ASIC_NIMASK			0x04
#define ASIC_INTTYPEH			0x18
#define ASIC_INTTYPEL			0x1C

/* IIM register offsets */
#define IIM_SREV			24

/* I2C register offsets */
#define I2C_IADR			0x0
#define I2C_IFDR			0x4
#define I2C_I2CR			0x8
#define I2C_I2SR			0xC
#define I2C_I2DR			0x10
#define I2C_I2CR_IEN			(1 << 7)

/* L2CC register offsets */
#define L2CC_CACHE_LINE_SIZE		32
#define L2CC_CACHE_CTL			0x100
#define L2CC_CACHE_AUX_CTL		0x104
#define L2CC_CACHE_SYNC			0x730
#define L2CC_CACHE_INV_LINE		0x770
#define L2CC_CACHE_INV_WAY		0x77C
#define L2CC_CACHE_CLEAN_LINE		0x7B0
#define L2CC_CACHE_CLEAN_INV_LINE	0x7F0
#define L2CC_CACHE_DBG_CTL		0xF40

/* ESDCTL register offsets */
#define ESDCTL0				0x00
#define ESDCFG0				0x04
#define ESDCTL1				0x08
#define ESDCFG1				0x0C
#define ESDMISC				0x10

#if !defined(__ASSEMBLER__)	/* ADDED FOR COMPILATION */

#define MXC_CCM_BASE_ADDR	IO_ADDRESS(CCM_BASE_ADDR)
#define MXC_ASIC_BASE_ADDR	IO_ADDRESS(ASIC_BASE_ADDR)
#define MXC_IIM_BASE_ADDR	IO_ADDRESS(IIM_BASE_ADDR)
#define MXC_IOMUXC_BASE_ADDR	IO_ADDRESS(IOMUXC_BASE_ADDR)
#define MXC_WDOG_BASE_ADDR	IO_ADDRESS(WDOG_BASE_ADDR)
#define MXC_UART1_BASE_ADDR	IO_ADDRESS(UART1_BASE_ADDR)
#define MXC_UART2_BASE_ADDR	IO_ADDRESS(UART2_BASE_ADDR)
#define MXC_NFC_BASE_ADDR       IO_ADDRESS(NFC_BASE_ADDR)
#define MXC_I2C_BASE_ADDR	IO_ADDRESS(I2C_BASE_ADDR)

#define _reg_MXC_CCM_CCMR	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_CCMR)))
#define _reg_MXC_CCM_PDR0	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_PDR0)))
#define _reg_MXC_CCM_PDR1	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_PDR1)))
#define _reg_MXC_CCM_PDR2	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_PDR2)))
#define _reg_MXC_CCM_PDR3	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_PDR3)))
#define _reg_MXC_CCM_PDR4	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_PDR4)))
#define _reg_MXC_CCM_RCSR	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_RCSR)))
#define _reg_MXC_CCM_MPCTL	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_MPCTL)))
#define _reg_MXC_CCM_PPCTL	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_PPCTL)))
#define _reg_MXC_CCM_ACMR	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_ACMR)))
#define _reg_MXC_CCM_COSR	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_COSR)))
#define _reg_MXC_CCM_CGR0	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_CGR0)))
#define _reg_MXC_CCM_CGR1	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_CGR1)))
#define _reg_MXC_CCM_CGR2	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_CGR2)))
#define _reg_MXC_CCM_CGR3	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR+CLKCTL_CGR3)))

#define _reg_MXC_WDOG_WCR       (*((volatile unsigned short *)(MXC_WDOG_BASE_ADDR + WDOG_WCR)))
#define _reg_MXC_WDOG_WSR	(*((volatile unsigned short *)(MXC_WDOG_BASE_ADDR + WDOG_WSR)))
#define _reg_MXC_WDOG_WRSR	(*((volatile unsigned short *)(MXC_WDOG_BASE_ADDR + WDOG_WRSR)))

#define _reg_MXC_ASIC_NIMASK	(*((volatile unsigned long *)(MXC_ASIC_BASE_ADDR + ASIC_NIMASK)))
#define _reg_MXC_ASIC_INTTYPEH	(*((volatile unsigned long *)(MXC_ASIC_BASE_ADDR + ASIC_INTTYPEH)))
#define _reg_MXC_ASIC_INTTYPEL	(*((volatile unsigned long *)(MXC_ASIC_BASE_ADDR + ASIC_INTTYPEH)))

#define _reg_MXC_IIM_SREV	(*((volatile unsigned long *)(MXC_IIM_BASE_ADDR + IIM_SREV)))

#endif				/* !defined(__ASSEMBLER__) */

#endif				/* MX35_H_ */
