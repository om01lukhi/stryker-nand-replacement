/*
 * Copyright 2004-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file bootloader/drivers/uart/mxc_uart.h
 *
 * @brief This file contains the UART register information.
 *
 *
 * @ingroup Miniboot and NANDboot
 */

#ifndef MXC_UART_H
#define MXC_UART_H

#include "mxc.h"

/* Maximum length of the string */
#define MAX_STRLEN	150

#if (UART_PORT==1)
#define MXC_UART_BASE_ADDR	MXC_UART1_BASE_ADDR
#endif
#if (UART_PORT==2)
#define MXC_UART_BASE_ADDR	MXC_UART2_BASE_ADDR
#endif

/*
 * This defines the addresses for UART registers for 16 bit access 
 */
#define _reg_MXC_UART_URXD       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x00)))
#define _reg_MXC_UART_UTXD       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x40)))
#define _reg_MXC_UART_UCR1       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x80)))
#define _reg_MXC_UART_UCR2       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x84)))
#define _reg_MXC_UART_UCR3       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x88)))
#define _reg_MXC_UART_UCR4       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x8C)))
#define _reg_MXC_UART_UFCR       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x90)))
#define _reg_MXC_UART_USR1       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x94)))
#define _reg_MXC_UART_USR2       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x98)))
#define _reg_MXC_UART_UESC       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0x9C)))
#define _reg_MXC_UART_UTIM       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0xA0)))
#define _reg_MXC_UART_UBIR       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0xA4)))
#define _reg_MXC_UART_UBMR       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0xA8)))
#define _reg_MXC_UART_UBRC       (*((volatile U32 *)(MXC_UART_BASE_ADDR + 0xAC)))

/*
 * Mask to check Tx buffer empty
 */
#define TXFE_MASK   0x4000

/*
 * Mask to check receive data ready
 */
#define RDR_MASK    0x0001

/*
 * This defines the UART Baud rate configurations 
 */

#if UART_BAUD_RATE==9600
#define MXC_UART_UBIR              0x5F
#endif

#if UART_BAUD_RATE==19200
#define MXC_UART_UBIR              0xC0
#endif

#if UART_BAUD_RATE==38400
#define MXC_UART_UBIR              0x17F
#endif

#if UART_BAUD_RATE==57600
#define MXC_UART_UBIR              0x23F
#endif

#if UART_BAUD_RATE==115200
#define MXC_UART_UBIR              0x47F
#endif

/* The line status register bits. */
#define SIO_LSR_DR      0x01	/* data ready */
#define SIO_LSR_THRE    0x20	/* transmitter holding register empty */

/* The line control register bits. */
#define SIO_LCR_WLS0   0x01	/*word length select bit 0 */
#define SIO_LCR_WLS1   0x02	/* word length select bit 1 */
#define SIO_LCR_DLAB   0x80	/* divisor latch access bit */

#if UART_OUTPUT==INT_UART
#define mxc_outstring         mxc_uart_putstring
#define mxc_getstring         mxc_uart_getstring
#define mxc_getdata           mxc_uart_getdata
#define mxc_putdata           mxc_uart_putdata
#define mxc_dataready         mxc_uart_dataready
#define mxc_gethex            mxc_uart_gethex
#define mxc_puthex            mxc_uart_puthex
#else
#define mxc_outstring         ext_uart_write
#define mxc_getstring         ext_uart_read
#define mxc_getdata           ext_uart_getc
#define mxc_putdata           ext_uart_putc
#define mxc_dataready         ext_uart_dataready
#define mxc_gethex            ext_uart_gethex
#define mxc_puthex            ext_uart_puthex
#endif

#endif				/* MXC_UART_H */
