Put the Kernel image file as 'Image' in this directory before compiling miniboot.
