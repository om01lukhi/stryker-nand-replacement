/*
 * Copyright 2004-2009 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_setup.c
 * 
 * @brief Kernel tags source file for NANDBoot to configure command
 * line parameters to kernel.
 *
 * @ingroup miniboot and nandboot 
 */

#include "mxc_setup.h"
#include "mxc_uart.h"
#include <string.h>
/*!
 * This is initialization of  the kernel tagged list
 */
void mxc_setup_taglist(char * cmdline, unsigned int system_rev)
{

	struct tag *params = (struct tag *)CMDLINE_ADDR;	/* Tag parameters */

	/* Set up parameters to pass to kernel */
	/*  CORE tag must be present & first */
	params->hdr.size = (sizeof(struct tag_core) +
			    sizeof(struct tag_header)) / sizeof(U32);
	params->hdr.tag = ATAG_CORE;
	params->u.core.flags = 0;
	params->u.core.pagesize = 0;
	params->u.core.rootdev = 0;
	params = (struct tag *)((long *)params + params->hdr.size);

	/* Fill in the details of the memory layout */
	params->hdr.size = (sizeof(struct tag_mem32) +
			    sizeof(struct tag_header)) / sizeof(U32);
	params->hdr.tag = ATAG_MEM;
	params->u.mem.start = SDRAM_BASE_ADDR;
	params->u.mem.size = SDRAM_SIZE;
	params = (struct tag *)((long *)params + params->hdr.size);

	if(system_rev != -1){
		params->hdr.size = ((sizeof(struct tag_revision)) +
				     sizeof(struct tag_header))/sizeof(U32);
		params->hdr.tag = ATAG_REVISION;
		params->u.revision.rev = system_rev;
		params = (struct tag *)((long *)params + params->hdr.size);
	}
	if(cmdline){ /* Fill for CMDline */
		params->hdr.size = (ROUNDUP(strlen(cmdline)) +
				    sizeof(struct tag_header)) / sizeof(U32);
		params->hdr.tag = ATAG_CMDLINE;
		strcpy(params->u.cmdline.cmdline, cmdline);
		params = (struct tag *)((long *)params + params->hdr.size);
	}

	/* Mark end of parameter list  */
	params->hdr.size = 0;
	params->hdr.tag = ATAG_NONE;
}
