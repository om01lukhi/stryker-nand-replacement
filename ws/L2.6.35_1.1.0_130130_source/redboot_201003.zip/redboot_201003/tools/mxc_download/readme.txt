This Windows program is used to download a file to a memory location on the
MXC91331/MXC91321/MXC91231/MXC91131 EVB via a serial port on a PC and then 
jump to it.

Notes
-----
    1. Sometimes the download program may fail with PM card plugged in. 
       So if such problem occurs, remove the PM card and then try again.
    2. Redboot image for MXC91131 EVB can't start execution after download. 
       Reason unknown yet.

Supported platform
------------------
    i.300-30 EVB (MXC91331 based)
    MXC300-30 EVB (MXC91321 based)
    MXC275-30 EVB (MXC91231 based)
    MXC91131 EVB with DDR memory card
    MXC91131 EVB with MEM1 memroy card

Dip switch setup on the EVB
---------------------------
    SW1 (1-4): OFF ON  OFF OFF              -- For i.300-30/MXC30030/MXC275-30 EVB
    SW1 (1-4): OFF OFF ON  OFF              -- For MXC91131 EVB
    SW2 (1-5): OFF ON  OFF ON  ON
    SW3 (1-4): All OFF

    SW7 (1-4): OFF ON  OFF OFF
    SW8 (1-4): OFF OFF ON  ON
    SW9 (1-6): ON  OFF OFF OFF OFF OFF       (DSP_MOD_SEL)
    SW10(1-6): ON  ON  ON  OFF OFF ON        (AP_MOD_SEL)
    SW11(1-8): All OFF                       (CFG0-CFG7)

Serial port connection
----------------------
    1. For i.300-30/MXC30030/MXC275-30 EVB, use a Null-Modem RS-232 9-pin Serial 
    Cable to connect from your PC to the base board UART_B DTE port.
    For MXC91131 EVB, connect to UART_C DCE port without the null modem.

Syntax
------
    mxc_download.exe <COM Port> <Address> <File Name> <platform>

For example, to download Redboot binary to 0x81f00000 on MXC275-30 EVB via COM1, 
use:
    mxc_download.exe COM1 0x81f00000 mxc27530evb_redboot.bin mxc27530evb
For platforms like i.300-30 EVB, MXC300-30 EVB, MXC91131 EVB, MXC91131 MEM1 EVB:
    mxc_download.exe COM1 0x83f00000 i30030evb_redboot.bin i30030evb
    mxc_download.exe COM1 0x83f00000 mxc30030evb_redboot.bin i30030evb
    mxc_download.exe COM1 0x83f00000 mxc91131evb_redboot.bin mxc91131evb
    mxc_download.exe COM1 0x83f00000 mxc91131mem1evb_redboot.bin mxc91131mem1evb

Additional Notes
----------------
Mapping of internal UARTs on the EVB board
=====================================================
              |            Interal UART
BOARD UART    |======================================
              | i.300-30/MXC275-30 EVB | MXC91131 EVB
=====================================================
UART_A_DTE    |           UART1        |     UART1
UART_B_DTE    |           UART3        |     UART2
UART_C_DCE    |           UART2        |     UART3
=====================================================
