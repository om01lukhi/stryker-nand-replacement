const char *build_timestamp = "Evolution-Data-Server-2.24-2008-09-22";
