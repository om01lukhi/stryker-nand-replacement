/******************************************************************************

 C   M O D U L E   F I L E
 
 (c) Copyright Motorola Semiconductors Hong Kong Limited 2000-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name	: i.MX System Test Program
 Project No.	: 
 Title			: 
 File Name		: cases1_10.c
 Author			: Patrick Lam (r55106)    
 Last Modified	: 04/27/2003
 (MM/DD/YYYY)

 Description	: This file contains cases 1 to 10.

 Comments		:

 History (MM/DD/YYYY):
 04/27/2003 - Initial Proposal
 04/28/2003 - Key change #1 ...
            - Key change #2 ...
            

******************************************************************************/
#include "common.h"
#define PROTO_DEFINE_FUNCS
#include "testcase.h"


/****************************************************************
 Private Functions
****************************************************************/

//---------------------------------------------------------------
// Function		: case1n3
//		
// Description	: A combined case function for cases 1 and 3
//
// Return Value	: The status of the test.  For the meaning of the
//				  returned status, please refer to the case function
//				  description of each case.
//
//---------------------------------------------------------------
static status_t case1n3
	(
	int32_t num	// IN: the case number to execute
	)
{
	// switch between case numbers
	switch(num)
	{
	case 1:
		return OK;
	case 3:
		return ERR_TIMEOUT;
	default:
		return ERR_INVALID_CASE;
	} 
}

/*****************************************************************
 Public Functions
*****************************************************************/

//---------------------------------------------------------------
// Function		: case1
//		
// Description	: Function for Case 1.  (You may want to add some
//				  descriptions about what is being tested...)
//
// Return Value	: The status of the test.  (Add what each returned
//				  status means in this test case here)
//
//---------------------------------------------------------------
status_t case1(void)
{
	// use debugprintf for debug messages that you don't want to be
	// in final version
	debugprintf("dummy message\n");

	// use printf for all others
	printf("Test Done\n");
	return case1n3(1);
}

//---------------------------------------------------------------
// Function		: case2
//		
// Description	: Function for Case 2.  (You may want to add some
//				  descriptions about what is being tested...)
//
// Return Value	: The status of the test.  (Add what each returned
//				  status means in this test case here)
//
//---------------------------------------------------------------
status_t case2(void)
{
	return OK;
}

//---------------------------------------------------------------
// Function		: case3
//		
// Description	: Function for Case 1.  (You may want to add some
//				  descriptions about what is being tested...)
//
// Return Value	: The status of the test.  (Add what each returned
//				  status means in this test case here)
//
//---------------------------------------------------------------
status_t case3(void)
{
	return case1n3(3);
}