/******************************************************************************

 C   H E A D E R   F I L E

 (c) Copyright Motorola Semiconductors Hong Kong Limited 2000-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name : i.MX System Test Program
 Project No.  : 
 Title        : 
 File Name    : common.h    
 Last Modified: 04/27/2003
 (MM/DD/YYYY)

 Description  : Public data type

 Assumptions  : 
 
 Dependency Comments :

 Project Specific Data :

 History (MM/DD/YYYY) :
 04/27/2003 - Initial Proposal

******************************************************************************/
#ifndef _COMMON_H
#define _COMMON_H

/*************************** Header File Includes ****************************/
#include <stdio.h>
/********************************* Constants *********************************/
/******************************** Enumeration ********************************/
/****************************** Basic Data types *****************************/

/* Typedefs for integer types */
typedef unsigned char	uint8_t;	/* unsigned 8 bit data	*/
typedef unsigned short	uint16_t;	/* unsigned 16 bit data	*/
typedef unsigned int	uint32_t;	/* unsigned 32 bit data	*/
typedef signed char		int8_t;		/* signed 8 bit data	*/
typedef signed short	int16_t;	/* signed 16 bit data	*/
typedef signed int		int32_t;	/* signed 32 bit data	*/

typedef uint8_t *		p_uint8_t;	/* unsigned 8 bit data	*/
typedef uint16_t *		p_uint16_t;	/* unsigned 16 bit data	*/
typedef uint32_t *		p_uint32_t;	/* unsigned 32 bit data	*/
typedef int8_t *		p_int8_t;	/* signed 8 bit data	*/
typedef int16_t *		p_int16_t;	/* signed 16 bit data	*/
typedef int32_t *		p_int32_t;	/* signed 32 bit data	*/

typedef uint16_t		text_t;		/* 16-bit text data 	*/
typedef p_uint16_t		p_text_t;	/* 16-bit text data 	*/

typedef uint8_t			bool_t;		/* Boolean, TRUE/FALSE	*/


/************************* Structure/Union Data types ************************/
/********************************** Macros ***********************************/
#ifdef DEBUG
#define debugprintf printf
#else
#define debugprintf 
#endif

#define SDRAM_DENSITY	0x04000000	// 64MB total of SDRAM density
#define FLASH_DENSITY	0x02000000	// 32MB total of flash density

/*************************** Function prototype (S) **************************/

#endif