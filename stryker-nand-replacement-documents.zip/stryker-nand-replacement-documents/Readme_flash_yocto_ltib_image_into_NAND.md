########################################################################################################################################
#       SUMMARY
This document represent method to flash ltib and yocto images to NAND chip in imx28.
For both images we need to boot the board using SD card first and then we can perform further steps of flashing image into NAND.
kobs-ng utility is important to flash image in NAND as it adds, NCB (NAND config block).
For yocto, we flash u-boot image using kobs-ng and other required images like linux, dtb and rootfs using tftp from uboot console,
While in ltib, there are basic two steps, one we need to flash linux image using kobs-ng utility and rootfs.jffs2 using nand-write
########################################################################################################################################


###################################
#        CONTENT                  #
# 1. FLASH YOCTO IMAGE INTO NAND  #
# 2. FLASH LTIB IMAGE INTO NAND   #
###################################

################################
# 1. FLASH YOCTO IMAGE INTO NAND
################################

# Flash SD card with yocto image
cd <yocto_bsp>/build/tmp/deploy/images/imx28evk/
sudo dd if=core-image-base-imx28evk-20260721061255.rootfs.sdcard of=/dev/sdX
sync

# Copy u-boot into SD card /root/tmp/
sudp cp /tmp-dir/u-boot-imx28evk.sb /media/om/<root>/tmp/

# First boot the board and give below commands in linux console
1. flash_eraseall /dev/mtd0
2. kobs-ng init -v -w /tmp/u-boot-imx28evk.sb
3. sync

# Reboot the board and give halt on uboot console, and give below commands
--------------------------------------------------------------------
# check partition from yocto u-boot console
=> mtdparts 

device nand0 <gpmi-nand>, # parts = 7
 #: name                size            offset          mask_flags
 0: bootloader          0x00300000      0x00000000      1
 1: environment         0x00080000      0x00300000      0
 2: redundant-environment0x00080000     0x00380000      0
 3: kernel              0x00400000      0x00400000      0
 4: fdt                 0x00080000      0x00800000      0
 5: ramdisk             0x00800000      0x00880000      0
 6: filesystem          0x1ef80000      0x01080000      0
--------------------------------------------------------------------
# From uboot console

(Copy all needed images: zImage-imx28evk.bin, zImage-imx28-evk.dtb, core-image-base-imx28evk.ubifs to tftp-dir in host : /srv/tftp/)

setenv ipaddr 192.168.0.206
setenv serverip 192.168.0.48
ping ${serverip}


tftp 0x42000000 zImage-imx28evk.bin
nand erase.part kernel
nand write 0x42000000 kernel ${filesize}

tftp 0x42000000 zImage-imx28-evk.dtb
nand erase.part fdt
nand write 0x42000000 fdt ${filesize}

tftp 0x42000000 core-image-base-imx28evk.ubifs
nand erase.part filesystem
ubi part filesystem
ubi create rootfs
ubi write 0x42000000 rootfs ${filesize}

-------------------------------------------------------
# verifying that whole rootfs is stored correctly in NAND
ubifsmount ubi0:rootfs
ubifsls
ubifsumount
-------------------------------------------------------
# SWTICH BOARD TO NAND MODE (0100) and give below commands in uboot console

setenv loadaddr 0x42000000
setenv fdt_addr 0x41000000
setenv bootargs 'gpmi console=ttyAMA0,115200 rootfstype=ubifs ubi.mtd=6 root=ubi0:rootfs rw mtdparts=gpmi-nand:3m(bootloader)ro,512k(environment),512k(redundant-environment),4m(kernel),512k(fdt),8m(ramdisk),-(filesystem)'
setenv bootcmd 'nand read ${loadaddr} kernel 0x400000; nand read ${fdt_addr} fdt 0x80000; bootz ${loadaddr} - ${fdt_addr}'
saveenv
boot

################################
# 2. FLASH LTIB IMAGE INTO NAND
################################

# Flash SD card with default LTIB Boot image (rootfs mount on MMC)

# Configure image to be buit for NAND
./ltib -m config 

# In packagelist > boot stream > root : default kernel command line changed

FROM: noinitrd console=ttyAM0,115200 root=/dev/mmcblk0p3 rw rootwait ip=none gpmi

TO: noinitrd console=ttyAM0,115200 root=/dev/mtdblock1 rootfstype=jffs2 rw gpmi

and build
./ltib -p boot_stream.spec -f


========================================================================================
# Copy built below images to /home/ in SD CARD, in which earlier mmc image were flashed

1. imx28_ivt_linux.sb
2. rootfs.jffs2
========================================================================================

# Flash image after board booted

ls /dev/mtd*
cd /home/

flash_eraseall /dev/mtd0
kobs-ng init -v -w imx28_ivt_linux.sb

flash_eraseall /dev/mtd1
nandwrite /dev/mtd1 rootfs.jffs2
