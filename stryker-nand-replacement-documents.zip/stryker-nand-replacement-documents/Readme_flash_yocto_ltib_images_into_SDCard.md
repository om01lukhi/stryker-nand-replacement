# i.MX28-EVK --- Prepare and Boot an LTIB SD Card

This document describes the SD/MMC boot procedure for an i.MX28-EVK using an LTIB-generated Linux image, based on the i.MX28 EVK Linux User's Guide procedure.

------------------------------------------------------------------------
## 1. LTIB files required

The LTIB build should provide the following files:

ltib/
├── rootfs/
│   ├── boot/
│   │   ├── imx28_uboot.sb
│   │   ├── imx28_linux.sb
│   │   ├── uImage
│   │   ├── zImage
│   │   └── ...
│   └── ...
└── ...

For the U-Boot SD boot procedure, use:

ltib/rootfs/boot/imx28_uboot.sb
ltib/rootfs/boot/uImage
ltib/rootfs/

imx28_ivt_linux.sb belongs to the alternative Linux boot-stream procedure.
Do not write both imx28_ivt_linux.sb and imx28_ivt_uboot.sb as part of one boot configuration unless you specifically intend to reproduce another procedure.

------------------------------------------------------------------------
## 2. Identify the SD card

Check the block devices:
lsblk -o NAME,SIZE,TYPE,MOUNTPOINTS,MODEL

Example:
 
sda        3.6T  disk
sdb        3.7G  disk
├─sdb1       1G  part
├─sdb2      16M  part
└─sdb3     2.7G  part
nvme0n1  931.5G  disk

In this example the SD card is: /dev/sdb

### IMPORTANT
Replace /dev/sdb below only if your SD card has a different device
------------------------------------------------------------------------
## 3. Unmount the existing SD-card partitions

sudo umount /dev/sdb1 2>/dev/null || true
sudo umount /dev/sdb2 2>/dev/null || true
sudo umount /dev/sdb3 2>/dev/null || true

Verify:
lsblk /dev/sdb

------------------------------------------------------------------------
# 4. Create the SD-card partition layout

The LTIB documentation requires three primary partitions:
 
Partition 1: FAT32, type 0x0B
Partition 2: OnTrack DM6 Aux3, type 0x53
Partition 3: Linux, type 0x83

For a 3.7-GB SD card, a practical layout is:
 
/dev/sdb1   ~1 GB       FAT32
/dev/sdb2   16 MB       type 0x53
/dev/sdb3   remaining   type 0x83

The boot-stream file is only a few MB, so 16 MB gives adequate space.

## WARNING
The following procedure destroys the existing partition table on
/dev/sdb.

Start:
sudo fdisk /dev/sdb

Inside fdisk, delete the existing partitions:
 
d
3
d
2
d
1

Create partition 1:
n
p
1
<Enter>
+1G

Set partition 1 to FAT32:
t
1
b

Create partition 2:
n
p
2
<Enter>
+16M

Set partition 2 to type 0x53:
t
2
53

Create partition 3 using the remaining space:
n
p
3
<Enter>
<Enter>

Set partition 3 to Linux type 0x83:
t
3
83

Print the partition table:
p

You should have approximately:
/dev/sdb1    FAT32
/dev/sdb2    OnTrack DM6 Aux3
/dev/sdb3    Linux

Write the table:
w

------------------------------------------------------------------------
## 5. Reload the partition table

Run:
sudo partprobe /dev/sdb

Check:
lsblk /dev/sdb

Expected:
sdb
├─sdb1   ~1G
├─sdb2   16M
└─sdb3   ~2.7G

Verify the partition types:
sudo fdisk -l /dev/sdb
Partition 2 must be: 53  OnTrack DM6 Aux3
and partition 3 must be: 83  Linux

------------------------------------------------------------------------
# 6. Format the root filesystem partition

The i.MX28 guide specifies EXT2 for the SD root filesystem.
Run:
sudo mkfs.ext2 /dev/sdb3
sync

Do not format /dev/sdb2. /dev/sdb2 is the special boot-stream partition.

------------------------------------------------------------------------
# 7. Build the sdimage utility

If sdimage has not already been built:
cd ~/Working_Directory/stryker-pro/03_workspace/ltib
./ltib -p uuc.spec -m prep
cd rpm/BUILD/uuc-2.6.35.3-1.1.0
gcc sdimage.c -o sdimage

Verify:
ls -lh sdimage

------------------------------------------------------------------------
# 8. Write the U-Boot boot stream

Use the LTIB-generated U-Boot boot stream:
~/Working_Directory/stryker-pro/03_workspace/ltib/rootfs/boot/imx28_uboot.sb
Run:
cd ~/Working_Directory/stryker-pro/03_workspace/ltib/rpm/BUILD/uuc-2.6.35.3-1.1.0
sudo ./sdimage \
    -f ~/Working_Directory/stryker-pro/03_workspace/ltib/rootfs/boot/imx28_uboot.sb \
    -d /dev/sdb
sync

------------------------------------------------------------------------
# 9. Write uImage

The LTIB kernel image is:
~/Working_Directory/stryker-pro/03_workspace/ltib/rootfs/boot/uImage

The i.MX28 guide specifies writing it at a 128-KB offset.
Run:
cd ~/Working_Directory/stryker-pro/03_workspace/ltib/rootfs/boot
sudo dd if=uImage of=/dev/sdb bs=1K seek=128
sync

Verify the command completed without errors.

------------------------------------------------------------------------
# 10. Clear the U-Boot environment

The guide uses a 127-KB zero-filled file.
Create it:
dd if=/dev/zero of=/tmp/zero.raw bs=1K count=127

Write it at the specified offset:
sudo dd if=/tmp/zero.raw of=/dev/sdb bs=1K seek=1
sync

This clears the U-Boot environment so that U-Boot uses the default environment.

------------------------------------------------------------------------
# 11. Mount the root filesystem partition

Create a mount point:
sudo mkdir -p /mnt/mmc

Mount:
sudo mount /dev/sdb3 /mnt/mmc

Verify:
df -h /mnt/mmc

------------------------------------------------------------------------
# 12. Copy the LTIB root filesystem

The LTIB unpacked root filesystem is:
~/Working_Directory/stryker-pro/03_workspace/ltib/rootfs/

Copy the contents of this directory to the SD-card root filesystem:
sudo cp -a \
    ~/Working_Directory/stryker-pro/03_workspace/ltib/rootfs/. \
    /mnt/mmc/

The /. at the end is important.

Correct result:
/mnt/mmc/
├── bin/
├── boot/
├── dev/
├── etc/
├── home/
├── lib/
├── proc/
├── root/
├── sbin/
├── sys/
├── tmp/
├── usr/
└── var/

Do not create:
/mnt/mmc/rootfs/

------------------------------------------------------------------------
# 13. Verify the root filesystem
Run:
ls -lah /mnt/mmc

You should see directories such as:
bin
boot
dev
etc
lib
proc
root
sbin
sys
tmp
usr
var

Check the boot directory:
ls -lh /mnt/mmc/boot

You should see LTIB boot files including:
uImage
zImage
imx28_uboot.sb
imx28_linux.sb

------------------------------------------------------------------------
# 14. Sync and unmount

sudo sync
sudo umount /mnt/mmc
sync

------------------------------------------------------------------------
# 15. Safely remove the SD card

After the final sync:
sync
Then remove the SD card from the host.

------------------------------------------------------------------------
# 16. Configure the i.MX28-EVK for SD/MMC boot

Insert the SD card into the i.MX28-EVK.
Set the EVK boot-mode switches/jumpers for SD/MMC boot according to the board's User Guide.
Connect the serial console to the host PC.
Power-cycle the board.

------------------------------------------------------------------------
