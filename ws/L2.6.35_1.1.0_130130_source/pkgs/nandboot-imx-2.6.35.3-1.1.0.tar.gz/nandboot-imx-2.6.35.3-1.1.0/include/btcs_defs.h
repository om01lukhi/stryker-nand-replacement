/*
 * Copyright (c) 2006-2010, Freescale Semiconductor, Inc.  All rights reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef __BTCS_DEFS_H__
#define __BTCS_DEFS_H__

#define BTCS_NUM_REGS 10

enum btcs_cmd {
	BTCS_CAN_IRQ,
	BTCS_REG_MODIFIED,
	BTCS_PRINTK,
};

struct btcs_event {
	int cmd;
	void *arg;
};

struct btcs_shm {
	int reg[BTCS_NUM_REGS];
};

struct btcs_cb_interface {
	int magic;
	char *version;
	int size;
	int state;
	int (*printk) (void *, int);
	int (*setup) (void);
	int (*start) (void);
	int (*stop) (void);
	int (*cleanup) (void);
	int (*callback) (struct btcs_event *);
	int (*ossignal) (struct btcs_event *);
	struct btcs_shm *shm;
};

#endif /* __BTCS_DEFS_H__ */

