## 1. Create Docker setup in your workspace
1.1 On your Ubuntu 24.04 host:
cd /home/ayush/Working_Directory/stryker-pro/03_workspace
mkdir -p docker/ltib-ubuntu10.04
cd docker/ltib-ubuntu10.04

1.2 Create Dockerfile :
```
# syntax=docker/dockerfile:1

FROM ubuntu:24.04 AS rootfs-builder

ENV DEBIAN_FRONTEND=noninteractive

RUN apt-get update && \
    apt-get install -y --no-install-recommends \
        debootstrap \
        ca-certificates \
        xz-utils \
        gnupg \
    && rm -rf /var/lib/apt/lists/*

# Use i386 Ubuntu 10.04 because old LTIB BSPs are often happier in a 32-bit userspace.
# If your host/kernel does not allow i386 containers, see the amd64 note below.
RUN debootstrap \
    --arch=i386 \
    --variant=minbase \
    --no-check-gpg \
    lucid \
    /lucid \
    http://old-releases.ubuntu.com/ubuntu/

RUN printf '%s\n' \
    'deb http://old-releases.ubuntu.com/ubuntu lucid main restricted universe multiverse' \
    'deb http://old-releases.ubuntu.com/ubuntu lucid-updates main restricted universe multiverse' \
    'deb http://old-releases.ubuntu.com/ubuntu lucid-security main restricted universe multiverse' \
    > /lucid/etc/apt/sources.list

RUN mkdir -p /lucid/etc/apt/apt.conf.d && \
    printf '%s\n' \
    'Acquire::Check-Valid-Until "false";' \
    'APT::Get::AllowUnauthenticated "true";' \
    > /lucid/etc/apt/apt.conf.d/99old-releases

FROM --platform=linux/386 scratch

COPY --from=rootfs-builder /lucid /

ENV DEBIAN_FRONTEND=noninteractive
ENV LC_ALL=C
ENV LANG=C

RUN apt-get update && \
    apt-get install -y --force-yes \
        sudo \
        bash \
        wget \
        curl \
        tar \
        gzip \
        bzip2 \
        unzip \
        patch \
        diffstat \
        file \
        perl \
        make \
        autoconf \
        automake \
        gettext \
        libgtk2.0-dev \
        rpm \
        bison \
        m4 \
        libfreetype6-dev \
        libdbus-glib-1-dev \
        liborbit2-dev \
        intltool \
        ccache \
        ncurses-dev \
        zlib1g \
        zlib1g-dev \
        gcc \
        g++ \
        libtool \
        libncurses5-dev \
        uuid-dev \
        liblzo2-dev \
        tcl \
        dpkg \
        aptitude \
        gawk \
        flex \
        texinfo \
        help2man \
        cvs \
        subversion \
        git-core \
        rsync \
        bc \
    && apt-get clean && \
    rm -rf /var/lib/apt/lists/*

RUN useradd -m -s /bin/bash -u 1000 builder && \
    echo 'builder ALL=(ALL) NOPASSWD:ALL' > /etc/sudoers.d/builder && \
    chmod 0440 /etc/sudoers.d/builder

USER builder
WORKDIR /work

CMD ["/bin/bash"]
```

1.3 Build the image:
cd /home/ayush/Working_Directory/stryker-pro/03_workspace/docker/ltib-ubuntu10.04
docker build -t ltib-ubuntu10.04-i386 .


## 2. Start the LTIB container
cd /home/ayush/Working_Directory/stryker-pro/03_workspace

2.1 Create container: 
docker run -it \
  --name ltib-imx28 \
  -v /home/ayush/Working_Directory/stryker-pro/03_workspace:/work \
  ltib-ubuntu10.04-i386

2.2 Inside the container, confirm:
cat /etc/issue
uname -m
gcc --version
rpm --version
All above details should be from ubuntu 10.04

2.3 Restart docker container: (Optional)
docker start -ai ltib-imx28

## 3. Put the i.MX28 LTIB BSP source in the workspace
Copy your i.MX28 BSP source bundle into:
/home/ayush/Working_Directory/stryker-pro/03_workspace

For example, if your file is something like: L2.6.35_1.1.0_130130_source.tar.gz

then inside the container:
cd /work
ls
You should see the BSP tarball.


## 4. Extract and install LTIB
4.1 Inside the container:
cd /work
tar -xvf L2.6.35_1.1.0_130130_source.tar.gz

4.2 If the extracted BSP contains ltib.tar.gz , extract/install it:
cd /L2.6.35_1.1.0_130130_source
tar -xvf ltib.tar.gz
./install

4.3 When the installer asks for the LTIB installation path, choose something under /work , for example:
/work/ltib


## 5. Configure LTIB for i.MX28 EVK
After installation:
cd /work/ltib
./ltib

[ERR] Change LTIB toolchain selection:
    cd /work/ltib
    ./ltib -m config
    Select this toolchain: ARM, gcc-4.4.4, multilib, neon optimized

[ERR] u-boot build failed / Update git-config:
    The build is failing for two related reasons:
    LTIB tried to apply/commit U-Boot changes but Git refused because the container user has no Git identity.
    After that failed, LTIB continued into the U-Boot build, but the U-Boot tree does not have the target mx28_evk_config ; the i.MX28 EVK target is normally mx28evk_config without the underscore.
    Do this inside the Docker container.

    1. Set Git identity for the container user
    git config --global user.email "builder@localhost"
    git config --global user.name "LTIB Builder"

    2. Verify:
    git config --global --list

    3. Clean only the failed U-Boot build 
    cd /work/ltib
    ./ltib -m clean -p u-boot

    If that command itself fails, remove the failed U-Boot build directory manually:
    cd /work/ltib
    rm -rf rpm/BUILD/u-boot-2009.08

    4. Check which U-Boot config target exists
    Before rebuilding, inspect the U-Boot Makefile after LTIB prepares it:
    cd /work/ltib
    ./ltib -m prep -p u-boot
    ./ltib -m scbuild -p u-boot

    5. Continue next build
    cd /work/ltib
    ./ltib

If want to update all the images:

    cd /work/ltib
    
    ./ltib -m config

    ./ltib -m scbuild -p u-boot
    ./ltib -m scdeploy -p u-boot

    ./ltib -m scbuild -p kernel
    ./ltib -m scdeploy -p kernel

    ./ltib -p boot_stream.spec -f

[ERR] Fast workaround if you do not need Python in the target rootfs
    1. For an initial i.MX28 EVK bootable image, Python is usually not required. Disable it and continue the build:
    cd /work/ltib
    ./ltib -m config
    ./ltib 
    ./ltib -p boot_stream.spec -f

Check build artifects:
ls -lh /work/ltib/rootfs/boot/


## 6. Building the Manufacturing Firmware
6.1 Configure the firmware build profile as follows:
cd /work/ltib/
./ltib --selectype

6.2 Choose the following:
Choose the platform type
    Selection (imx28) --->
Choose the packages profile
    Selection (mfg firmware profile) --->

After LTIB completes the build, updater.sb and updater_ivt.sb will be created in /work/ltib/



