/*******************************************************************************
*
* Copyright (C) 2003, MOTOROLA INC.   All Rights Reserved
*
*  FILE NAME      :  generic_flash_programming.c
*  DATE CREATED   :  06-18-03
*  	
*  DESCRIPTION: Function and Test code for AMD Am29BDS128H Flash
*  This code will query the burst flash on the eval board for its manufacturer ID 
*  AND device ID.  If device ID is incorrect, the code will report this failure. 
*  If manufacturer ID not correct, the code will also report this.
*	
*  Next, this code will program the flash with a known data pattern.
*
*
*  ****************************
*  IMPORTANT NOTE ON FUNCTIONS:
*  ****************************
*
*  When passing an address to a function, the function assumes that the address
*  passed to it is the Flash address as a standard integer, not the System address.
*  E.g., regardless of where in the system memory the Flash resides, the functions
*  should be passed address values between 0x000000 and 0x7FFFFF. The functions will
*  automatically adjust to write or read to the correct system address based off of
*  the value of CS_BASE. Address values between 0x000000 and 0x7FFFFF represent the
*  entire FLASH (x16) address range. This test code assumes a system with a x32
*  FLASH configuration.  Thus the functions will convert the x16 FLASH address to the
*  appropriate and desired SYSTEM (x32) address.  
*
*  If a function needs to be passed a sector value, it will accept either the
*  NEGATIVE number of the sector or any Flash address within the sector.
*
*  Ex: Sector 2 starts at Flash address 0x002000 and ends at 0x002FFF
*        Passing -2, 0x002000, 0x002FFF or 0x0023F9 would all work correctly
*        Passing 2 would be interpreted as an address in sector 0
*
*  The sector value functions will actually also operate correctly when passed
*  a system address that points to the sector.
*
*  In general though, the intent is that as long as CS_BASE is defined, the function
*  user does not need to bother with where the Flash resides in system memory.
*
*	Revision history:
*	rev 0.0 - original release
*	rev 0.1 - updated for i.mx21
*
********************************************************************************
*  I N C L U D E   F I L E S
*******************************************************************************/

#include "common.h"
#include "tht_memory_map_defines.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Modify SysInit() for different system initialization settings */
extern int SysInit(void);
extern int MemInit(void);



/******************************************************************************
*  DEFINES
******************************************************************************/

/* i.MX21 specific defines */

/***** Critical *****/
// CS_BASE informs the program of the base system address of the Flash
#define CS_BASE	(volatile unsigned int *)CS0_BASE_ADDR	// Chip select 0, i.mx21

//#define SDRAM_EIM_MEMCPY_TEST		// uncomment to program the flash for one of two types of testing

/***************************************************
********* AMD Burst Flash Constant Defines *********
***************************************************/

// Read adjusting for CS_BASE

#define read(x) *(CS_BASE+x)

//reset & unlock writes
#define reset() *CS_BASE=0x00F000F0
#define unlock() *(CS_BASE + 0x555)=0x00AA00AA; *(CS_BASE + 0x2AA)=0x00550055

//manufacturer and device ID values
#define MANU_ID 0x00010001
#define MANU_ID_AD (CS_BASE)
#define DEV_ID_1 0x227E227E
#define DEV_ID_AD_1 (CS_BASE + 0x1)
#define DEV_ID_2 0x22182218
#define DEV_ID_AD_2 (CS_BASE + 0xE)
#define DEV_ID_3 0x22002200
#define DEV_ID_AD_3 (CS_BASE + 0xF)

// base addresses of FLASH banks
#define BANK_D	(CS_BASE)
#define BANK_C	(CS_BASE + 0x100000)
#define BANK_B	(CS_BASE + 0x400000)
#define BANK_A	(CS_BASE + 0x700000)

// used for convenience during polling
#define DQ7 ((1<<23)|(1<<7))
#define DQ6 ((1<<22)|(1<<6))
#define DQ5 ((1<<21)|(1<<5))
#define DQ4 ((1<<20)|(1<<4))
#define DQ3 ((1<<19)|(1<<3))
#define DQ2 ((1<<18)|(1<<2))
#define DQ1 ((1<<17)|(1<<1))
#define DQ0 ((1<<16)|(1<<0))

/******************************
****** Globals Variables ******
******************************/

unsigned char UBM = 0; //Unlock Bypass Mode flag
volatile unsigned int gFailCount;

/*****************************
****** Function Defines ******
*****************************/

/* Sector Base Address Convertor */

// Takes in flexible input to return base address of desired sector
// Parameter: int sector = negative of Sector # [0:-269]
//						or	Flash address in desired sector [0:0x7FFFFF]
//						or	System address in desired sector (CS_BASE+[0:0x7FFFFF])
// Returns: Base address of the sector calculated, or 'null' if the input is invalid
//		as a "volatile unsigned int *"
// Examples:	assuming CS_BASE = 0x16000000
//		Correct:
//				sector_calc(-15) would return the base address of sector 15 (0x16040000)
//				sector_calc(0x04A820) would return the base address of sector 15 also
//				sector_calc(0x1604A820) would return the base address of sector 15 as well
//				sector_calc(0) returns CS_BASE
//		Incorrect:
//				sector_calc(-273) would return null, as there is not a sector 273
//				sector_calc(0x9FFFFF) would return null, as the address is outside of the flash

volatile unsigned int * sector_bcalc(int sector){	
	if(sector<1){
		sector*=-1;
		if (sector<8){
			return (CS_BASE + sector * 0x1000);
		} else if (sector<262){
			return (CS_BASE + (sector - 7) * 0x8000);
		} else if (sector<270){
			return (CS_BASE + (sector - 262) * 0x1000 + 0x7F8000);
		} else {
			return 0;
		}
	} else if(sector<0x800000){
		sector+=(int)CS_BASE;
	} else if((sector > (int)CS_BASE) && (sector < (int)CS_BASE+0x800000)){
		if((sector > (int)CS_BASE+0x7FFF) && (sector < (int)CS_BASE+0x7F8000)){
			return (volatile unsigned int *)(sector&0xFFFF8000);
		} else {
			return (volatile unsigned int *)(sector&0xFFFFF000);
		}
	}
	return 0;
}

/***************************************************
********* AMD Burst Flash Function Defines *********
***************************************************/

/*****/

/* Asynchronous Read */

// This is actually just a define that adjusts for CS_BASE

// Syntax:

// int store_data=read(x); where x is the desired Flash address to be read

/*****/

/* Asynchronous Read Multiple */

// Read out a chunk of data to dynamically allocated memory

// Parameters: volatile unsigned int* address = pointer to "lowest" address to be read
// 			   int words = number of words to be read
// Returns:	pointer to an array containing the read data.
//	This pointer has been acquired using malloc, therefore:
//	**** NOTE: ****
//	returned pointer should be released before program ends using
//		free(<pointer>);
//	Do not lose, overwrite, alter, etc...this pointer!
//	after free() you will no longer have address to the data in it

int* read_m(int address, int words){
	int *data = malloc(words * sizeof(int));
	address = ((int)CS_BASE + 4*address);
	reset();
	memcpy(data,(int*)address,words*4);
	return data;
}	

/*****/

/*** Autoselect Commands ***/

/* Manufacturer ID */

// Returns: 1 if manufacturer id matches expected value (MANU_ID)

int auto_manu_id(void){
	int temp;
	*CS_BASE=0x00F000F0;
	unlock();
	*(CS_BASE + 0x555)=0x00900090;
	temp=*MANU_ID_AD;
	reset();
	return (temp==MANU_ID);
}

/*****/

/* Device ID */

// Returns: 1 if device id matches expected values (DEV_ID_x, x=(1..3))

int auto_dev_id(void){ 
	int temp[3];
	*CS_BASE=0x00F000F0;
	unlock();
	*(CS_BASE + 0x555)=0x00900090;
	temp[0]=*DEV_ID_AD_1;
	temp[1]=*DEV_ID_AD_2;
	temp[2]=*DEV_ID_AD_3;
	reset();
	return (temp[0]==DEV_ID_1&&temp[1]==DEV_ID_2&&temp[2]==DEV_ID_3);	// relational operator, compares and returns true (1) or false (0)
}

/*****/

/* Sector Lock Verify */

// Parameter: int sector = negative sector # or a flash/system address within the sector to be erased
// Returns: 1 if sector is locked
// WARNING: function is fairly flexible for input, but does not error check,

int auto_sect_lock_ver(int sector){
	volatile unsigned int * sector_p=sector_bcalc(sector);
	sector_p+=0x555;
	reset();
	unlock();
	*sector_p=0x00900090;
	sector = *sector_p;
	reset();
	return (sector==0x00010001);	// relational operator, compares and returns true (1) or false (0)
}

/*****/

/* Indicator Bits */

// Returns: indicator bits - DQ15-DQ8 = 0, DQ7: factory lock bit,
// DQ6: customer lock bit, DQ5: Handshake bit (1 = reduced wait, 0 = standard),
// DQ4-DQ0 = 0

int auto_indicator(void){
	int temp;
	reset();
	unlock();
	*(CS_BASE + 0x555)=0x00900090;
	temp = *(CS_BASE + 0x3);
	reset();
	return temp;
}	

/*** End of Autoselect Commands ***/	

/*****/

/*** Unlock Bypass Mode ***/

// while in UBM mode data cannot be read
// Commands that benefit from UBM mode:
// Program, Sector Erase, Erase
// Highly recommended for write multiple

/* Unlock Bypass Entry */

// Enables Unlock Bypass Mode, sets the UBM flag to 1

void ub_entry(void){
	reset();
	unlock();
	*(CS_BASE + 0x555)=0x00200020;
	UBM = 1;
}

/*****/

/* Unlock Bypass Reset */

// Exits Unlock Bypass Mode, sets the UBM flag to 0

void ub_reset(void){
	reset();
	*CS_BASE = 0x00900090;
	*CS_BASE = 0x00000000;
	UBM = 0;
}

/*** End of UBM commands ***/

/*****/

/* Program */

// Parameters: int address = flash address to be written to
//				int data = data to be written
// Returns: 1 on succesful write, null on failure

int write(int address,int data){ 
	if(!UBM){
		unlock();
	}
	*(CS_BASE + 0x555)=0x00A000A0;
	*(CS_BASE + address)=data;
	
	// Polling for completion
	while(((*(CS_BASE + address)^data)&DQ7) != 0){
		if((*(CS_BASE + address)&DQ5)==DQ5){
			if(((*(CS_BASE + address)^data)&DQ7)==0){
				return 1;
			} else {
				return 0;
			}
		}
	}
	return 1;
}

/*****/

/* Program multiple */

// Writes a chunk of data sequentially starting at a pointer

// Parameters: int address = starting flash address to be written to
//				int words = number of words of data to be written
//				int * data = pointer to start of data
// Returns: 1 on success, 0 if an attempt to write a word of data fails
//				twice in a row.

int write_m(int address,int words, int * data){
	int z=0,error=0;
	reset();
	ub_entry();
	while(z<words){
		if(write(address + z,data[z])){
			z+=1;
			error=0;
		} else {
			error+=1;
			if(error>1){
				ub_reset();
				return 0;
			}
		}
	}
	ub_reset();
	return 1;
}

/*****/

/*** Erasure Commands ***/

/* Chip Erase */

// The Fifth Horseman of the Apocalypse. Nothing will survive.
// Note that this takes some time to occur, 2-3 minutes
// Returns: 1 on succesful erase, null on failure

int erase_chip(void){
//	volatile unsigned int intermediate;
	reset();
	if(!UBM){
		unlock();
	}
	*(CS_BASE + 0x555)=0x00800080;
	if(!UBM){
		unlock();
	}
	*(CS_BASE + 0x555)=0x00100010;
	
	// Polling for completion
	while(((*CS_BASE^0x00800080)&DQ7)!=0){
		if((*CS_BASE&DQ5)==DQ5){
			if(((*CS_BASE^0x00800080)&DQ7)==0){
				return 1;
			} else {
				return 0;
			}
		}
	}

	return 1;
}

/*****/

/* Sector Erase */

// Practices a less wanton destruction, erasing only a specific sector.
// Parameters:	int sector = either the negative # of the sector to be erased,
//				            or a flash or system address within the sector to be erased
//				valid range: [0:-269], [0:0x7FFFFF] or [(CS_BASE) + 4 * (0:0x7FFFFF)]
// Returns: 1 on succesful erase, null on failure

int erase_sector(int sector){
	volatile unsigned int * sector_p=sector_bcalc(sector);
	sector_p+=0x555;
	reset();
	if(!UBM){
		unlock();
	}
	*(CS_BASE + 0x555)=0x00800080;
	if(!UBM){
		unlock();
	}
	*sector_p=0x00300030;
	// Polling for completion
	while(((*sector_p^0x00800080)&DQ7)!=0){
		if((*sector_p&DQ5)==DQ5){
			if(((*sector_p^0x00800080)&DQ7)==0){
				return 1;
			} else {
				return 0;
			}
		}
	}

	return 1;
}

/*****/

/* Erase Suspend */

// Valid only during a sector erase.
// Allows erase to be temporarily suspended so data can be read from a different sector.
// Parameter: 	int sector = preferably the same input used to initialize the erase.
//				technically, it only needs to be a sector # (negative) or address in the same bank
//				as the sector being currently erased. constants BANK_A to BANK_D will
//				also function correctly as inputs

void erase_suspend(int sector){
	*sector_bcalc(sector)=0x00B000B0;
	reset();
}

/*****/

/* Erase Resume */

// Valid only during erase suspend mode, resumes suspended erase.
// Parameter: identical to erase suspend

void erase_resume(int sector){
	reset();
	*sector_bcalc(sector)=0x00300030;
}

/*** End of Erasure Commands ***/

/*****/

/* Set Configuration Register */

// Command not valid during program/write, erase, or sector lock

// Parameter: unsigned char config = detailed bit-wise:
//		[7]	Set Device Read Mode (1 = Async, 0 = Synchronous)
//		[6]	RDY signal (1 = active with data, 0 = active one clock cycle before data)
//		[5]	Clock (1 = output triggers on rising edge, 0 = output triggers on falling edge)
//		[4:3]	Read Mode:
//					00 = Continous
//					01 = 8-word linear with wrap around
//					10 = 16-word linear with wrap around
//					11 = 32-word linear with wrap around
//		[2:0]	Programmable Wait State:
//					Data is valid on the [...] active CLK edge after AVD# transition to Vih
//					000 = 2nd
//					001 = 3rd
//					010 = 4th
//					011 = 5th
//					100 = 6th
//					101 = 7th
//					110 = <reserved>
//					111 = <reserved>
					
void set_config(unsigned int build_address){
	build_address = build_address << 12;
	build_address += 0x555;
	unlock();
	(*(volatile unsigned int *)(CS_BASE + build_address))=0x00C000C0;
}

void Enable_I_cache (void)
{
    __asm
    {
	   	mrc p15,0,r0,c1,c0,0
	    mov r0, #0x00001000
   		mcr p15,0,r0,c1,c0,0 
	}
}

/*****/

/****************************
******   The Program   ******
****************************/


int main(void){
	
	/***********************
	** Setting up the MX1 **
	***********************/
	
	//counter
	volatile unsigned int q;
	uint32_t pattern;

		
	// using a 32.768kHz crystal produces a 16.777MHz Pre-Multiplier
	// settings for the MCU and System PLL (for latest Tahiti spec) 
	// dictate that the default output of the PLL with a 32.768MHz
	// crystal is 264.24MHz.  
	// BCLK set to divide-by-five will produce a 52.8MHz HCLK
//	*(p_uint32_t)CRM_CSCR &= 0xFFFFC3FF;		
//	*(p_uint32_t)CRM_CSCR |= 0x00001000;
		
/*
	DDIR_A = 0x00007FF0;
	GIUS_A = 0x00007FF0;	// configure outputs as general purpose
	OCR1_A = 0xFFFFFFFF;
	OCR2_A = 0xFFFFFFFF;
	DR_A = 0x00007FF0;
	DDIR_C = 0xFFFFE1FF;
	GIUS_C = 0xFFFFE1FF;	//configure UART1
	OCR1_C = 0xFFFFFFFF;
	OCR2_C = 0xFFFFFFFF;
	EIM = 0x00000000;	//BCLK only during access
	FMCR = 0x00000000;	//CS2 and CS3 are non-SDRAM
*/
	

	SysInit();
	MemInit();
	
	//set to async mode, random access time 55ns, assuming HCLK = 88.08MHz
	*(p_uint32_t)WEIM_CS0U = 0x00000801;	//chip select 0 upper register
	*(p_uint32_t)WEIM_CS0L = 0x00000E01;	//chip select 0 lower register

//	Enable_I_cache();
	
	/********************************************************************
	** Test 1: Verify manufacturer and device code for AMD Am29BDS128H **
	********************************************************************/
	
	if(auto_manu_id()){
		printf("Manufacturer ID is correct!\n");
	} else {
		printf("**Manufacturer ID is incorrect**\n");
	}	
	if(auto_dev_id()){
		printf("Device ID is correct!\n");
	} else {
		printf("**Device ID is incorrect**\n");
	}


	/**********************************
	** Test 2: Flash Erase and Write **
	**********************************/

	#ifdef SDRAM_EIM_MEMCPY_TEST	// use this for memcpy test of SDRAM and EIM
		// Erase all of BANK D
		for (q = 0; q <= 38; q++){
			if(erase_sector(-q)){
				printf("Sector %d", q);
				printf(" Erased\n");
			} else {
				printf("Sector %d", q); 
				printf(" Erase failed.\n");
			}
		}
		reset();

		printf("Now, writing known data values into flash.\n");
		pattern = 0;	// initilaize apttern variable
		// now write to entire flash, just a test to ensure we can write to the entire flash
		for (q = 0; q < 1024*1024*2; q++)	// 2MB of flash programming
		{
			// data written to each address is the address that the data is written to
			// int write(int address,int data)
			// write(q,q);
			write(q,pattern);
			
			pattern += 0x11112222;
		}
		
		gFailCount = 0;	// initialize 
		pattern = 0;
		// now let's read the entire flash content to ensure the writes took
		for (q = 0; q < 1024*1024*2; q++)
		{
			if(read(q) != pattern)
			{
				printf("Failure, write didn't take!, Address = 0x%x\n", q); 
				gFailCount++;
			}
			pattern += 0x11112222;
		}
		
		if (gFailCount ==0)
		{
			printf("Write test passed!\n");
		}
		
	#else		// use this for the intensive DMA and memcpy test
		// Erase all of BANK D
		for (q = 0; q <= 38; q++){
			if(erase_sector(-q)){
				printf("Sector %d", q);
				printf(" Erased\n");
			} else {
				printf("Sector %d", q); 
				printf(" Erase failed.\n");
			}
		}
		reset();
		
		// address starting at first MB of flash
		printf("Now, writing known data values into flash.\n");
		pattern = 0;	// initilaize apttern variable
		// now write to entire flash, just a test to ensure we can write to the entire flash
		for (q = 0; q < 1024*1024*1; q++)	// 1MB of flash programming, for memcpy
		{
			// data written to each address is the address that the data is written to
			// int write(int address,int data)
			// write(q,q);
			write(q,pattern);
			
			pattern += 0x11112222;
		}
		
		// address starting at second MB of flash
		pattern = 0;
		for (q = 0x100000; q <= 0x100100; q++)	// 256 bytes of flash programming, for DMA transfer
		{
			// data written to each address is the address that the data is written to
			// int write(int address,int data)
			// write(q,q);
			write(q,pattern);
			
			pattern = (q + 1);
		}
		
		
		
		gFailCount = 0;	// initialize 
		pattern = 0;
		// now let's read the entire flash content to ensure the writes took
		for (q = 0; q < 1024*1024*2; q++)
		{
			if(read(q) != pattern)
			{
				printf("Failure, write didn't take!, Address = 0x%x\n", q); 
				gFailCount++;
			}
			pattern += 0x11112222;
		}
		
		if (gFailCount ==0)
		{
			printf("Write test passed!\n");
		}	
	
	#endif
	
	reset();


	return (0);
}





















