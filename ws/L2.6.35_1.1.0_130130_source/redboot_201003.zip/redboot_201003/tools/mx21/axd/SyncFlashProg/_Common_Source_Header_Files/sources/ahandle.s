; Last modified: Nov 14, 2001
; Template v0.3 for DBMX1


;;; Copyright ARM Ltd 1998. All rights reserved.

    AREA SWI_Area, CODE, READONLY
    
    EXPORT Reset_Handler    
	EXPORT Undefined_Handler
    EXPORT SWI_Handler
    EXPORT Prefetch_Handler
	EXPORT Abort_Handler
    EXPORT IRQ_Handler
    EXPORT FIQ_Handler
    IMPORT C_IRQ_Handler	;Dispatch ITC status bits
    IMPORT C_FIQ_Handler	;Dispatch ITC status bits
	IMPORT C_Undefined_Handler
	IMPORT C_SWI_Handler
	IMPORT C_Prefetch_Handler
	IMPORT C_Abort_Handler
	IMPORT __main
	
; Core starts up in supervisor mode with interrupts disabled

I_Bit		EQU 0x80
F_Bit		EQU 0x40
T_bit		EQU 0x20		
Mode_USR	EQU 0x10
Mode_FIQ	EQU 0x11
Mode_IRQ	EQU 0x12
Mode_SVC	EQU 0x13		
SVC_Stack	EQU 0x120FFFFF ; 4K byte SVC stack at the top of RAM
IRQ_Stack	EQU 0x120FEFFF ; followed by 4K IRQ stack
FIQ_Stack	EQU 0x120FDFFF ; followed by 4K FIQ stack
USR_Stack	EQU	0x120FCFFF ; followed by 4K USRstack		
CS0H		EQU 0x220000	; CS0 control register Highest word
CS0L		EQU 0x220004	; CS0 control register Lower word

Reset_Handler

; --- Initialise stack pointer registers
; Enter SVC mode and set up the SVC stack pointer
        MSR     CPSR_c, #Mode_SVC:OR:I_Bit:OR:F_Bit ; No interrupts
        LDR     SP, =SVC_Stack

; Enter IRQ mode and set up the IRQ stack pointer
        MSR     CPSR_c, #Mode_IRQ:OR:I_Bit:OR:F_Bit ; No interrupts
        LDR     SP, =IRQ_Stack

; Enter FIQ mode and set up the FIQ stack pointer
        MSR     CPSR_c, #Mode_FIQ:OR:I_Bit:OR:F_Bit ; No interrupts
        LDR     SP, =FIQ_Stack

; Set up other stack pointers if necessary
        ; ...

; --- Initialise memory system
        ; ...

; --- Initialise critical IO devices
        ; ...

; --- Initialise interrupt system variables here
        ; ...

; For the sake of silicon evaluation, the following code for switching into
; User mode has been commmented out.  The program will continue to run with
; the processor in Supervisor mode.
; --- Now change to User mode and set up User mode stack.
;        MSR     CPSR_c, #Mode_USR:OR:I_Bit:OR:F_Bit ; No interrupts
;        LDR     SP, =USR_Stack
; Finally, Re-Enter SVC mode
        MSR     CPSR_c, #Mode_SVC:OR:I_Bit:OR:F_Bit ; No interrupts
 
        IMPORT  __main

; --- Now enter the C code
        B      __main   ; note use B not BL, because an application will never return this way


SWI_Handler

    STMFD   sp!, {r0-r3, r12, lr}  ; Store registers
    MOV     r1, sp                 ; Set pointer to parameters
    MRS     r0, spsr               ; Get spsr
    STMFD   sp!, {r0}              ; Store spsr onto stack
    TST     r0, #T_bit             ; Occurred in Thumb state?
    LDRNEH  r0, [lr,#-2]           ; Yes: Load halfword and...
    BICNE   r0, r0, #0xFF00        ; ...extract comment field
    LDREQ   r0, [lr,#-4]           ; No: Load word and...
    BICEQ   r0, r0, #0xFF000000    ; ...extract comment field

        ; r0 now contains SWI number
        ; r1 now contains pointer to stacked registers

    BL      C_SWI_Handler          ; Call main part of handler
    LDMFD   sp!, {r0}              ; Get spsr from stack
    MSR     spsr_cf, r0            ; Restore spsr
    LDMFD   sp!, {r0-r3, r12, pc}^ ; Restore registers and return


IRQ_Handler

    STMFD   sp!, {r0-r3, r12, lr}  ; Store registers
    MOV     r1, sp                 ; Set pointer to parameters
    MRS     r0, spsr               ; Get spsr
    STMFD   sp!, {r0}              ; Store spsr onto stack
	
    BL      C_IRQ_Handler          ; Call main part of handler	
    LDMFD   sp!, {r0}              ; Get spsr from stack
    MSR     spsr_cf, r0            ; Restore spsr
    LDMFD   sp!, {r0-r3, r12, pc}^ ; Restore registers and return


FIQ_Handler

    STMFD   sp!, {r0-r3, r12, lr}  ; Store registers
    MOV     r1, sp                 ; Set pointer to parameters
    MRS     r0, spsr               ; Get spsr
    STMFD   sp!, {r0}              ; Store spsr onto stack
	
    BL      C_FIQ_Handler          ; Call main part of handler	
    LDMFD   sp!, {r0}              ; Get spsr from stack
    MSR     spsr_cf, r0            ; Restore spsr
    LDMFD   sp!, {r0-r3, r12, pc}^ ; Restore registers and return

Undefined_Handler
    STMFD   sp!, {r0-r3, r12, lr}  ; Store registers
    MOV     r1, sp                 ; Set pointer to parameters
    MRS     r0, spsr               ; Get spsr
    STMFD   sp!, {r0}              ; Store spsr onto stack
	
    BL      C_Undefined_Handler    ; Call main part of handler	
    LDMFD   sp!, {r0}              ; Get spsr from stack
    MSR     spsr_cf, r0            ; Restore spsr
    LDMFD   sp!, {r0-r3, r12, pc}^ ; Restore registers and return

Prefetch_Handler
    STMFD   sp!, {r0-r3, r12, lr}  ; Store registers
    MOV     r1, sp                 ; Set pointer to parameters
    MRS     r0, spsr               ; Get spsr
    STMFD   sp!, {r0}              ; Store spsr onto stack
	
    BL      C_Prefetch_Handler    ; Call main part of handler	
    LDMFD   sp!, {r0}              ; Get spsr from stack
    MSR     spsr_cf, r0            ; Restore spsr
    LDMFD   sp!, {r0-r3, r12, pc}^ ; Restore registers and return

Abort_Handler
    STMFD   sp!, {r0-r3, r12, lr}  ; Store registers
    MOV     r1, sp                 ; Set pointer to parameters
    MRS     r0, spsr               ; Get spsr
    STMFD   sp!, {r0}              ; Store spsr onto stack
	
    BL      Abort_Handler         ; Call main part of handler	
    LDMFD   sp!, {r0}              ; Get spsr from stack
    MSR     spsr_cf, r0            ; Restore spsr
    LDMFD   sp!, {r0-r3, r12, pc}^ ; Restore registers and return

    END

