/*
 * Copyright 2009 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef BTCS_H

#define CONFIG_BTCS
#define CONFIG_BTCS_START 0xC2080000
#define CONFIG_BTCS_SIZE  0x00100000

#endif
