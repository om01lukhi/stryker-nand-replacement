/*
 * Copyright 2004-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_nfc.c
 * 
 * @brief NANDBoot NFC code.
 *
 * This code implements the SPL part of the NANDboot. This reads the pages from
 * NAND Flash to RAM and detects the bad block before copying the pages.
 * 
 * @ingroup NANDboot
 */

#include "mxc_uart.h"
#include "mxc_nfc.h"
#include "btcs_config.h"
#ifdef CONFIG_BTCS
#include "btcs_defs.h"
#endif

#define MXC_CMD_WAIT_US         100
#define MXC_ADDR_WAIT_US        100
#define MXC_BUFADDR_WAIT_US     100
#define TEST_BAD                1

/* K9LBG08U0D and K9LAG08U0M are both of 8192 blocks */
#define BLOCK_NUM		8192
char badblock_list[BLOCK_NUM];
static char bbt_pattern[] = {'B', 'b', 't', '0'};
#ifdef NB_DEBUG
#define NB_DEBUG_BUF_ADDR     0x81000000
#define NB_DEBUG_BUF_LEN      0x100
static char *dbg_ptr = (char *)NB_DEBUG_BUF_ADDR;
static char idx = 0;
/*
 * This function writes a one byte message number and 7 char message into the
 * debug buffer. This is used for debugging when there is no serial output yet
 * and possibly the debugger is not able to single stpe through the code!
 */
void nb_dbg1(char *msg)
{
	int i;

	/* dbg_ptr boundary check */
	if ((dbg_ptr + 8) > (char *)(NB_DEBUG_BUF_ADDR + NB_DEBUG_BUF_LEN)) {

		dbg_ptr = (char *)NB_DEBUG_BUF_ADDR;
	}

	*dbg_ptr = idx++;	/* Put the message number */

	/* put the message, until null */
	for (i = 0; i < 7; i++) {
		*(dbg_ptr + i) = *(msg + i);
	}
	/* Point to the next message to be written */
	dbg_ptr += 8;
}

void nb_dbg(char *msg)
{
	int i;

	/* dbg_ptr boundary check */
	if ((dbg_ptr + 8) > (char *)(NB_DEBUG_BUF_ADDR + NB_DEBUG_BUF_LEN)) {

		dbg_ptr = (char *)NB_DEBUG_BUF_ADDR;
	}

	*dbg_ptr++ = idx++;	/* Put the message number */
}
#else				/* !NB_DEBUG */
#define nb_dbg(_msg)
#endif

static int g_page_size=0;
/*!
 * This function polls the NANDFC to wait for an operation to complete
 * function. It sets the flags for the commands that requires different read
 * and write operations.
 *
 * @param       maxRetries     number of retry attempts (separated by 1 us)
 */
int wait_op_done(U32 maxRetries)
{
	while (maxRetries-- > 0) {
		if (_reg_MXC_NFC_CONFIG2 & 0x8000)
			break;
		udelay(1);
	}

	if (maxRetries <= 0) {

		nb_dbg("1-fail");
		return -1;
	}
	return 0;
}

/*!
 * The NFC has to be preset before performing any operation
 */
void mxc_nfb_preset(void)
{
	/* Unlock the internal RAM Buffer */
	_reg_MXC_NFC_CONFIG = 0x2;
	/* Blocks to be unlocked */
	_reg_MXC_NFC_UNLOCKSTART_BLKADDR = 0x0;
	/* Last Unlock Block */
	_reg_MXC_NFC_UNLOCKEND_BLKADDR = 0xFFFF;
	/* Unlock Block Command */
	_reg_MXC_NFC_WRPROT = 0x4;
	/* Asymmetric mode, Mask Interrupt, ECC on */
	_reg_MXC_NFC_CONFIG1 = (_reg_MXC_NFC_CONFIG1 & ~0x100) | 0x011;
	/* Set SPAS */
	_reg_MXC_NFC_RSLTSPARE_AREA = 0x20;
}

/*!
 * For every read/write operation on NAND Flash, command has to be send . 
 * This function sends command to the NAND Flash. It writes the command to the 
 * NFC's Command Register. Configures the NFC's Configuration Register to 
 * perform the Command Input Operation.
 * 
 * @param       cmd    area from where to read the page
 * 
 * @return      This function returns 0 if command operation is not  complete 
 * else returns 1. 
 */
int mxc_nfb_command(U8 cmd)
{
	_reg_MXC_NFC_FLASH_CMD = cmd;
	/* Configure NAND Flash Config2 Register 
	 * Set INT to 0, FCMD to 1, rest to 0
	 */
	_reg_MXC_NFC_CONFIG2 = 0x1;

	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_CMD_WAIT_US) == 0) ? 1 : 0;
}

/*!
 * Reading or writing to any location in NAND Flash requires to pass an 
 * address of that location in NFC. This function writes the NAND Flash Address
 * to the NFC's Address Register. Sets the Configuration Register for the 
 * Address Input Operation 
 * 
 * @param       addr    addr from where to read the page
 * 
 * @return      This function returns 0 if address operation is not complete 
 * else returns 1. 
 */
int mxc_nfb_address(U16 addr)
{
	_reg_MXC_NFC_FLASH_ADDR = addr;
	/* Configure NAND Flash Config2 Register 
	 * Set INT to 0, FADD to 1, rest to 0
	 */
	_reg_MXC_NFC_CONFIG2 = 0x2;
	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_ADDR_WAIT_US) == 0) ? 1 : 0;
}

/*!
 * This function configures the NFC to copy the NAND Flash data in the main 
 * area number passed as parameter during read operation or write the data 
 * from main area to the NAND Flash.
 * 
 * @param       addr    value for the internal main area buffer.
 * 
 * @return      This function returns 0 if the operation is not complete 
 * else returns 1. 
 */
int mxc_nfb_bufferaddr(U16 addr)
{
	_reg_MXC_NFC_BUFFER_ADDR = addr;
	/* 
	 * Configure NAND Flash Config2 Register 
	 * Set INT to 0, FDO to 1, rest to 0
	 */
	_reg_MXC_NFC_CONFIG2 = 0x8;

	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_BUFADDR_WAIT_US) == 0) ? 1 : 0;
}

/*!
 * This function reads pages to NAND flash RAM buffer. It configures the NFC 
 * with address of the internal RamBuffer where the data has to be copied and 
 * then configures the NFC Configuration Register to perform the read 
 * operation. 
 * Address of NAND flash is send as 3 bytes. 1st byte is the offset of the 
 * page. 2nd bytes has LSB 5 bits as page number. MSB 3 bits of 2nd byte and 
 * LSB 7 bits of 3rd byte forms the 10 bits of block address. 
 * This function also checks for the bad block. The block is said to be bad if 
 * the value at OxBth location in the spare area for page 0 or 1 of the block 
 * is not 0xFF (for 16 bit NAND flash only).  
 * If the destination pointer is null this function will just check whether 
 * the block is good or bad without copying data to RAM.
 *  
 * @param       page    5 bit page address in the block
 * @param       block   10 bit block address 
 * 
 * @return      This function returns 0 if the page read is in bad block 
 *              It returns 1 is page is in good block
 *              It returns -1 if any of the command or address has failed  
 */
int mxc_nfb_readpage(U16 page, U16 block)
{
	U32 i, addr, bi;
	volatile U16 *spbuff8;
	volatile U16 *spbuff16;

	if(g_page_size != NFC_PAGESIZE_512B)
		addr = ((U32)block << 7) | page;
	else
		addr = ((U32) block << 5) | page;

	/* Check  for Badblock */
	if (badblock_list[block] == 1) {
		mxc_outstring(" Bad Block : ");
		mxc_puthex(block);
		return 0;
	}
	if (!mxc_nfb_command(0x0)) {
		return -1;
	}

	/* 
	 * The NAND Flash Addr is a 3 Cycle process.  Write to NAND Flash Addr
	 * Register - Start Addr in Page 
	 */
	if (!mxc_nfb_address(0)) {
		return -1;
	}

	if (g_page_size != NFC_PAGESIZE_512B)  {
		  if (!mxc_nfb_address(0)) {
                	return -1;
        	}
	}
	
	/* Write to NAND Flash Addr Register - 5 bit Page Addr and 
	 * 3 bit LSB Block Addr 
	 */
	if (!mxc_nfb_address(addr & 0x00ff)) {
		return -1;
	}

	/* Write to NAND Flash Addr Register - 7 bit MSB of Block Addr 
	 * 8th bit is don't care 
	 */
	if (!mxc_nfb_address((addr & 0xff00) >> 8)) {
		return -1;
	}
	/* 
	 * The current nandflash need one more address cycle
	 */
	if (!mxc_nfb_address((addr & 0xff0000) >> 16)) {
		return -1;
	}


	/*for 2k pagesize, need  read confirm*/
	if (g_page_size != NFC_PAGESIZE_512B) {
		 if (!mxc_nfb_command(0x30)) {
              		  return -1;
       		 }
	}
	
	/* Receive Data in RAM Buffer Addr Register - Set to 4th Internal 
	 * Buffer, where data will be loaded 
	 */

#ifdef NFC_V1_2
	/* Newer V1 controllers (i.e. MX25, MX35) only need one of these */
	if (!mxc_nfb_bufferaddr(0x0)) {
		return -1;
	}
#else
	/*for 2kpagesize nandflash, need 4 buffer to load data*/
	if (g_page_size != NFC_PAGESIZE_512B) {
		if (!mxc_nfb_bufferaddr(0x0))
			return -1;

		if (!mxc_nfb_bufferaddr(0x1))
  	              return -1;

		if (!mxc_nfb_bufferaddr(0x2))
    	            return -1;
	}/*End of g_page_size*/
	
	if (!mxc_nfb_bufferaddr(0x3)) {
		return -1;
	}
#endif

	return 1;
}

/*
 * This function copies data using ldmia and stmia instructions. It uses the
 * r3-r10 registers for this and copies 8 words at a time
 *
 */
asm("   	                		\n\
        .align  2				\n\
        .text					\n\
        .global asmcopy_8w			\n\
        .type asmcopy_8w, %function		\n\
asmcopy_8w:					\n\
	stmfd sp!, {r3-r10, lr}		 	\n\
.Loop:	ldmia r1!, {r3-r10}			\n\
	stmia r0!, {r3-r10}			\n\
	subs r2, r2, #1				\n\
	bne .Loop				\n\
	ldmfd sp!, {r3-r10, pc}			\n\
");

#ifdef CONFIG_BTCS
static void btcs_poll(void)
{
	struct btcs_cb_interface *btcs;
	struct btcs_event event;
	int (*btcs_callback)(struct btcs_event *);

	btcs = (struct btcs_cb_interface *)CONFIG_BTCS_START;

	if (btcs->magic == 0xdeadbeef) {
		event.cmd = BTCS_CAN_IRQ;
		event.arg = 0;
		btcs_callback = btcs->callback;
		btcs_callback(&event);
	}
}
#endif

/*!
 * This function copies Linux kernel Image starting from 1st block of the 
 * NAND Flash to RAM. The Linux kernl image written to NAND Flash has 4 bytes 
 * size and 4 bytes of crc value written at starting of the image. This 8 bytes
 * are initially skipped and then remaining data are copied to RAM. Using the 
 * size and crc value validity of the Linux kernel image is checked.
 * 
 * @param       pmem    memory address in RAM where Linux has to be copied
 * @param       start_block    starting block from where to copy kernel from 
 * 
 * @return      This function returns 0 if copying of kernel is not succeeded 
 * else it will return 1.
 * 
 */
int mxc_nfb_copyimage(U32 * pmem, U32 start_block, int poll)
{
	U16 page, block, bd_blk, nf_addr, addr, bi;
	volatile U32 *membuff;
	U32 size, i, tmp, ret,pagesize,pagenum;
#ifdef DOCHKSUM
	U8 *ch;
	U32 crc;
#endif

	mxc_nfb_preset();
	pagesize = 512;

	if (g_page_size == NFC_PAGESIZE_2K)
		pagesize = 2048;
	else if (g_page_size & NFC_PAGESIZE_4K) {
		pagesize = 4096;
		_reg_MXC_NFC_RSLTSPARE_AREA = 109;
		/* 8bit ecc */
		_reg_MXC_NFC_CONFIG1 &= 0xFFFE;
	}
	/* Read first page of linux kernel image in order to get size and maybe crc */
	bd_blk = 0;
	do {
		page = 0;
		block = start_block + bd_blk;

		ret = mxc_nfb_readpage(page, block);
		if (ret == -1) {
			mxc_outstring("\n-->Failed to read page... ");
			return 0;
		}
		if (ret == 0) {
			bd_blk++;
		}
	} while (ret != 1);

	membuff = MAIN_AREA0;
	size = *(membuff++);
	mxc_outstring("\n-->Size: ");
	mxc_puthex(size);

#ifdef DOCHKSUM
	crc = *(membuff++);
	mxc_outstring("\n-->Crc: ");
	mxc_puthex(crc);
	ch = (U8 *) pmem;	/* for checking crc */
#else
	membuff++;
#endif

	mxc_outstring("\nCopying pages....");

		
	/* Copy the first 6 words separately as it is not 8 word aligned for asmcopy_8w*/
        for (i = 0; i < 6; i++) {
 		*(pmem++) = *(membuff++);
 	}

	/* Copy the remaining (pagesize / 4)- 8 words starting from pmem*/
	asmcopy_8w(pmem, membuff, (pagesize / 32) - 1);

	/* Incrememt pmem by the number of relevant words */
	pmem += (pagesize / 4) - 8;
	
	/* Get total number of pages of image */
	if (g_page_size == NFC_PAGESIZE_2K)
        	nf_addr = (size/2048) + 1;
	else if (g_page_size & NFC_PAGESIZE_4K)
		nf_addr = (size/4096) + 1;
	else
		nf_addr = (size / 512) + 1;
	

	/* Read the remaining pages */
	if(g_page_size != NFC_PAGESIZE_512B) {
		pagenum = start_block << 7;
		addr = (start_block << 7) + 1;
	} else {
		pagenum = start_block << 5;
		addr = (start_block << 5) + 1;
	}

	  for (; addr <= (nf_addr + pagenum); addr++) {
		if(g_page_size != NFC_PAGESIZE_512B)
			page = addr & 0x7F;
		else
			page = addr & 0x1F;
		ret = 0;
		while (ret != 1) {
			if(g_page_size != NFC_PAGESIZE_512B)
				block = (addr >> 7) + bd_blk;
			else
				block = (addr >> 5) + bd_blk;
#ifdef CONFIG_BTCS
			if (poll)
				btcs_poll();
#endif
			ret = mxc_nfb_readpage(page, block);
			if (ret == -1) {
				mxc_outstring("\n-->Failed to read page... ");
				return 0;
			}
			if (ret == 0) {
				bd_blk++;
			}

		}
		/* Copy bytes from RAM buffer main area 0 to RAM */
		membuff = MAIN_AREA0;
		asmcopy_8w(pmem, membuff, pagesize/32);
		pmem += pagesize/4;
	}
#ifdef DOCHKSUM
	/* Check addition crc for image validity */
	tmp = 0;

	for (i = 0; i < size; i++) {
		tmp += *(ch++);
	}
	mxc_outstring("\n-->Calculated CRC: ");
	mxc_puthex(tmp);
	mxc_outstring("\n");
	if (tmp != crc) {
		return 0;
	}
	mxc_outstring("\n-->Found valid CRC\n");
#endif
	return 1;
}

int check_pattern()
{
	char *spbuff = (char *)SPARE_AREA0;
	int i;
	int pattern;
	pattern = *((int *)spbuff);
	for (i = 0; i < 4; i++) {
		if (bbt_pattern[i] != *(((char *)&pattern) + i))
		    return -1;
	}
	return 0;
}

/*! 
 * This function scan for badblock and maintains the Badblock table
 * Badblock table is maintained only for Kernel partition (i.e)4Mb.
 */
int mxcnb_scan_badblocks(int startblock)
{
	int ret, i, j, k, blocknum;
	U32 *bi = MAIN_AREA0;
	U32 reg, data;
	U32 *ptr;
	int start_block;
	char bbt_found = 0;
	ptr = (U32 *)(&badblock_list[0]);
	for (i=0; i < BLOCK_NUM/4; i++)
	    *ptr++ = 0;

	reg = _reg_MXC_CCM_RCSR;
	g_page_size = (reg & NFC_PAGESIZE_MASK ) >> NFC_PAGESIZE_OFFSET;
	start_block = BLOCK_NUM - 1;
	if (g_page_size & NFC_PAGESIZE_4K)
		start_block = BLOCK_NUM/2 - 1;

	/* read Bad Block Table, 1 page is enough for kernel and btcs */
	for (i = start_block; i > start_block - 4; i--) {
		ret = mxc_nfb_readpage(0, i);
		if (ret < 0)
			continue;
		if (check_pattern())
			continue;
		bbt_found = 1;
		for (j = 0; j < BLOCK_NUM/16; j++)
			if (*(bi + j) != 0xFFFFFFFF) {
				data = *(bi + j);
				for (k = 0; k < 16; k++) {
					badblock_list[j * 16 + k] =
					    (~(data >> (2 * k))) & 0x3 ? 1 : 0;
					if (badblock_list[j * 16 + k]) {
					    mxc_outstring("--- Bad block found at ");
					    mxc_puthex(j * 16 + k);
					    mxc_outstring("\n");
					}
				}
		}
		break;
	}
	if (bbt_found == 0)
		mxc_outstring("\n---> No BBT found\n");

	return g_page_size;
}
