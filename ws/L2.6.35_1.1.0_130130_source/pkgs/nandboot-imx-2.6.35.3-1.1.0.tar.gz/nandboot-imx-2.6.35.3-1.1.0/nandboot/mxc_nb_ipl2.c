/*
 * Copyright 2004-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file mxc_nb_ipl.c
 *
 * @brief Source file for NANDboot Initial Program Loader (IPL)
 *
 * NANDboot is for NAND flash booting.
 * NAND Flash can be configured as a booting device. This requires an
 * Initial Program Loader (IPL) to be written on the first block of the
 * NAND Flash which performs the initial booting operations. Since IPL has
 * the size limit, it loads Secondary Program Loader (SPL) which initializes
 * the system and loads the OS.
 * This file contains the IPL code which loads the SPL from NAND Flash to the
 * SPL_DEST_ADDR address in the RAM and starts executing from that location.
 *
 * @ingroup NANDboot
 */

typedef unsigned short u16;
typedef unsigned int u32;
typedef unsigned char u8;

#include "mxc_nfc2.h"

/*!
 * This is helper sleep function which loops for approximately given number
 * usecs.
 *
 * @param       count     number of usec to wait loop
 */
void udelay(int count)
{
/* Assuming 366 MHz, 366 instructions will take 1 usec, we will execute 2
 * inst in the loop (1 compare, 1 increment).
 */
#define LOOPS_PER_USEC (366 / 2)

	volatile int i;

	count *= LOOPS_PER_USEC;	/* 'count' number of usec */

	for (i = 0; i < count; i++) ;
}

/*!
 * This function polls the NANDFC to wait for an operation to complete
 * function. It sets the flags for the commands that requires different read
 * and write operations.
 *
 * @param       maxRetries     number of retry attempts (separated by 1 us)
 */
int wait_op_done(U32 maxRetries)
{
	while (maxRetries-- > 0) {
		if (_reg_MXC_NFC_IPC & NFC_INT)
		{	_reg_MXC_NFC_IPC &= ~NFC_INT;
			break;
		}
		udelay(1);
	}

	if (maxRetries <= 0) {
		return -1;
	}
	return 0;
}

int mxc_nfb_command(U16 cmd)
{
	_reg_MXC_NFC_NAND_ADD_CMD = cmd;
	/* Set FCMD to 1 */
	_reg_MXC_NFC_LAUNCH_NFC = NFC_FCMD;

	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_NB_WAIT_US) == 0) ? 1 : 0;
}
/*!
 * Reading or writing to any location in NAND Flash requires to pass an
 * address of that location in NFC. This function writes the NAND Flash Address
 * to the NFC's Address Register. Sets the Configuration Register for the
 * Address Input Operation
 *
 * @param       addr    addr from where to read the page
 *
 * @return      This function returns 0 if address operation is not complete
 * else returns 1.
 */
int mxc_nfb_address(U16 addr)
{
	_reg_MXC_NFC_NAND_ADD_CMD = (U32)addr  << 16 ;
	/* Set FADD to 1 */
	_reg_MXC_NFC_LAUNCH_NFC = NFC_FADD;

	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_NB_WAIT_US) == 0) ? 1 : 0;
}

/*!
 * This function configures the NFC to copy the NAND Flash data in the main
 * area number passed as parameter during read operation or write the data
 * from main area to the NAND Flash.
 *
 * @param       addr    value for the internal main area buffer.
 *
 * @return      This function returns 0 if the operation is not complete
 * else returns 1.
 */
int mxc_nfb_bufferaddr(U16 addr)
{
        /* NFC buffer 0 is used for page read/write */
         _reg_MXC_NFC_CONFIGURATION1 = ( _reg_MXC_NFC_CONFIGURATION1 | NFC_SET_RBA_BITS) & NFC_SET_RBA0;

	/* Set FDO to 1 */
	_reg_MXC_NFC_LAUNCH_NFC = NFC_FDO_PAGE;
	/* Confirm Cmd Complete */
	return (wait_op_done(MXC_NB_WAIT_US) == 0) ? 1 : 0;
}

/*!
 * The NFC has to be preset before performing any operation
 */
int mxc_nfb_preset(void)
{
	/* NFC Reset*/
	_reg_MXC_NFC_CONFIGURATION1 = (1 << 2);
	_reg_MXC_NFC_CONFIGURATION2 = (1 << 6);

	/*setting to 64 pages per block */
        _reg_MXC_NFC_CONFIGURATION2 =  ( _reg_MXC_NFC_CONFIGURATION2  | NFC_SET_PPB_BITS) & NFC_SET_PPB64;

	/* Mask Interrupt */
	_reg_MXC_NFC_CONFIGURATION2 |= NFC_INT_MSK;

	/* Reset NAND */
	mxc_nfb_command(NAND_CMD_RESET);

        /* Unlock the internal RAM Buffer */
        _reg_MXC_NFC_WR_PROTECT =  (_reg_MXC_NFC_WR_PROTECT | NFC_SET_BLS_BITS) & NFC_BLS_UNLOCK;

        /* Blocks to be unlocked */
        /* Start Address = 0X0, End Address   = 0xFFFF */
        _reg_MXC_NFC_UNLOCK_BLK_ADD0 =  ( 0x0 | ( 0xFFFF << NFC_UEBA0) );

        /* Unlock Block Command for given address range */
        _reg_MXC_NFC_WR_PROTECT =  (_reg_MXC_NFC_WR_PROTECT | NFC_SET_WPC_BITS) & NFC_WPC_UNLOCK;
}

/*
 * This function does the trick of swapping the 464th byte in the last RAM
 * buffer in the main area with the 0th byte in the spare area. This seems
 * to be the optimal way of addressing the NFC imcompatibility problem with
 * the NAND flash out of factory in terms of BI field.
 * Note: this function only operates on the NFC's internal RAM buffers and
 *       for 2K page only.
 */
static void mxc_swap_2k_bi_main_sp(void)
{
        u16 tmp1, tmp2, new_tmp1;

        tmp1 = BAD_BLK_MARKER_464;
        tmp2 = BAD_BLK_MARKER_SP_0;
        new_tmp1 = (tmp1 & 0xFF00) | (tmp2 >> 8);
        tmp2 = (tmp1 << 8) | (tmp2 & 0xFF);
        BAD_BLK_MARKER_464 = new_tmp1;
        BAD_BLK_MARKER_SP_0 = tmp2;
}

/*
 * This function copies data using ldmia and stmia instructions. It uses the
 * r3-r10 registers for this and copies 8 words at a time
 */
asm("   	                		\n\
        .align  2				\n\
        .text					\n\
        .global asmcopy_8w			\n\
        .type asmcopy_8w, %function		\n\
asmcopy_8w:					\n\
	stmfd sp!, {r3-r10, lr}		 	\n\
.Loop:	ldmia r1!, {r3-r10}			\n\
	stmia r0!, {r3-r10}			\n\
	subs r2, r2, #1				\n\
	bne .Loop				\n\
	ldmfd sp!, {r3-r10, pc}			\n\
");

typedef u32(*FPTR) (void);
/*!
 * Main routine of NANDboot Initial Program Loader. It copies all the pages
 * after first 2k bytes offset in the 0th block which is guaranteed to be good
 * block
 */
int main(void)
{
	unsigned short i, page;
	volatile unsigned int *pMem = SPL_DEST_ADDR;
	volatile unsigned int *membuff;
	FPTR fptr;		/* To jump to SPL */
	int startpage, endpage, reg;

	startpage = 0x1;
	endpage   = 0x3f;

	mxc_nfb_preset();
	/*
	 * Copy 1st block of NAND into memory starting from 4th page, where SPL
	 * is expected to be stored
	 */
	for (page = startpage; page <= endpage; page++){

		/* Write to NAND Flash Cmd Register - Read Area 0x0 */
		if (!mxc_nfb_command(NAND_CMD_READ0)) {
			return -1;
		}

		/*
		 * The NAND Flash Addr is a 3 Cycle process. Write to NAND
		 * Flash Addr Register - Start Addr in Page 0x0
		 */
		if (!mxc_nfb_address(0x0)) {
			return -1;
		}

		/*if the pagesize is 2k, 5 cycle process*/
		if (!mxc_nfb_address(0x0)) {
                	return -1;
              	}

		/* Write to NAND Flash Addr Register - Page Addr in Block 0x0 */
		if (!mxc_nfb_address(page)) {
			return -1;
		}
		/* Write to NAND Flash Addr Register - Block Addr 0x0 */
		if (!mxc_nfb_address(0x0)) {
			return -1;
		}
		if (!mxc_nfb_command(NAND_CMD_READSTART)) {
			return -1;
		}

		if (!mxc_nfb_bufferaddr(0x0)) {
			return -1;
		}
		/* Read Data from RAM Buffer */
		membuff = MAIN_AREA0;
		mxc_swap_2k_bi_main_sp();

	     	asmcopy_8w(pMem, membuff, NB_2k_PG_SZ/32);
		pMem += NB_2k_PG_SZ/4;
	}

	/* Jump to SPL start address */
	fptr = (FPTR) SPL_DEST_ADDR;
	fptr();
	/* Point of no return */
}
