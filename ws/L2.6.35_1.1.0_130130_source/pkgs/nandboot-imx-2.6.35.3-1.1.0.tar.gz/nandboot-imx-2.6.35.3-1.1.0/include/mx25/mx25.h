/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef MX25_H_
#define MX25_H_

#include "hal_cache.h"

/* definitions */
#ifdef __ASSEMBLER__

#define REG8_VAL(a)      (a)
#define REG16_VAL(a)     (a)
#define REG32_VAL(a)     (a)

#define REG8_PTR(a)      (a)
#define REG16_PTR(a)     (a)
#define REG32_PTR(a)     (a)

#else				/* __ASSEMBLER__ */

#define REG8_VAL(a)      ((unsigned char)(a))
#define REG16_VAL(a)     ((unsigned short)(a))
#define REG32_VAL(a)     ((unsigned int)(a))

#define REG8_PTR(a)      ((volatile unsigned char *)(a))
#define REG16_PTR(a)     ((volatile unsigned short *)(a))
#define REG32_PTR(a)     ((volatile unsigned long *)(a))

#define REG32_SET(addr, val)    (*(volatile unsigned long*) (addr) = (val))
#define REG16_SET(addr, val)    (*(volatile unsigned short*) (addr) = (val))
#define readb(a)             (*(volatile unsigned char *)(a))
#define readw(a)             (*(volatile unsigned short *)(a))
#define readl(a)             (*(volatile unsigned int *)(a))
#define writeb(v,a)          (*(volatile unsigned char *)(a) = (v))
#define writew(v,a)          (*(volatile unsigned short *)(a) = (v))
#define writel(v,a)          (*(volatile unsigned int *)(a) = (v))

#endif				/* __ASSEMBLER__ */

/* handy sizes */
#define SZ_16		    0x00000010
#define SZ_256		    0x00000100
#define SZ_512		    0x00000200

#define SZ_1K		    0x00000400
#define SZ_2K		    0x00000800
#define SZ_4K		    0x00001000
#define SZ_8K		    0x00002000
#define SZ_16K		    0x00004000
#define SZ_32K		    0x00008000
#define SZ_64K		    0x00010000
#define SZ_128K		    0x00020000
#define SZ_256K		    0x00040000
#define SZ_512K		    0x00080000

#define SZ_1M		    0x00100000
#define SZ_2M		    0x00200000
#define SZ_4M		    0x00400000
#define SZ_8M		    0x00800000
#define SZ_16M		    0x01000000
#define SZ_32M		    0x02000000
#define SZ_48M		    0x03000000
#define SZ_64M		    0x04000000
#define SZ_128M		    0x08000000
#define SZ_256M		    0x10000000
#define SZ_512M		    0x20000000

#define SZ_1G		    0x40000000
#define SZ_2G		    0x80000000

/*
 * MX25 memory map:
 *
 * Virt     Phys        Size    What
 * ---------------------------------------------------------------------------
 * FC000000 43F00000    1M      AIPS 1
 * 50000000 50000000    1M      SPBA
 * FC200000 53F00000    1M      AIPS 2
 * 60000000 60000000    1M      ROMPATCH (128M)
 * 68000000 68000000    1M      ASIC (128M)
 * 78000000 78000000    128K    FBC RAM (IRAM)
 * C0000000 80000000    256M    SDRAM0
 * NotUsed  90000000    256M    SDRAM1
 *          A0000000    128M    CS0 Flash
 *          A8000000    128M    CS1 Flash
 *          B0000000    32M     CS2 SRAM
 *          B2000000    32M     CS3
 *          B4000000    32M     CS4
 *          B6000000    32M     CS5
 * B8000000 B8000000    64K     SDRAM, WEIM, M3IF, EMI controllers
 * BB000000 BB000000    8K      NFC
 */

/*
 * IRAM
 */
#define IRAM_BASE_ADDR       0x78000000 /* internal ram */
#define IRAM_BASE_ADDR_VIRT  0x78000000
#define IRAM_SIZE            SZ_128K

/*
 * AIPS 1
 */
#define AIPS1_BASE_ADDR       0x43F00000
#define AIPS1_BASE_ADDR_VIRT  0xFC000000
#define AIPS1_SIZE            SZ_1M

#define MAX_BASE_ADDR       (AIPS1_BASE_ADDR + 0x00004000)
#define CLKCTL_BASE_ADDR    (AIPS1_BASE_ADDR + 0x00008000)
#define ETB_SLOT4_BASE_ADDR (AIPS1_BASE_ADDR + 0x0000C000)
#define ETB_SLOT5_BASE_ADDR (AIPS1_BASE_ADDR + 0x00010000)
#define AAPE_BASE_ADDR      (AIPS1_BASE_ADDR + 0x00014000)
#define I2C_BASE_ADDR       (AIPS1_BASE_ADDR + 0x00080000)
#define I2C3_BASE_ADDR      (AIPS1_BASE_ADDR + 0x00084000)
#define CAN1_BASE_ADDR      (AIPS1_BASE_ADDR + 0x00088000)
#define CAN3_BASE_ADDR      (AIPS1_BASE_ADDR + 0x0008C000)
#define UART1_BASE_ADDR     (AIPS1_BASE_ADDR + 0x00090000)
#define UART2_BASE_ADDR     (AIPS1_BASE_ADDR + 0x00094000)
#define I2C2_BASE_ADDR      (AIPS1_BASE_ADDR + 0x00098000)
#define OWIRE_BASE_ADDR     (AIPS1_BASE_ADDR + 0x0009C000)
#define ATA_BASE_ADDR       (AIPS1_BASE_ADDR + 0x000A0000)
#define CSPI1_BASE_ADDR     (AIPS1_BASE_ADDR + 0x000A4000)
#define KPP_BASE_ADDR       (AIPS1_BASE_ADDR + 0x000A8000)
#define IOMUXC_BASE_ADDR    (AIPS1_BASE_ADDR + 0x000AC000)
#define AUDMUX_BASE_ADDR    (AIPS1_BASE_ADDR + 0x000B0000)
#define ECT_A_BASE_ADDR     (AIPS1_BASE_ADDR + 0x000B8000)
#define ECT_B_BASE_ADDR     (AIPS1_BASE_ADDR + 0x000BC000)

/*
 * SPBA global module enabled #0
 */
#define SPBA0_BASE_ADDR       0x50000000
#define SPBA0_BASE_ADDR_VIRT  0x50000000
#define SPBA0_SIZE            SZ_1M

#define CSPI3_BASE_ADDR         (SPBA0_BASE_ADDR + 0x00004000)
#define UART4_BASE_ADDR         (SPBA0_BASE_ADDR + 0x00008000)
#define UART3_BASE_ADDR         (SPBA0_BASE_ADDR + 0x0000C000)
#define CSPI2_BASE_ADDR         (SPBA0_BASE_ADDR + 0x00010000)
#define SSI2_BASE_ADDR          (SPBA0_BASE_ADDR + 0x00014000)
#define ESAI_BASE_ADDR          (SPBA0_BASE_ADDR + 0x00018000)
#define ATA_DMA_BASE_ADDR       (SPBA0_BASE_ADDR + 0x00020000)
#define SIM1_BASE_ADDR          (SPBA0_BASE_ADDR + 0x00024000)
#define SIM2_BASE_ADDR          (SPBA0_BASE_ADDR + 0x00028000)
#define UART5_BASE_ADDR         (SPBA0_BASE_ADDR + 0x0002C000)
#define TSC_BASE_ADDR           (SPBA0_BASE_ADDR + 0x00030000)
#define SSI1_BASE_ADDR          (SPBA0_BASE_ADDR + 0x00034000)
#define FEC_BASE_ADDR           (SPBA0_BASE_ADDR + 0x00038000)
#define SPBA_CTRL_BASE_ADDR     (SPBA0_BASE_ADDR + 0x0003C000)

/*
 * AIPS 2
 */
#define AIPS2_BASE_ADDR       0x53F00000
#define AIPS2_BASE_ADDR_VIRT  0xFC200000
#define AIPS2_SIZE            SZ_1M

#define CCM_BASE_ADDR       (AIPS2_BASE_ADDR + 0x00080000)
#define GPT4_BASE_ADDR      (AIPS2_BASE_ADDR + 0x00084000)
#define GPT3_BASE_ADDR      (AIPS2_BASE_ADDR + 0x00088000)
#define GPT2_BASE_ADDR      (AIPS2_BASE_ADDR + 0x0008C000)
#define GPT1_BASE_ADDR      (AIPS2_BASE_ADDR + 0x00090000)
#define EPIT1_BASE_ADDR     (AIPS2_BASE_ADDR + 0x00094000)
#define EPIT2_BASE_ADDR     (AIPS2_BASE_ADDR + 0x00098000)
#define GPIO4_BASE_ADDR     (AIPS2_BASE_ADDR + 0x0009C000)
#define PWM2_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000A0000)
#define GPIO3_BASE_ADDR     (AIPS2_BASE_ADDR + 0x000AD000)
#define PWM3_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000A8000)
#define SCC_BASE_ADDR       (AIPS2_BASE_ADDR + 0x000AC000)
#define RNGB_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000B0000)
#define MMC_SDHC1_BASE_ADDR (AIPS2_BASE_ADDR + 0x000B4000)
#define MMC_SDHC2_BASE_ADDR (AIPS2_BASE_ADDR + 0x000B8000)
#define LCDC_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000BC000)
#define SLCDC_BASE_ADDR     (AIPS2_BASE_ADDR + 0x000C0000)
#define PWM4_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000C8000)
#define GPIO1_BASE_ADDR     (AIPS2_BASE_ADDR + 0x000CC000)
#define GPIO2_BASE_ADDR     (AIPS2_BASE_ADDR + 0x000D0000)
#define SDMA_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000D4000)
#define WDOG_BASE_ADDR	    (AIPS2_BASE_ADDR + 0x000DC000)
#define PWM1_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000E0000)
#define RTIC_BASE_ADDR      (AIPS2_BASE_ADDR + 0x000EC000)
#define IIM_BASE_ADDR       (AIPS2_BASE_ADDR + 0x000F0000)
#define USBOTG_BASE_ADDR    (AIPS2_BASE_ADDR + 0x000F4000)
#define OTG_BASE_ADDR       USBOTG_BASE_ADDR
#define CSI_BASE_ADDR       (AIPS2_BASE_ADDR + 0x000F8000)
#define DRYICE_BASE_ADDR    (AIPS2_BASE_ADDR + 0x000FC000)
#define SRTC_BASE_ADDR      (DRYICE_BASE_ADDR)

/*
 * ROMP and ASIC
 */
#define ROMP_BASE_ADDR       0x60000000
#define ROMP_BASE_ADDR_VIRT  0x60000000
#define ROMP_SIZE            SZ_1M

#define ASIC_BASE_ADDR       0x68000000
#define ASIC_BASE_ADDR_VIRT  0x68000000
#define ASIC_SIZE            SZ_1M
#define AVIC_BASE_ADDR       ASIC_BASE_ADDR
#define AVIC_BASE_ADDR_VIRT  ASIC_BASE_ADDR_VIRT
#define AVIC_SIZE            ASIC_SIZE

/*
 * SDRAM, WEIM, M3IF, EMI controllers
 */
#define X_MEMC_BASE_ADDR       0xB8000000
#define X_MEMC_BASE_ADDR_VIRT  0xB8000000
#define X_MEMC_SIZE            SZ_64K

#define ESDCTL_BASE_ADDR        (X_MEMC_BASE_ADDR + 0x1000)
#define WEIM_BASE_ADDR          (X_MEMC_BASE_ADDR + 0x2000)
#define M3IF_BASE_ADDR          (X_MEMC_BASE_ADDR + 0x3000)
#define EMI_CTL_BASE_ADDR       (X_MEMC_BASE_ADDR + 0x4000)

/*
 * NFC controller
 */
#define NFC_BASE_ADDR       0xBB000000
#define NFC_BASE_ADDR_VIRT  0xBB000000
#define NFC_SIZE            SZ_8K

/*
 * Memory regions and CS
 */
#define CSD0_BASE_ADDR          0x80000000
#define CSD0_BASE_ADDR_VIRT     0xC0000000
#define CSD0_SIZE		SZ_256M
#define CSD1_BASE_ADDR          0x90000000
#define CSD1_BASE_ADDR_VIRT	0xD0000000
#define CSD1_SIZE		SZ_256M

#define SDRAM_BASE_ADDR         CSD0_BASE_ADDR

#define CS0_BASE_ADDR           0xA0000000
#define CS1_BASE_ADDR           0xA8000000
#define CS2_BASE_ADDR           0xB0000000
#define CS3_BASE_ADDR           0xB2000000
#define CS4_BASE_ADDR           0xB4000000
#define CS4_SIZE                SZ_32M
#define CS5_BASE_ADDR           0xB6000000
#define CS5_SIZE                SZ_32M

/*!
 * This macro defines the physical to virtual address mapping for all the
 * peripheral modules. It is used by passing in the physical address as x
 * and returning the virtual address. If the physical address is not mapped,
 * it returns 0xDEADBEEF
 */
#define IO_ADDRESS(x)   \
	(void *) \
	(((x >= AIPS1_BASE_ADDR) && (x < (AIPS1_BASE_ADDR + AIPS1_SIZE))) ? AIPS1_IO_ADDRESS(x):\
	((x >= SPBA0_BASE_ADDR) && (x < (SPBA0_BASE_ADDR + SPBA0_SIZE))) ? SPBA0_IO_ADDRESS(x):\
	((x >= AIPS2_BASE_ADDR) && (x < (AIPS2_BASE_ADDR + AIPS2_SIZE))) ? AIPS2_IO_ADDRESS(x):\
	((x >= ROMP_BASE_ADDR) && (x < (ROMP_BASE_ADDR + ROMP_SIZE))) ? ROMP_IO_ADDRESS(x):\
	((x >= ASIC_BASE_ADDR) && (x < (ASIC_BASE_ADDR + AVIC_SIZE))) ? ASIC_IO_ADDRESS(x):\
	((x >= IRAM_BASE_ADDR) && (x < (IRAM_BASE_ADDR + IRAM_SIZE))) ? IRAM_IO_ADDRESS(x):\
	((x >= X_MEMC_BASE_ADDR) && (x < (X_MEMC_BASE_ADDR + X_MEMC_SIZE))) ? X_MEMC_IO_ADDRESS(x):\
	((x >= NFC_BASE_ADDR) && (x < (NFC_BASE_ADDR + NFC_SIZE))) ? NFC_IO_ADDRESS(x):\
	0xDEADBEEF)

/*
 * define the address mapping macros: in physical address order
 */

#define AIPS1_IO_ADDRESS(x)  \
	(((x) - AIPS1_BASE_ADDR) + AIPS1_BASE_ADDR_VIRT)

#define SPBA0_IO_ADDRESS(x)  \
	(((x) - SPBA0_BASE_ADDR) + SPBA0_BASE_ADDR_VIRT)

#define AIPS2_IO_ADDRESS(x)  \
	(((x) - AIPS2_BASE_ADDR) + AIPS2_BASE_ADDR_VIRT)

#define ROMP_IO_ADDRESS(x)  \
	(((x) - ROMP_BASE_ADDR) + ROMP_BASE_ADDR_VIRT)

#define ASIC_IO_ADDRESS(x)  \
	(((x) - ASIC_BASE_ADDR) + ASIC_BASE_ADDR_VIRT)

#define IRAM_IO_ADDRESS(x)  \
	(((x) - IRAM_BASE_ADDR) + IRAM_BASE_ADDR_VIRT)

#define X_MEMC_IO_ADDRESS(x)  \
	(((x) - X_MEMC_BASE_ADDR) + X_MEMC_BASE_ADDR_VIRT)

#define NFC_IO_ADDRESS(x)  \
	(((x) - NFC_BASE_ADDR) + NFC_BASE_ADDR_VIRT)


/* CCM Register offsets */
#define CCM_MPCTL                    0x00
#define CCM_UPCTL                    0x04
#define CCM_CCTL                     0x08
#define CCM_CGR0                     0x0C
#define CCM_CGR1                     0x10
#define CCM_CGR2                     0x14
#define CCM_PCDR0                    0x18
#define CCM_PCDR1                    0x1C
#define CCM_PCDR2                    0x20
#define CCM_PCDR3                    0x24
#define CCM_RCSR                     0x28
#define CCM_CRDR                     0x2C
#define CCM_DCVR0                    0x30
#define CCM_DCVR1                    0x34
#define CCM_DCVR2                    0x38
#define CCM_DCVR3                    0x3C
#define CCM_LTR0                     0x40
#define CCM_LTR1                     0x44
#define CCM_LTR2                     0x48
#define CCM_LTR3                     0x4C
#define CCM_LTBR0                    0x50
#define CCM_LTBR1                    0x54
#define CCM_PCMR0                    0x58
#define CCM_PCMR1                    0x5C
#define CCM_PCMR2                    0x60
#define CCM_MCR                      0x64
#define CCM_LPIMR0                   0x68
#define CCM_LPIMR1                   0x6C

/* ESDCTL register offsets */
#define ESDCTL0			    0x00
#define ESDCFG0			    0x04
#define ESDCTL1			    0x08
#define ESDCFG1			    0x0C
#define ESDMISC			    0x10

/* I2C register offsets */
#define I2C_IADR		    0x0
#define I2C_IFDR                    0x4
#define I2C_I2CR                    0x8
#define I2C_I2SR                    0xC
#define I2C_I2DR                    0x10
#define I2C_I2CR_IEN                (1 << 7)

/* ASIC register offsets */
#define ASIC_NIMASK		    0x04
#define ASIC_INTTYPEH		    0x18
#define ASIC_INTTYPEL		    0x1C

/* IIM register offsets */
#define IIM_SREV		    24

/* WDOG register offsets */
#define WDOG_WCR		    0x0
#define WDOG_WSR		    0x2
#define WDOG_WRSR		    0x4
#define WDOG_WICR		    0x6
#define WDOG_WMCR		    0x8


/* IO_MUX register offsets */
#define IOMUXC_MUX_CTL_I2C1_CLK	    0x150
#define IOMUXC_MUX_CTL_I2C1_DAT	    0x154
#define IOMUXC_PAD_CTL_I2C1_CLK	    0x348
#define IOMUXC_PAD_CTL_I2C1_DAT	    0x34C

/* CCM_CCTL bit offsets */
#define CCM_CCTL_ARM_OFFSET		30
#define CCM_CCTL_ARM_MASK		(0x3 << 30)
#define CCM_CCTL_AHB_OFFSET		28
#define CCM_CCTL_AHB_MASK		(0x3 << 28)
#define CCM_CCTL_MPLL_RST		(1 << 27)
#define CCM_CCTL_UPLL_RST		(1 << 26)
#define CCM_CCTL_LP_CTL_OFFSET		24
#define CCM_CCTL_LP_CTL_MASK		(0x3 << 24)
#define CCM_CCTL_LP_MODE_RUN		(0x0 << 24)
#define CCM_CCTL_LP_MODE_WAIT		(0x1 << 24)
#define CCM_CCTL_LP_MODE_DOZE		(0x2 << 24)
#define CCM_CCTL_LP_MODE_STOP		(0x3 << 24)
#define CCM_CCTL_UPLL_DISABLE		(1 << 23)
#define CCM_CCTL_MPLL_BYPASS		(1 << 22)
#define CCM_CCTL_USB_DIV_OFFSET		16
#define CCM_CCTL_USB_DIV_MASK		(0x3 << 16)
#define CCM_CCTL_CG_CTRL		(1 << 15)
#define CCM_CCTL_ARM_SRC		(1 << 14)
#define CCM_CCTL_ARM_SRC_OFFSET		14

/* CLKCTL_RCSR bit offsets */
#define CCM_RCSR_NF16B_OFFSET		14
#define CCM_RCSR_NFC_4K_OFFSET		9
#define CCM_RCSR_NFC_FMS_OFFSET		8


/* CCM's MPLL & PPLL defines */
#define CCM_PLL_PCTL_PARAM(pd, mfd, mfi, mfn) \
	(((pd - 1) << 26) + (((mfd) - 1) << 16) + ((mfi) << 10) + ((mfn) << 0))

#define CCM_MPCTL_PARAM_399		CCM_PLL_PCTL_PARAM(1, 12, 11, 1)

#define CCM_CCTL_PARAM (                 \
	(0 << CCM_CCTL_ARM_OFFSET)  |	\
	((3 - 1) <<  CCM_CCTL_AHB_OFFSET) |	\
	((4 - 1) <<  CCM_CCTL_USB_DIV_OFFSET) |	\
	CCM_CCTL_ARM_SRC)


#if !defined(__ASSEMBLER__)	/* ADDED FOR COMPILATION */

#define MXC_CCM_BASE_ADDR	IO_ADDRESS(CCM_BASE_ADDR)
#define MXC_ASIC_BASE_ADDR	IO_ADDRESS(ASIC_BASE_ADDR)
#define MXC_IIM_BASE_ADDR	IO_ADDRESS(IIM_BASE_ADDR)
#define MXC_IOMUXC_BASE_ADDR	IO_ADDRESS(IOMUXC_BASE_ADDR)
#define MXC_WDOG_BASE_ADDR	IO_ADDRESS(WDOG_BASE_ADDR)
#define MXC_UART1_BASE_ADDR	IO_ADDRESS(UART1_BASE_ADDR)
#define MXC_UART2_BASE_ADDR	IO_ADDRESS(UART2_BASE_ADDR)
#define MXC_NFC_BASE_ADDR       IO_ADDRESS(NFC_BASE_ADDR)
#define MXC_I2C_BASE_ADDR	IO_ADDRESS(I2C_BASE_ADDR)


#define _reg_MXC_CCM_CCTL	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR + CCM_CCTL)))
#define _reg_MXC_CCM_CGRC0	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR + CCM_CGR0)))
#define _reg_MXC_CCM_CGRC1	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR + CCM_CGR1)))
#define _reg_MXC_CCM_CGRC2	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR + CCM_CGR2)))
#define _reg_MXC_CCM_PCDR2	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR + CCM_PCDR2)))
#define _reg_MXC_CCM_PCDR3	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR + CCM_PCDR3)))
#define _reg_MXC_CCM_RCSR	(*((volatile unsigned long *)(MXC_CCM_BASE_ADDR + CCM_RCSR)))

#define _reg_MXC_ASIC_NIMASK	(*((volatile unsigned long *)(MXC_ASIC_BASE_ADDR + ASIC_NIMASK)))
#define _reg_MXC_ASIC_INTTYPEH	(*((volatile unsigned long *)(MXC_ASIC_BASE_ADDR + ASIC_INTTYPEH)))
#define _reg_MXC_ASIC_INTTYPEL	(*((volatile unsigned long *)(MXC_ASIC_BASE_ADDR + ASIC_INTTYPEH)))

#define _reg_MXC_IIM_SREV	(*((volatile unsigned long *)(MXC_IIM_BASE_ADDR + IIM_SREV)))

#define _reg_MXC_IOMUXC_MUX_CTL_I2C1_CLK    (*((volatile unsigned long *)(MXC_IOMUXC_BASE_ADDR + IOMUXC_MUX_CTL_I2C1_CLK)))
#define _reg_MXC_IOMUXC_MUX_CTL_I2C1_DAT    (*((volatile unsigned long *)(MXC_IOMUXC_BASE_ADDR + IOMUXC_MUX_CTL_I2C1_DAT)))
#define _reg_MXC_IOMUXC_PAD_CTL_I2C1_CLK    (*((volatile unsigned long *)(MXC_IOMUXC_BASE_ADDR + IOMUXC_PAD_CTL_I2C1_CLK)))
#define _reg_MXC_IOMUXC_PAD_CTL_I2C1_DAT    (*((volatile unsigned long *)(MXC_IOMUXC_BASE_ADDR + IOMUXC_PAD_CTL_I2C1_DAT)))

#define _reg_MXC_WDOG_WCR       (*((volatile unsigned short *)(MXC_WDOG_BASE_ADDR + WDOG_WCR)))
#define _reg_MXC_WDOG_WSR	(*((volatile unsigned short *)(MXC_WDOG_BASE_ADDR + WDOG_WSR)))
#define _reg_MXC_WDOG_WRSR	(*((volatile unsigned short *)(MXC_WDOG_BASE_ADDR + WDOG_WRSR)))

#define NFC_PAGESIZE_OFFSET	26
#define NFC_PAGESIZE_MASK	0x0C000000
#define NFC_FMS_OFFSET		8
#define NFC_FMS_MASK		0x00000300
#define NFC_PAGESIZE_512B	0x0
#define NFC_PAGESIZE_2K		0x1
#define NFC_PAGESIZE_4K		0x2

#endif				/* !defined(__ASSEMBLER__) */

#endif				/* MX25_H_ */
