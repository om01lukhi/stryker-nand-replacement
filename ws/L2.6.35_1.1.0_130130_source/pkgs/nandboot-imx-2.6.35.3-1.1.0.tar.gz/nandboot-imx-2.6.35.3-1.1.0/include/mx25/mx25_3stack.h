/*
 * Copyright 2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 *         File : mx25_3stack.h
 *
 *        Board specific code for MX25 platform.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef MX25_3STACK_H_
#define MX25_3STACK_H_

#include "mx25.h"

/*!
 * This defines processor id for the respective processor.
 * This id is passed to the Linux kernel before booting.
 */
#define PROC_ID         	 1771

/* RAM address and size */
#define RAM_BANK0_BASE          CSD0_BASE_ADDR
#define SDRAM_BASE_ADDR         CSD0_BASE_ADDR
#define SDRAM_BASE_ADDR_VIRT	CSD0_BASE_ADDR_VIRT
#define SDRAM_SIZE              0x04000000

/* Command line option address for Linux kernel */
#define CMDLINE_ADDR		(U8 *)(SDRAM_BASE_ADDR + 0x100)

/* NAND flash bus width */
#define NAND_BUSWIDTH		NAND_WIDTH_8

/* Link address for IPL & SPL */
#define IPL1_TEXT_START		0xBB000000  /* ipl1 Text segment start(link) address */
#define IPL2_TEXT_START		0x80007500  /* ipl2 Text segment start(link) address */
#define SPL_TEXT_START		0x81000000  /* spl Text segment start(link) address */

/* Load addree for SPL and kernel */
#define SPL_DEST_ADDR		0x81000000  /* RAM address where SPL code will be copied to*/
#define KERNEL_DEST_ADDR	(U32 *)(SDRAM_BASE_ADDR + 0x8000)

#define TIMEOUT                 0x4000

/* UART register value */
#define UART_FIFO_CTRL		0xA81
#define MXC_UART_UBMR  		0xA259

/* Stack start address for C environment */
#define STACK_ADDR		(SDRAM_BASE_ADDR + 0x8000 - 0x1000)

/* The PMIC */
#define PMIC_MC34704_I2C_ADDR	0x54
#define PMIC_I2C_ADDR		PMIC_MC34704_I2C_ADDR

#endif /*End of MX25_3STACK_H_*/
