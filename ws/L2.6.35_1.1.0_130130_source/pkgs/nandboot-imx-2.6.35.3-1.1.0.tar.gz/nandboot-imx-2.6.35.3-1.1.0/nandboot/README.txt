
This file contains the information to use NANDBoot code 

NANDBoot consists of two parts: 
        - Initial Program Loader (IPL), 
        - Secondary Program Loader (SPL)
        - Tools to create NAND flash image


Directory strucure:
------------------

bootloader
|-- nandboot
      |-- Makefile            -- Makefile for the complete nandboot
      |-- README.txt          -- This file
      |-- full_output         -- Directory contains Doxygen generated documentation
|-- bin      -- Contains the generated tools and binary files
     |-- Image_crc          - Linux kernel image with CRC and size info
     |-- crcgen             - Tool to generate CRC and write to the image
     |-- ipl1.bin           - IPL binary part 1 (Runs from NAND RAM buffer)
     |-- ipl2.bin           - IPL binary part 2 (Runs from SDRAM)
     |-- nandfsbuild        - Tool to generate the NAND flash image for Virtio
     |-- mkiplspl.sh        - Tool to generate iplspl.bin
     `-- spl.bin            - SPL binary
|-- crcgen   -- Code for addition CRC checksum
      `-- mxc_nb_crcgen.c
|   image
      `-- Image              - Linux Kernel Image
|-- nandboot
    		IPL code
    	|-- ipl_link.lds.S
	|-- ipl_startup.S
	|-- ipl_startup2.c
	|-- mxc_nb_ipl.c

    		SPL Code
|-- platform
	|-- boot.c           
	|-- mxc.h
	|-- mxc_init.c
|-- drivers
	|-- nfc
	     |-- mxc_nb_nfc.c
	     |-- mxc_nb_nfc.h
        |-- uart
	     |-- mxc_nb_uart.c
	     |-- mxc_nb_uart.h
|-- nandboot
	|-- spl_link.lds.S
	|-- mxc_spl_startup.S

Building and Installing the nandboot:
------------------------------------
1) Compile the Linux 2.6 Kernel for MXC platform. This generates the Linux
   Kernel image. Copy this image file into nandboot/image/Image.

2) Configure the nandboot parameters (See Configuration section below).

3) Build Instructions:
   -------------------
   1. To compile nand bootloader for different platforms, modify the PLATFORM variable in the
      Makefile appropriately.

   2. Export CROSS_COMPILE variable to point to the ARM gcc compiler toolkit.
      e.g. $ export CROSS_COMPILE=/opt/montavista/foundation/devkit/arm/v6_vfp_le/bin/arm_v6_vfp_le-

   3. Export KBUILD_OUTPUT variable to point to the linux directory in the linux tree
      e.g. $ export KBUILD_OUTPUT=/home/LINUX2.6/linux

   4. Use 'make clean' command to clean any previous object files.

   5. Run make command in the nandboot directory. This generates the ipl (ipl1 and ipl2), spl, iplspl.bin and tools. 
      This also creates the Image_crc file, which is the Linux Kernel image with length and CRC information added as
      two 4 byte data at the beginning.

4) Boot into the Linux with NAND MTD driver (using debugger and RedBoot). Write the iplspl.bin file into first NAND 
   partition (/dev/mtd/5).Write kernel image Image_crc into second NAND partition (/dev/mtd/6). Write the root filesystem 
   image into third NAND partition (/dev/mtd/7). Please note that Linux kernel image should be compiled to use the root from 
   /dev/mtd/7. Then reboot the EVB.  Now NAND boot should boot up the Linux kernel image from /dev/mtd/6. Please note that 
   the EVB should be configured for NAND boot (Refer to NAND Boot design document(nandboot.fm)  for NAND Boot fuses).

5) Run the Linux platform. This should give a menu of options to boot the Kernel.

6) Generate nandboot documentation by executing the command 'make doxygen'

Configuration of NANDBoot:
-------------------------
The following parameters can be configured by editing the header file
bootloader/mxc.h:

1) UART_OUTPUT : Selects between External or Internal MXC UART
   This value is set to INT_UART by default.
   Valid values:
        INT_UART - Use Internal MXC UART
        EXT_UART - Use External UART

2) UART_PORT : Selects the UART port number
   if UART_OUTPUT is set to EXT_UART
   Valid values: 
        1 - Use  EXT_UART_A
        2 - Use  EXT_UART_B

   if UART_OUTPUT is set to INT_UART
    Valid values
        2 - Use MXC UART_C

3) WDOG_EN: Enable/Disable Watchdog timer (MMCU_WDOG_1)
   Valid values: 
        1 - Enable
        0 - Disable

4) UNIT_TEST: Enable/Disable unit testing of NANDBoot
   Enabling unit testing will make NANDBoot to perform unit test before going
   to the main menu.
   Valid values:
        Non-zero  - Enable Unit testing
        0         - Disable unit testing

5)  CRC_EN : Enable/Diable 'Addition CRC' feature  in Miniboot
      Valid values
          1 - Enable
          0 - Diable        

6)  CHANGE_COMMAND_LINE_OPTION : Enable/Disble change of command line
                                        option  in Nandboot
         Valid Values
              1 - Enable
              0 - Disable
7) CHANGE_COMMAND_LINE_ADDRESS :  Enable/Disble change of command line
                                  addresss option  in nandboot
        Valid Values
              1 - Enable
              0 - Disable

8)  UART_BAUD_RATE : Change UART Baud rate
        Valid values
                9600, 19200, 38400, 57600, 115200

                                                            
For details of the other configuration parameters, refer to Doxygen generated
documentation for NANDBoot in full_output directory.

--

