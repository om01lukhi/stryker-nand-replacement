/******************************************************************************

 C   H E A D E R   F I L E

 (c) Copyright Motorola Semiconductors Hong Kong Limited 2001-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name : i.MX System Test Program
 Project No.  : 
 Title        : 
 File Name    : testcase.h
 Last Modified: 04/27/2003
 (MM/DD/YYYY)

 Description  : This file contains all the test case specific data types

 Assumptions  : 
 
 Dependency Comments :

 Project Specific Data :
 
 History (MM/DD/YYYY) :
 04/27/2003 - Initial Proposal

******************************************************************************/

#ifndef _TESTCASE_H
#define _TESTCASE_H

/*************************** Header File Includes ****************************/
#include "common.h"
/********************************* Constants *********************************/
/******************************** Enumeration ********************************/
typedef enum {
	OK,
	// Add other failure cases here.  For example....
	ERR_INIT_FAILED,
	ERR_TIMEOUT,
	ERR_INVALID_CASE
} status_t;

/****************************** Basic Data types *****************************/
typedef status_t (* testfunc_t) (void);

/************************* Structure/Union Data types ************************/
/* test case structure */
typedef struct
{
	testfunc_t	func;
	uint8_t		caseNum;
} testcase_t;

/* point structure	*/
typedef struct
{
    uint16_t	x;		/*  x point  */
    uint16_t	y;		/*  y point  */
} point_t, *p_point_t;

/* area structure	*/
typedef struct
{
	point_t		top;	/*  Top left corner		*/
	point_t		bottom;	/*  Bottom right corner	*/
} area_t, *p_area_t;

/********************************** Macros ***********************************/
/******************************* Global Data *********************************/
/*************************** Function prototype (S) **************************/

#ifdef EXTERN
    #undef EXTERN
#endif

#ifdef PROTO_DEFINE_FUNCS
    #define EXTERN
#else
    #define EXTERN extern
#endif

EXTERN status_t case1(void);
EXTERN status_t case2(void);
EXTERN status_t case3(void);

#endif