/******************************************************************************

 C   H E A D E R   F I L E

 (c) Copyright Motorola Semiconductors Hong Kong Limited 2001-2003
 ALL RIGHTS RESERVED

*******************************************************************************

 Project Name : i.MX System Test Program
 Project No.  : 
 Title        : 
 File Name    : prototype.h
 Last Modified: 04/27/2003
 (MM/DD/YYYY)

 Description  : Prototype definition header for i.MX silicon system test program.

 Assumptions  : 
 
 Dependency Comments :

 Project Specific Data :
 
 History (MM/DD/YYYY) :
 04/27/2003 - Initial Proposal

******************************************************************************/

#ifndef _PROTOTYPE_H
#define _PROTOTYPE_H

/*************************** Header File Includes ****************************/

#ifdef EXTERN
    #undef EXTERN
#endif

#ifdef PROTO_DEFINE_FUNCS
    #define EXTERN
#else
    #define EXTERN extern
#endif

/********************************* Constants *********************************/
/******************************** Enumeration ********************************/
/****************************** Basic Data types *****************************/
/************************* Structure/Union Data types ************************/
/********************************** Macros ***********************************/
/******************************* Global Data *********************************/
/*************************** Function prototype (S) **************************/

/* Interrupt Service Routines function prototypes */
void   fast_scr31_isr(void);	// fast_scr31_isr (31)
void   fast_scr63_isr(void);	// fast_scr63_isr (63)
void   fast_scr30_isr(void);	// fast_scr30_isr (30)
void   fast_scr62_isr(void);	// fast_scr62_isr (62)
void   fast_scr29_isr(void);	// fast_scr29_isr (29)
void   fast_scr61_isr(void);	// fast_scr61_isr (61)
void   fast_scr28_isr(void);	// fast_scr28_isr (28)
void   fast_scr60_isr(void);	// fast_scr60_isr (60)
void   fast_scr27_isr(void);	// fast_scr27_isr (27)
void   fast_scr59_isr(void);	// fast_scr59_isr (59)
void   fast_scr26_isr(void);	// fast_scr26_isr (26)
void   fast_scr58_isr(void);	// fast_scr58_isr (58)
void   fast_scr25_isr(void);	// fast_scr25_isr (25)
void   fast_scr57_isr(void);	// fast_scr57_isr (57)
void   fast_scr24_isr(void);	// fast_scr24_isr (24)
void   fast_scr56_isr(void);	// fast_scr56_isr (56)
void   fast_scr23_isr(void);	// fast_scr23_isr (23)
void   fast_scr55_isr(void);	// fast_scr55_isr (55)
void   fast_scr22_isr(void);	// fast_scr22_isr (22)
void   fast_scr54_isr(void);	// fast_scr54_isr (54)
void   fast_scr21_isr(void);	// fast_scr21_isr (21)
void   fast_scr53_isr(void);	// fast_scr53_isr (53)
void   fast_scr20_isr(void);	// fast_scr20_isr (20)
void   fast_scr52_isr(void);	// fast_scr52_isr (52)
void   fast_scr19_isr(void);	// fast_scr19_isr (19)
void   fast_scr51_isr(void);	// fast_scr51_isr (51)
void   fast_scr18_isr(void);	// fast_scr18_isr (18)
void   fast_scr50_isr(void);	// fast_scr50_isr (50)
void   fast_scr17_isr(void);	// fast_scr17_isr (17)
void   fast_scr49_isr(void);	// fast_scr49_isr (49)
void   fast_scr16_isr(void);	// fast_scr16_isr (16)
void   fast_scr48_isr(void);	// fast_scr48_isr (48)
void   fast_scr15_isr(void);	// fast_scr15_isr (15)
void   fast_scr47_isr(void);	// fast_scr47_isr (47)
void   fast_scr14_isr(void);	// fast_scr14_isr (14)
void   fast_scr46_isr(void);	// fast_scr46_isr (46)
void   fast_scr13_isr(void);	// fast_scr13_isr (13)
void   fast_scr45_isr(void);	// fast_scr45_isr (45)
void   fast_scr12_isr(void);	// fast_scr12_isr (12)
void   fast_scr44_isr(void);	// fast_scr44_isr (44)
void   fast_scr11_isr(void);	// fast_scr11_isr (11)
void   fast_scr43_isr(void);	// fast_scr43_isr (43)
void   fast_scr10_isr(void);	// fast_scr10_isr (10)
void   fast_scr42_isr(void);	// fast_scr42_isr (42)
void   fast_scr09_isr(void);	// fast_scr09_isr  (9)
void   fast_scr41_isr(void);	// fast_scr41_isr (41)
void   fast_scr08_isr(void);	// fast_scr08_isr  (8)
void   fast_scr40_isr(void);	// fast_scr40_isr (40)
void   fast_scr07_isr(void);	// fast_scr07_isr  (7)
void   fast_scr39_isr(void);	// fast_scr39_isr (39)
void   fast_scr06_isr(void);	// fast_scr06_isr  (6)
void   fast_scr38_isr(void);	// fast_scr38_isr (38)
void   fast_scr05_isr(void);	// fast_scr05_isr  (5)
void   fast_scr37_isr(void);	// fast_scr37_isr (37)
void   fast_scr04_isr(void);	// fast_scr04_isr  (4)
void   fast_scr36_isr(void);	// fast_scr36_isr (36)
void   fast_scr03_isr(void);	// fast_scr03_isr  (3)
void   fast_scr35_isr(void);	// fast_scr35_isr (35)
void   fast_scr02_isr(void);	// fast_scr02_isr  (2)
void   fast_scr34_isr(void);	// fast_scr34_isr (34)
void   fast_scr01_isr(void);	// fast_scr01_isr  (1)
void   fast_scr33_isr(void);	// fast_scr33_isr (33)
void   fast_scr32_isr(void);	// fast_scr32_isr (32)
void   fast_scr00_isr(void);	// fast_scr00_isr (0)

void   norm_scr31_isr(void);	// norm_scr31_isr (31)
void   norm_scr63_isr(void);	// norm_scr63_isr (63)
void   norm_scr30_isr(void);	// norm_scr30_isr (30)
void   norm_scr62_isr(void);	// norm_scr62_isr (62)
void   norm_scr29_isr(void);	// norm_scr29_isr (29)
void   norm_scr61_isr(void);	// norm_scr61_isr (61)
void   norm_scr28_isr(void);	// norm_scr28_isr (28)
void   norm_scr60_isr(void);	// norm_scr60_isr (60)
void   norm_scr27_isr(void);	// norm_scr27_isr (27)
void   norm_scr59_isr(void);	// norm_scr59_isr (59)
void   norm_scr26_isr(void);	// norm_scr26_isr (26)
void   norm_scr58_isr(void);	// norm_scr58_isr (58)
void   norm_scr25_isr(void);	// norm_scr25_isr (25)
void   norm_scr57_isr(void);	// norm_scr57_isr (57)
void   norm_scr24_isr(void);	// norm_scr24_isr (24)
void   norm_scr56_isr(void);	// norm_scr56_isr (56)
void   norm_scr23_isr(void);	// norm_scr23_isr (23)
void   norm_scr55_isr(void);	// norm_scr55_isr (55)
void   norm_scr22_isr(void);	// norm_scr22_isr (22)
void   norm_scr54_isr(void);	// norm_scr54_isr (54)
void   norm_scr21_isr(void);	// norm_scr21_isr (21)
void   norm_scr53_isr(void);	// norm_scr53_isr (53)
void   norm_scr20_isr(void);	// norm_scr20_isr (20)
void   norm_scr52_isr(void);	// norm_scr52_isr (52)
void   norm_scr19_isr(void);	// norm_scr19_isr (19)
void   norm_scr51_isr(void);	// norm_scr51_isr (51)
void   norm_scr18_isr(void);	// norm_scr18_isr (18)
void   norm_scr50_isr(void);	// norm_scr50_isr (50)
void   norm_scr17_isr(void);	// norm_scr17_isr (17)
void   norm_scr49_isr(void);	// norm_scr49_isr (49)
void   norm_scr16_isr(void);	// norm_scr16_isr (16)
void   norm_scr48_isr(void);	// norm_scr48_isr (48)
void   norm_scr15_isr(void);	// norm_scr15_isr (15)
void   norm_scr47_isr(void);	// norm_scr47_isr (47)
void   norm_scr14_isr(void);	// norm_scr14_isr (14)
void   norm_scr46_isr(void);	// norm_scr46_isr (46)
void   norm_scr13_isr(void);	// norm_scr13_isr (13)
void   norm_scr45_isr(void);	// norm_scr45_isr (45)
void   norm_scr12_isr(void);	// norm_scr12_isr (12)
void   norm_scr44_isr(void);	// norm_scr44_isr (44)
void   norm_scr11_isr(void);	// norm_scr11_isr (11)
void   norm_scr43_isr(void);	// norm_scr43_isr (43)
void   norm_scr10_isr(void);	// norm_scr10_isr (10)
void   norm_scr42_isr(void);	// norm_scr42_isr (42)
void   norm_scr09_isr(void);	// norm_scr09_isr  (9)
void   norm_scr41_isr(void);	// norm_scr41_isr (41)
void   norm_scr08_isr(void);	// norm_scr08_isr  (8)
void   norm_scr40_isr(void);	// norm_scr40_isr (40)
void   norm_scr07_isr(void);	// norm_scr07_isr  (7)
void   norm_scr39_isr(void);	// norm_scr39_isr (39)
void   norm_scr06_isr(void);	// norm_scr06_isr  (6)
void   norm_scr38_isr(void);	// norm_scr38_isr (38)
void   norm_scr05_isr(void);	// norm_scr05_isr  (5)
void   norm_scr37_isr(void);	// norm_scr37_isr (37)
void   norm_scr04_isr(void);	// norm_scr04_isr  (4)
void   norm_scr36_isr(void);	// norm_scr36_isr (36)
void   norm_scr03_isr(void);	// norm_scr03_isr  (3)
void   norm_scr35_isr(void);	// norm_scr35_isr (35)
void   norm_scr02_isr(void);	// norm_scr02_isr  (2)
void   norm_scr34_isr(void);	// norm_scr34_isr (34)
void   norm_scr01_isr(void);	// norm_scr01_isr  (1)
void   norm_scr33_isr(void);	// norm_scr33_isr (33)
void   norm_scr32_isr(void);	// norm_scr32_isr (32)
void   norm_scr00_isr(void);	// norm_scr00_isr (00)


#endif