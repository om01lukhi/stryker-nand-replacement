/*
 * Copyright 2004-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

/*!
 * @file boot.c
 * 
 * @brief Main source file for Nandboot
 *
 * @ingroup NANDboot
 */

#include "mxc.h"
#include "version.h"
#include "mxc_uart.h"
#include "btcs_config.h"
#ifdef CONFIG_BTCS
#include "btcs_defs.h"
#endif

/*!
 * This function initially calls the system initialization function 
 * It displays menu at the terminal which provides 
 * different options for the kernel loading and then waits for user inputs. 
 * For executing the Linux kernel it calls the \b jump_to_kernel 
 * assembly routine.
 *
 */

#define INTERACTIVE_BOOT
#undef INTERACTIVE_BOOT

void mxc_main(void)
{
	U32 *pmem = KERNEL_DEST_ADDR;
	U8 *pcmdline = CMDLINE_ADDR;
	U8 hexstr[20];
	int addr, i = 0, timeout = MENU_TIMEOUT;
	U8 boot_option = '1', ch;
	char cmdline[MAX_STRLEN] = "noinitrd console=ttymxc0,115200 ubi.mtd=4 root=ubi0:root rootfstype=ubifs init=/linuxrc";
	unsigned int system_rev = read_system_rev();
	const char nandboot_version_string[] =
	    NANDBOOT_VERSION" (Build: " NANDBOOT_DATE " - " NANDBOOT_TIME ")\n";
	char *btcs_version_string;
#ifdef CLR_WDOG_PDE
	mxc_wdog_clrpde();
#endif
	U32 kernel_start_block = KERNEL_START_BLOCK_512B;
#ifdef CONFIG_BTCS
	U32 btcs_start_block = BTCS_START_BLOCK_512B;
	struct btcs_cb_interface *btcs;
#endif
	U32 g_page_size;
	mxc_platform_init();
	/* Initialize Watchdog Timer */
	mxc_wd_init();
	/* Initialize UART */
#if (UART_OUTPUT==INT_UART)
	mxc_uart_init();
#endif
#ifdef IMX25_3STACK
	/* initialize the pmic */
	i2c_write(PMIC_I2C_ADDR, 0x2, 0x9);
#endif
#ifdef IMX35_3STACK
	/* Pull down the CAN_PWDN on pmic */
	i2c_write(PMIC_I2C_ADDR, 0x21, 0x60);
#endif
	/* service WDOG Timer */
	mxc_wd_reset();

#if UNIT_TEST
	mxc_uart_unit_test();
#endif
	g_page_size = mxcnb_scan_badblocks(kernel_start_block);
	if(g_page_size == NFC_PAGESIZE_2K) {
		kernel_start_block = KERNEL_START_BLOCK_2k;
#ifdef CONFIG_BTCS
		btcs_start_block = BTCS_START_BLOCK_2k;
#endif
	} else if (g_page_size & NFC_PAGESIZE_4K) {
		kernel_start_block = KERNEL_START_BLOCK_4k;
#ifdef CONFIG_BTCS
		btcs_start_block = BTCS_START_BLOCK_4k;
#endif
	}
	mxc_setup_taglist(0, system_rev);
	/* Display message */
	mxc_outstring("\nFreescale MXC processor - ");
	mxc_puthex(system_rev);
	mxc_putdata('\n');
	mxc_outstring(nandboot_version_string);
	while (1) {
#ifdef INTERACTIVE_BOOT
		mxc_wd_reset();
		mxc_outstring("Choose an option from below:\n");
#ifdef CONFIG_BTCS
		mxc_outstring("1. Load BTCS \n");
		mxc_outstring("2. Load kernel to RAM and then boot from [0x"); mxc_puthex(pmem); mxc_outstring("]\n");
#else
		mxc_outstring("1. Load kernel to RAM and then boot from [0x"); mxc_puthex(pmem); mxc_outstring("]\n");
#endif
		mxc_outstring("\n   Please enter selection ->  ");
		/* Loop to receive input from user */
		do {
			mxc_outstring("\b ");
			if (!mxc_timeout(timeout)) {
				boot_option = mxc_getdata();
				mxc_putdata(boot_option);
				if (boot_option >= 0x20) {
					mxc_putdata('\b');
					mxc_putdata(boot_option);
				}

			} else {
				boot_option = '1';
				mxc_outstring("Timeout occured \n\n");
			}
		} while ((boot_option < '1') || (boot_option > '2'));
		mxc_wd_reset();

		mxc_outstring("\n\n");
#endif

		switch (boot_option) {
		case '1':
#ifdef CONFIG_BTCS
			btcs = (struct btcs_cb_interface *)CONFIG_BTCS_START;

			if (!mxc_nfb_copyimage(btcs, btcs_start_block, 0)) {
				mxc_outstring("Bad btcs exiting......\n");
				break;
			}
			mxc_wd_reset();

			btcs_version_string = btcs->version;
			mxc_putdata('\n');
			mxc_outstring(btcs_version_string);
			mxc_outstring("\n-->Starting btcs...\n");
			btcs->setup();
			btcs->start();
#ifdef INTERACTIVE_BOOT
			break;
#else
			/* 
			 * Fall into...
			 */
#endif
		case '2':
#endif
			mxc_outstring("-->Booting from RAM...\n");

			if (!mxc_nfb_copyimage(pmem, kernel_start_block, 1)) {
				mxc_outstring("Bad kernel exiting......\n");
				break;
			}
			mxc_wd_reset();

			mxc_outstring("-->Starting kernel...\n");
			HAL_ICACHE_SYNC();
			HAL_DCACHE_INVALIDATE_ALL();
			HAL_ICACHE_DISABLE();
			HAL_DCACHE_DISABLE();
			hal_mmu_disable();
			jump_to_kernel(0, PROC_ID, pcmdline, pmem);
			/*
			 * Not reached
			 */
			break;
		}
	}
}

