/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#include "mxc.h"

unsigned int read_system_rev(void)
{
	int val;

	unsigned int system_rev = 0x35 << PART_NUMBER_OFFSET; /* For MX35 Platform*/

	/* get silicon id */
	val = _reg_MXC_IIM_SREV & 0xF;
        system_rev |= val << 4;

	/* Now trying to retrieve the silicon rev from IIM's SREV register */
	return system_rev;
}

void mxc_platform_init()
{
	/* Mask all interrupts */
	_reg_MXC_ASIC_NIMASK = 0xFFFFFFFF;

	/* Make all interrupts IRQ and not FIQ */
	_reg_MXC_ASIC_INTTYPEH = 0;
	_reg_MXC_ASIC_INTTYPEL = 0;
}
