/* mx21serial.h */

#define COM1_S "COM1:"
#define COM2_S "COM2:"
#define COM3_S "COM3:"

enum { PACKET_SIZE  = 256 };
enum { USB_PACKET_SIZE  = 32 };
enum { SER_PACKET_SIZE  = 1024 };
enum { PAR_PACKET_SIZE  = 128 };
enum { COM1 = 1};
enum { COM2 = 2};
enum { COM3 = 3};
enum { SPACE = 32 };
enum { TILDE = 126 };

// Types to be used later.
typedef unsigned long       DWORD;
typedef int                 BOOL;
typedef unsigned char       BYTE;
typedef unsigned short      WORD;
typedef float               FLOAT;
typedef void				*PVOID;
typedef PVOID				HANDLE;

/* command values */
#define CMD_READ           0x0101 /* read memory */
#define CMD_WRITE          0x0202 /* write memory location */
#define CMD_PC             0x0303 /* ??? */
#define CMD_DOWNLOAD       0x0404 /* block download  */
#define CMD_STATUS         0x0505 /* Get boot status */
#define CMD_CSF_ADDR       0x0606 /* Specify CSF data address */
#define CMD_HW_CONFIG_ADDR 0x0707 /* Specify Hardware Configuration data address */
#define CMD_EXECUTE_ADDR   0x0808 /* Specify Execute address */

// Access type values for read and write commands.
#define END_EXEC		0xAA
#define END_RPT			0x00

/* status messages taken from the HK download code. */
struct status_decode {
	unsigned long code;
	char *description;
} status_codes[] = {
{0x56787856, "Development part"},
{0x12343412, "Production part"},
{0x8D8D8D8D, "Data specified is out of bounds"},
{0x55555555, "Error during Assert Verification"},
{0x36363636, "Hash verification failed (including hash verification on certificates)"},
{0x33333333, "Certificate parsing failed, or the certificate contained an unsupported key (including unsupported key length)"},
{0x35353535, "Signature verification failed (including signature verification on certificate)"},
{0x39393939, "Failure not matching any other description"},
{0x4B4B4B4B, "CSF Command Sequence contains an unsupported command identifier"},
{0x4E4E4E4E, "Absence of expected CSF Header (including mismatched HAB Version)"},
{0x4D4D4D4D, "CSF length is unsupported"},
{0x2E2E2E2E, "CSF TYPE does not match processor TYPE"},
{0x2D2D2D2D, "CSF UID does not match either processor UID or generic UID"},
{0x3A3A3A3A, "CSF Customer/Product code does not match processor Customer/Product code"},
{0x87878787, "Key index is either unsupported, or an attempt is made to overwrite the Super-Root key"},
{0xF0F0F0F0, "Successful operation completion"},
{0x17171717, "SCC unexpectedly not in Secure State"},
{0x1E1E1E1E, "SecureRAM secret key invalid"},
{0x1D1D1D1D, "SecureRAM initialization failure"},
{0x1B1B1B1B, "SecureRAM Self Test failure"},
{0x2B2B2B2B, "SecureRAM internal failure"},
{0x27272727, "SecureRAM secret key unexpectedly in use"},																													 
{0x3C3C3C3C, "SAHARA failure"},
{0x59595959, "SAHARA/SCC connectivity failure"},
{0x0F0F0F0F, "SHW is not enabled"},
{0x8B8B8B8B, "An attempt is made to read a key from the list of subordinate public keys at a location where no key is installed"},
{0x8E8E8E8E, "Algorithm type is either invalid or otherwise unsupported (eg. Debug Port activated while the HAC of a non-engineering processor TYPE is in use)"},
{0x66666666, "Write operation to register failed"},
{0x63636363, "HW configuration block invalid "},
{0x65656565, "HW configuration block missing when booting from NAND flash "},
{0x65656565, "HW configuration block missing when booting from NAND flash "},	
{0x6F6F6F6F, "RAM application pointer is NULL or ERASED_FLASH"},
{0x69696969, "CSF missing when HAB enabled "},
{0x6A6A6A6A, "NANDFC buffer load failed"},
{0x6C6C6C6C, "Exception has occurred"},
{0x00000000, "Download Success & Completed"},
{0, 0}  /* must be last */
};


#define SET_ADDR(h, v)								\
	do {											\
		h[2] = (unsigned char)(v >> 24); 			\
		h[3] = (unsigned char)((v >> 16) & 0xFF); 	\
		h[4] = (unsigned char)((v >> 8) & 0xFF);  	\
		h[5] = (unsigned char)(v & 0xFF);			\
	} while(0)
#define SET_COUNT(h, v)								\
	do {											\
		h[7] = (unsigned char)(v >> 24);			\
		h[8] = (unsigned char)((v >> 16) & 0xFF);	\
		h[9] = (unsigned char)((v >> 8) & 0xFF); 	\
		h[10] = (unsigned char)(v & 0xFF);			\
	} while(0)
#define SET_DATA(h, v)								\
	do {											\
		h[11] = (unsigned char)(v >> 24); 			\
		h[12] = (unsigned char)((v >> 16) & 0xFF);	\
		h[13] = (unsigned char)((v >> 8) & 0xFF); 	\
		h[14] = (unsigned char)(v & 0xFF);			\
	} while(0)
#define GET_CMD(h)      *(unsigned short*)h

/* command acknowledge code for commands other that status. */
#define PRODUCTION_PART  0x12343412
#define DEVELOPMENT_PART 0x56787856
#define WRITE_COMPLETE   0x128A8A12 /* 2nd ack after write is complete */

#define swap_16(x)	((x >> 8) | ((x & 0xFF) << 8))
#define swap_32(x)	((x >> 24) | ((x & 0xFF0000) >> 8) | ((x & 0xFF00) << 8) | ((x & 0xFF) << 24))

#define _x			0xFF
#define ROM_ERROR	-1
#define ROM_OK		0
#define ERR_FILE_NOT_OPEN	-100
#define ERR_FILE_ZERO_BYTE  -101

enum {
	ENUM_DOWNLOAD,
	ENUM_NOR,
	ENUM_NAND,
	ENUM_NULL,
};

#define CS0_BASE_ADDR				0xC8000000
#define CS0_SIZE					0x02000000
#define NFC_BASE					0xDF003000
#define NFC_SIZE					0x02000000 //todo: check
#define SDRAM_BASE_ADDR     0xC0000000
#define SDRAM_SIZE          0x04000000
#define FLASH_CODE_ADDR		0xC3F00000 
#define MDBMX2_AITC_NIPRIORITY3     0x10040030
#define MDBMX2_AITC_NIPRIORITY2     0x10040034
#define MDBMX2_AITC_NIPRIORITY1     0x10040038
#define MDBMX2_AITC_NIPRIORITY0     0x1004003C
#define SERIAL_DOWNLOAD_MAGIC       0x000000AA
#define SERIAL_DOWNLOAD_MAGIC_REG   MDBMX2_AITC_NIPRIORITY3
#define SERIAL_DOWNLOAD_SRC_REG     MDBMX2_AITC_NIPRIORITY2
#define SERIAL_DOWNLOAD_TGT_REG     MDBMX2_AITC_NIPRIORITY1
#define SERIAL_DOWNLOAD_SZ_REG      MDBMX2_AITC_NIPRIORITY0
#define SERIAL_DOWNLOAD_SRC_ADDR	(SDRAM_BASE_ADDR + 0x100000)

#define REG_READ	1
#define REG_WEITE	2

int Setup_Port(HANDLE hCom, int baud);
HANDLE Open_Port(char* pcCommPort, int baud);
void Shutdown_Port(HANDLE portH);
void PRINT_HELP_MSG(char* s);
char *status_to_string(unsigned long status);
int parse_cmd_line(int argc, char* argv[], int *p_num, unsigned long *download);
int op_header(HANDLE handle, unsigned char* header, unsigned long *result);
int download_file(HANDLE handle, char *f_name, unsigned long addr);
int config_reg(HANDLE handle, struct reg_addr_val p[], unsigned long count);


