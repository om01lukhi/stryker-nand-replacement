;/* tahiti_init.s */

;;; Copyright ARM Ltd 2000. All rights reserved.
;
; This module performs ROM/RAM remapping (if required), initializes stack pointers and 
; interrupts for each mode, and finally branches to __main in the C library (which 
; eventually calls main()).
;
; On reset, the ARM core starts up in Supervisor (SVC) mode, in ARM state, with IRQ and FIQ disabled.

        AREA    Init, CODE, READONLY


; --- Standard definitions of mode bits and interrupt (I & F) flags in PSRs

Mode_USR        EQU     0x10
Mode_FIQ        EQU     0x11
Mode_IRQ        EQU     0x12
Mode_SVC        EQU     0x13
Mode_ABT        EQU     0x17
Mode_UNDEF      EQU     0x1B
Mode_SYS        EQU     0x1F ; available on ARM Arch 4 and later

I_Bit           EQU     0x80 ; when I bit is set, IRQ is disabled
F_Bit           EQU     0x40 ; when F bit is set, FIQ is disabled


; --- System memory locations

RAM_Limit       EQU     0xC0010000        	; For Tahiti
;RAM_Limit       EQU     0x08010000        	; For DBMX1 ADS
SVC_Stack       EQU     RAM_Limit           ; 4096 byte SVC stack at top of memory
USR_Stack       EQU     SVC_Stack-4096      ; followed by IRQ stack
IRQ_Stack       EQU     USR_Stack-4096      ; followed by SVC stack
FIQ_Stack		EQU		IRQ_Stack-4096 		; followed by USR stack

ROM_Start       EQU     0x00000000          ; Base address of ROM after remapping
Instruct_2      EQU     ROM_Start + 4       ; Address of second instruction in ROM

;CM_ctl_reg      EQU     0x1000000C          ; Address of Core Module Control Register
;Remap_bit       EQU     0x04                ; Bit 2 is remap bit of CM_ctl


        ENTRY

;; --- Perform ROM/RAM remapping, if required
;    IF :DEF: ROM_RAM_REMAP
;
;; On reset, an aliased copy of ROM is at 0x0.
;; Continue execution from 'real' ROM rather than aliased copy
;        LDR     pc, =Instruct_2
;
;; Remap by setting Remap bit of the CM_ctl register
;        LDR     r1, =CM_ctl_reg
;        LDR     r0, [r1]
;        ORR     r0, r0, #Remap_bit
;        STR     r0, [r1]
;        
;; RAM is now at 0x0.
;; The exception vectors (in vectors.s) must be copied from ROM to the RAM
;; The copying is done later by the C library code inside __main
;
;    ENDIF

        EXPORT  Reset_Handler

Reset_Handler

; --- Initialise stack pointer registers
; Enter SVC mode and set up the SVC stack pointer
        MSR     CPSR_c, #Mode_SVC:OR:I_Bit:OR:F_Bit ; No interrupts
        LDR     SP, =SVC_Stack

; Enter IRQ mode and set up the IRQ stack pointer
        MSR     CPSR_c, #Mode_IRQ:OR:I_Bit:OR:F_Bit ; No interrupts
        LDR     SP, =IRQ_Stack

; Enter FIQ mode and set up the FIQ stack pointer
        MSR     CPSR_c, #Mode_FIQ:OR:I_Bit:OR:F_Bit ; No interrupts
        LDR     SP, =FIQ_Stack


; Set up other stack pointers if necessary
        ; ...

; --- Initialise memory system
        ; ...

; --- Initialise critical IO devices
        ; ...

; --- Initialise interrupt system variables here
        ; ...

; --- Now change to User mode and set up User mode stack.
;        MSR     CPSR_c, #Mode_USR:OR:I_Bit:OR:F_Bit ; No interrupts
;        LDR     SP, =USR_Stack
; Finally, Re-Enter SVC mode
        MSR     CPSR_c, #Mode_SVC:OR:I_Bit:OR:F_Bit ; No interrupts
        LDR     SP, =SVC_Stack

        IMPORT  __main

; --- Now enter the C code
        B      __main   ; note use B not BL, because an application will never return this way

        END

