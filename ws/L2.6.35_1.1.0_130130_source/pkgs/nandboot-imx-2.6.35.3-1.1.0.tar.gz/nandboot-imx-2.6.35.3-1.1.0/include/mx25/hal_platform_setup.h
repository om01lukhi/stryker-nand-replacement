/*
 * Copyright 2009-2010 Freescale Semiconductor, Inc. All Rights Reserved.
 */
/*
 * The code contained herein is licensed under the GNU General Public
 * License. You may obtain a copy of the GNU General Public License
 * Version 2 or later at the following locations:
 *
 * http://www.opensource.org/licenses/gpl-license.html
 * http://www.gnu.org/copyleft/gpl.html
 */

#ifndef HAL_PLATFORM_SETUP_H_
#define HAL_PLATFORM_SETUP_H_

#include "mx25_3stack.h"

#if !defined(__ASSEMBLER__)

#define SETUP_IOMUX()  setup_iomux()
#define NFC_V1_2	/* V1.2 is an arbitrary designation for the MX25/MX35 NFC */

static void setup_iomux(void)
{
 	/* enable UART1 IPG clock */
	_reg_MXC_CCM_CGRC2 |= 0x00004000;
 	/* enable UART PER clock */
 	/* enable I2C PER clock */
	_reg_MXC_CCM_CGRC0 |= 0x00008040;

	_reg_MXC_CCM_CGRC0 |= 0x1fffffff;
	_reg_MXC_CCM_CGRC1 |= 0xffffffff;
	_reg_MXC_CCM_CGRC2 |= 0x000fdfff;

 	/* set UART PER div */
	//_reg_CCM_PCDR3 &= ~0x3f000000;
 	/* set NFC PER div */
	_reg_MXC_CCM_PCDR2 &= ~0x0000003f;
	_reg_MXC_CCM_PCDR2 |= (4 - 1);	/* 133 / 4 => 33.25 MHz */

	_reg_MXC_IOMUXC_MUX_CTL_I2C1_CLK = 0x10;
	_reg_MXC_IOMUXC_MUX_CTL_I2C1_DAT = 0x10;
	_reg_MXC_IOMUXC_PAD_CTL_I2C1_CLK = 0x1E8;
	_reg_MXC_IOMUXC_PAD_CTL_I2C1_CLK = 0x1E8;
}   

#include "hal_mm.h"
/*
 * hal_mmu_init() based on Redboot
 * Copyright (C) 1998, 1999, 2000, 2001, 2002 Red Hat, Inc.
 */
static void hal_mmu_init(void)
{
	unsigned long ttb_base = RAM_BANK0_BASE + 0x02000000;
	unsigned long i;
	static int zeros[8];

	/*
	 * Set the TTB register
	 */
	asm volatile ("mcr  p15,0,%0,c2,c0,0" : : "r"(ttb_base) /*:*/);

	/*
	 * Set the Domain Access Control Register
	 */
	i = ARM_ACCESS_DACR_DEFAULT;
	asm volatile ("mcr  p15,0,%0,c3,c0,0" : : "r"(i) /*:*/);

	/*
	 * First clear all TT entries - ie Set them to Faulting
	 */
	asmset_8w((void *)ttb_base, (void *)zeros, ARM_FIRST_LEVEL_PAGE_TABLE_SIZE / 32);

#define X		X_ARM_MMU_SECTION
#define NO_CACHE	ARM_UNCACHEABLE
#define CACHE		ARM_CACHEABLE
#define BUFF		ARM_BUFFERABLE
#define NO_BUFF		ARM_UNBUFFERABLE
#define RW		ARM_ACCESS_PERM_RW_RW
#define SECTION_BASE_ADDR(addr)	    (((unsigned long) addr) >> 20)
	/*--------------------------------------------------------------------------------------------------------------------------------------------------*/
	/*Physical				Virtual					    Size	    Attributes			Functions	    */
	/*Base					Base					    MB		cached?  buffered? r/w?				    */
	/*xxx00000				xxx00000												    */
	/*--------------------------------------------------------------------------------------------------------------------------------------------------*/
	X(SECTION_BASE_ADDR(SDRAM_BASE_ADDR),   SECTION_BASE_ADDR(SDRAM_BASE_ADDR),	    SDRAM_SIZE >> 20,	CACHE,    BUFF,    RW); /* SDRAM 64M 0x80000000 ---> 0x80000000 */
	X(SECTION_BASE_ADDR(SDRAM_BASE_ADDR),	SECTION_BASE_ADDR(SDRAM_BASE_ADDR_VIRT),    SDRAM_SIZE >> 20,	CACHE,    BUFF,    RW); /* SDRAM 64M 0x80000000 ---> 0xC0000000 where btcs is expected */	
	X(SECTION_BASE_ADDR(NFC_BASE_ADDR),	SECTION_BASE_ADDR(NFC_BASE_ADDR_VIRT),	    SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* NFC */
	X(SECTION_BASE_ADDR(AIPS1_BASE_ADDR),   SECTION_BASE_ADDR(AIPS1_BASE_ADDR_VIRT),    SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* AIPS1 to match kernel mapping */
	X(SECTION_BASE_ADDR(AIPS2_BASE_ADDR),   SECTION_BASE_ADDR(AIPS2_BASE_ADDR_VIRT),    SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* AIPS2 to match kernel mapping */
	X(SECTION_BASE_ADDR(ASIC_BASE_ADDR),    SECTION_BASE_ADDR(ASIC_BASE_ADDR_VIRT),     SZ_1M >> 20,	NO_CACHE, NO_BUFF, RW); /* ASIC mapping */
}

static void hal_mmu_enable(void)
{
asm("					\n\
	ldr r2, =10f			\n\
	mrc p15, 0, r1, c1, c0, 0	\n\
	orr r1, r1, #0x0007		\n\
	mcr p15, 0, r1, c1, c0, 0	\n\
	mov pc, r2			\n\
	nop				\n\
	nop				\n\
	nop				\n\
10:					\n\
	nop				\n\
");
}

static void hal_mmu_disable(void)
{
asm("					\n\
1:					\n\
	mrc p15, 0, r15, c7, c14, 3	\n\
	bne 1b				\n\
	mov r0, #0			\n\
	mcr p15,0,r0,c7,c10,4		\n\
	mcr p15,0,r0,c7,c5,0		\n\
	mrc p15,0,r0,c1,c0,0		\n\
	bic r0,r0,#0x7			\n\
	bic r0,r0,#0x1000		\n\
	mcr p15,0,r0,c1,c0,0		\n\
	nop				\n\
	nop				\n\
	nop				\n\
");
}

#endif

#if defined(__ASSEMBLER__) 
#if !defined(NOHALASM)  /* Added for linking */
/*
 * Platform setup macro
 */
#define PLATFORM_SETUP1 _platform_setup1

/* Patterned after redboot hal_platform_setup.h
 * This macro represents the initial startup code for the platform
 * r11 is reserved to contain chip rev info in this file
*/
    .macro  _platform_setup1
MX25_SETUP_START:
	/* invalidate I/D cache/TLB and drain write buffer */
	mov r0, #0
	mcr 15, 0, r0, c7, c7, 0	/* invalidate I cache and D cache */
	mcr 15, 0, r0, c8, c7, 0	/* invalidate TLBs */
	mcr 15, 0, r0, c7, c10, 4	/* Drain the write buffer */

	/* Disable Power Down Counter of WDOG */
	ldr r0, =WDOG_BASE_ADDR
	mov r1, #0
	strh r1, [r0, #8]

	init_aips
	init_clock
	setup_sdram_ddr
    .endm   /* _platform_setup1 */

    .macro init_clock
	ldr r0, =CCM_BASE_ADDR
	/* set MPLL to 399 MHz */
	ldr r1, =CCM_MPCTL_PARAM_399
	str r1, [r0, #CCM_MPCTL]
	ldr r1, =CCM_CCTL_PARAM
	str r1, [r0, #CCM_CCTL]
    .endm /* init_clock */

    .macro init_aips
	/* setup AIPS1 and AIPS2 */
	ldr r0, =AIPS1_BASE_ADDR
	ldr r1, =0x77777777
	str r1, [r0]	/* MPR_1 */
	str r2, [r0, #4]  /* MPR_2 */
	mov r1, #0
	str r1, [r0, #0x40]
	str r1, [r0, #0x44]
	str r1, [r0, #0x48]
	str r1, [r0, #0x4C]
	str r1, [r0, #0x50]
	ldr r0, =AIPS2_BASE_ADDR
	ldr r1, =0x77777777
	str r1, [r0]	/* MPR_1 */
	str r2, [r0, #4]  /* MPR_2 */
	mov r1, #0
	str r1, [r0, #0x40]
	str r1, [r0, #0x44]
	str r1, [r0, #0x48]
	str r1, [r0, #0x4C]
	str r1, [r0, #0x50]
    .endm /* init_aipi */

    .macro setup_sdram_ddr
	ldr r0, =ESDCTL_BASE_ADDR
	ldr r1, =0x0076E83A	/* initial ESDCFG0 value */
	str r1, [r0, #ESDCFG0]
	ldr r1, =0x00000204	/* initial ESD_MISC value */
	str r1, [r0, #ESDMISC]
	ldr r1, =0x92210000	/* CS0 precharge command */
	str r1, [r0, #ESDCTL0]
	ldr r2, =0x80000F00	/* precharge all dummy write */
	ldr r1, =0x12344321
	str r1, [r2]
	ldr r1, =0xB2210000	/* Load Mode Register command */
	str r1, [r0, #ESDCTL0]
	mov r1, #0xda
	ldr r2, =0x82000000	/* dummy write: Load EMR2 */
	strb r1, [r2]
	ldr r2, =0x83000000	/* dummy write: Load EMR3 */
	strb r1, [r2]
	ldr r2, =0x81000400	/* dummy write: Load EMR1; enable DLL */
	strb r1, [r2]
	ldr r2, =0x80000333	/* dummy write: Load MR; reset DLL */
	strb r1, [r2]
	ldr r1, =0x92210000	/* CS0 precharge command */
	str r1, [r0, #ESDCTL0]
	ldr r2, =0x80000400	/* precharge all dummy write */
	ldr r1, =0x12345678
	strb r1, [r2]
	ldr r1, =0xA2210000	/* select manual refresh mode */
	str r1, [r0, #ESDCTL0]
	ldr r2, =0x80000000	/* manual refresh once... */
	ldr r1, =0x87654321
	str r1, [r2]
	str r1, [r2]		/* ...and twice */
	ldr r1, =0xB2210000	/* Load Mode Register command */
	str r1, [r0, #ESDCTL0]
	mov r1, #0xda
	ldr r2, =0x80000233	/* dummy write: Load MR; CL=3, BL=8, end DLL reset */
	strb r1, [r2]
	ldr r2, =0x81000780	/* dummy write: Load EMR1; OCD default */
	strb r1, [r2]
	ldr r2, =0x81000400	/* dummy write: Load EMR1; OCD exit */
	strb r1, [r2]
//  ESD_ESDCTL0  SDE_SMODE_SP_ROW_00_COL_00_DSIZ_SREFR_0_PWDT_0_FP_BL_0__PRCT
//  ESD_ESDCTL0 32'b1_000__0__010_00__10_00___10___011_0___00_0__0__0_0_000000
//  @; normal mode row=010//col=10//dzize=10//self ref=011//PWDT =00//BL =0//prct =000000
	ldr r1, =0x82216080
	str r1, [r0, #ESDCTL0]
	/* init IOMUXC_SW_PAD_CTL_GRP_DDRTYPE_GRP(1-5) */
	ldr r0, =0x43FAC454
	ldr r1, =0x00001000
	str r1, [r0]
    .endm   /* setup_sdram_ddr */

#endif  /* !defined(NOHALASM) */
#endif  /* defined(__ASSEMBLER__) */
#endif  /* HAL_PLATFORM_SETUP_H_ */
